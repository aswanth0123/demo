from rest_framework import serializers
from .models import *


class OtherAccountSerializer(serializers.ModelSerializer):
    class Meta:
        model = OtherAccount
        fields = ['id', 'code', 'name', 'account_type']


class UomCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = UomCategory
        fields = ['id', 'name', 'code', 'measure_type']

class UnitOfMeasureSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name', read_only=True)

    class Meta:
        model = UnitOfMeasure
        fields = ['id', 'name', 'category', 'category_name', 'type', 'factor', 'precision', 'active']
