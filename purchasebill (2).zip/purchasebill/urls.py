from django.urls import path,include
from .views import *
from rest_framework.routers import DefaultRouter

app_name = 'purchasebill'

router = DefaultRouter()
router.register(r'other-accounts', OtherAccountViewSet)
router.register(r'uom-categories', UomCategoryViewSet, basename='uom-category')
router.register(r'uoms', UnitOfMeasureViewSet, basename='uom')

urlpatterns = [
    path('invoice/create/', InvoiceCreateView.as_view(), name='invoice_create'),
    path('return/create/', PurchaseReturnCreateView.as_view(), name='purchase_return_create'),
    path('api/products/', product_list_api, name='product_list_api'),
    path('api/product/<int:pk>/', product_detail_api, name='product_detail_api'),
    path('apis/', include(router.urls)),
    path('invoices/',invoice_list, name='invoice_list'),
    path('invoice/<int:pk>/edit/', invoice_edit, name='invoice_edit'),
    path('api/uom-categories/', UomCategoryListView.as_view(), name='uom_category_list_api'),
     path('api/uoms/search/', UomSearchView.as_view(), name='uom-search'),


]   
