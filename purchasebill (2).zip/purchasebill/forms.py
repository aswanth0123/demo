# purchasebill/forms.py

from django import forms
from django.forms import inlineformset_factory, BaseInlineFormSet
from .models import *
from customer.models import Customer
from datetime import date

# ------------------------
# Custom Form for InvoiceLine
# ------------------------
class InvoiceLineForm(forms.ModelForm):
    class Meta:
        model = InvoiceLine
        fields = [
            'product', 'hsn', 'uom', 'batch', 'qty', 'free_qty',
            'purchase_rate', 'sales_rate', 'discount_percent', 'discount_amount',
            'tax_percent', 'tax_amount', 'line_total', 'grand_total','tax',
        ]
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['product'].required = False
    
    def full_clean(self):
        super().full_clean()
        
        if self.data:
            product_value = None
            qty_value = None
            
            prefix = self.prefix + '-' if self.prefix else ''
            product_key = prefix + 'product'
            qty_key = prefix + 'qty'
            
            if product_key in self.data:
                product_value = self.data.get(product_key)
            if qty_key in self.data:
                try:
                    qty_value = float(self.data.get(qty_key) or 0)
                except (ValueError, TypeError):
                    qty_value = 0
            
            if not product_value and (not qty_value or qty_value == 0):
                self._errors = {}
                if not hasattr(self, 'cleaned_data'):
                    self.cleaned_data = {}
    
    def clean(self):
        cleaned_data = super().clean()
        product = cleaned_data.get('product')
        qty = cleaned_data.get('qty', 0) or 0
        
        if not product and qty == 0:
            return cleaned_data
        
        if not product:
            raise forms.ValidationError({'product': 'Product is required when quantity is entered.'})
        
        return cleaned_data

# ------------------------
# Custom FormSet to handle empty forms
# ------------------------
class InvoiceLineFormSetBase(BaseInlineFormSet):
    def clean(self):
        super().clean()
        for form in self.forms:
            if form in self.deleted_forms:
                continue
            if not hasattr(form, 'cleaned_data') or not form.cleaned_data:
                continue
            
            product = form.cleaned_data.get('product')
            qty = form.cleaned_data.get('qty', 0) or 0
            
            if not product and qty == 0:
                if form.instance and form.instance.pk:
                    form.cleaned_data['DELETE'] = True
                else:
                    for field_name in list(form.cleaned_data.keys()):
                        if field_name != 'DELETE':
                            del form.cleaned_data[field_name]

# ------------------------
# Main Invoice Form
# ------------------------
InvoiceLineFormSet = inlineformset_factory(
    parent_model=Invoice,
    model=InvoiceLine,
    form=InvoiceLineForm,
    fields=[
        'product', 'hsn', 'uom', 'batch', 'qty', 'free_qty',
        'purchase_rate', 'sales_rate', 'discount_percent', 'discount_amount',
        'tax_percent', 'tax_amount', 'line_total', 'grand_total','tax',
    ],
    extra=1,
    can_delete=True,
    formset=InvoiceLineFormSetBase
)


# ------------------------
# Invoice Form
# ------------------------
class InvoiceForm(forms.ModelForm):
    supplier = forms.ModelChoiceField(
        queryset=Customer.objects.filter(partner_type__in=['supplier', 'both']),
        required=True,
        label="Supplier",
        widget=forms.Select(attrs={'class': ''})
    )

    class Meta:
        model = Invoice
        fields = [
            'invoice_type', 'supplier', 'bill_date', 'bill_number',
            'invoice_date', 'invoice_number', 'branch', 'warehouse',
            'other_accounts', 'status', 'discount_type', 'discount_rate',
            'remarks','bill_amount', 'tax_amount','other_amount_total','grand_total'
        ]
        widgets = {
            'bill_number': forms.TextInput(attrs={'class': 'form-control', 'required': True}),
            'bill_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control', 'required': True}),
            'invoice_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'bill_amount': forms.NumberInput(attrs={'class': 'form-control', 'readonly': True}),
            'tax_amount': forms.NumberInput(attrs={'class': 'form-control', 'readonly': True}),
            'other_amount_total': forms.NumberInput(attrs={'class': 'form-control', 'readonly': True}),
            'grand_total': forms.NumberInput(attrs={'class': 'form-control', 'readonly': True}),
        }

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)

        # Read-only / disabled fields
        self.fields['invoice_number'].disabled = True
        self.fields['invoice_date'].disabled = True
        self.fields['branch'].disabled = True

        # Defaults
        if not self.initial.get('bill_date'):
            self.initial['bill_date'] = date.today()
            self.initial['invoice_date'] = date.today()

        # Default branch from user context
        if not self.initial.get('branch') and user:
            branch = None
            if getattr(user, 'user_type', None) == 'lco':
                branch = Branch.objects.filter(type_id=user.lco.code).first()
            if branch:
                self.initial['branch'] = branch.id
    def clean_bill_number(self):
        bill_number = self.cleaned_data.get('bill_number')
        qs = Invoice.objects.filter(bill_number=bill_number)

        # Exclude the current instance when editing
        if self.instance.pk:
            qs = qs.exclude(pk=self.instance.pk)

        if qs.exists():
            raise forms.ValidationError(
                "This Bill Number already exists. Please enter a unique Bill Number."
            )
        return bill_number


