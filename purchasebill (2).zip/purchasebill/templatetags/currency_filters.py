from django import template
from num2words import num2words

register = template.Library()

@register.filter
def currency_words(value):
    try:
        value = float(value)
        rupees = int(value)
        paise = int(round((value - rupees) * 100))
        words = f"{num2words(rupees, lang='en').replace('-', ' ')} rupees"
        if paise > 0:
            words += f" and {num2words(paise, lang='en').replace('-', ' ')} paise"
        return words + " only"
    except:
        return value
