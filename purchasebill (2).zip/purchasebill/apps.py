from django.apps import AppConfig


class PurchasebillConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'purchasebill'
