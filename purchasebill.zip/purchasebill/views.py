from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.db import transaction
from django.views import View
from django.http import JsonResponse
from .models import *
from .forms import *
from product.models import Product
from decimal import Decimal
from rest_framework import viewsets
from .serializers import * 
from django.db.models import Q
from django.forms.models import model_to_dict
import json
from datetime import datetime
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required
from django.urls import reverse
from django.db import IntegrityError
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status


class InvoiceCreateView(View):
    template_name = "purchasebill/invoice_create.html"

    def get(self, request, *args, **kwargs):
        invoice_form = InvoiceForm(user=request.user)
        line_formset = InvoiceLineFormSet()
        return render(request, self.template_name, {
            'form': invoice_form,
            'line_formset': line_formset,
        })

    def post(self, request, *args, **kwargs):
        data = request.POST.copy()
        data['invoice_type'] = 'purchase'
        data['status'] = 'draft'  # can later make 'posted' if you want auto-stock
        invoice_form = InvoiceForm(data, user=request.user)
        line_formset = InvoiceLineFormSet(request.POST)

        if invoice_form.is_valid() and line_formset.is_valid():
            try:
                with transaction.atomic():
                    # --- Save Invoice ---
                    invoice = invoice_form.save(commit=False)
                    invoice.created_by = request.user
                    invoice.invoice_type = 'purchase'
                    invoice.status = 'draft'
                    invoice.type = request.user.user_type
                    invoice.type_id = request.user.user_id
                    invoice.save()
                    invoice_form.save_m2m()

                    # --- Save Lines ---
                    lines = line_formset.save(commit=False)
                    for line in lines:
                        line.invoice = invoice
                        line.save()
                    line_formset.save_m2m()
                    update_invoice_tax_summary(invoice)
                    # for line in invoice.lines.all():
                    #     StockOnProduct.objects.create(
                    #         invoice=invoice,
                    #         product=line.product,
                    #         batch=line.batch,
                    #         warehouse=invoice.warehouse,
                    #         uom=line.uom,
                    #         movement_type='in',  # because it's purchase
                    #         qty=line.qty,
                    #         free_qty=line.free_qty,
                    #     )
                    snapshot = model_to_dict(invoice)
                    product_details = []

                    for line in invoice.lines.all():
                        product_details.append({
                            "product_id": line.product_id,
                            "product_name": str(line.product),
                            "qty": float(line.qty),
                            "free_qty": float(getattr(line, "free_qty", 0)),
                            "purchase_rate": float(line.purchase_rate),
                            "line_total": float(line.line_total),
                            "grand_total": float(line.grand_total),
                        })

                    snapshot["lines"] = product_details
                    snapshot_json = json.dumps(snapshot, default=str)

                    summary_text = (
                        f"Invoice created by {request.user.username} with "
                        f"{len(product_details)} product(s)."
                    )

                    InvoiceLog.objects.create(
                        invoice=invoice,
                        action="create",
                        summary=summary_text,
                        changed_by=request.user,
                        snapshot=snapshot_json,
                        changes=None
                    )
                    messages.success(request, "Invoice created successfully and stock updated!")
                    return redirect('purchasebill:invoice_create')

            except Exception as e:
                print("Error:", e)
                messages.error(request, f"Error saving invoice: {e}")

        else:
            print("Form errors:", invoice_form.errors, line_formset.errors)
            messages.error(request, "Please correct the errors below.")

        return render(request, self.template_name, {
            'form': invoice_form,
            'line_formset': line_formset,
        })

from django.http import JsonResponse
from django.db.models import Prefetch, Sum, Case, When, F, DecimalField

def product_list_api(request):
    from decimal import Decimal
    
    query = request.GET.get('q', '').strip()
    products = Product.objects.prefetch_related(
        Prefetch('tax')
    )
    
    if query:
        products = products.filter(name__icontains=query)
    
    products = products[:20]
    product_ids = [p.id for p in products]
    
    stock_by_product = (
        StockOnProduct.objects
        .filter(product_id__in=product_ids)
        .values('product_id')
        .annotate(
            total_qty=Sum(
                Case(
                    When(movement_type='in', then=F('qty')),
                    When(movement_type='out', then=-F('qty')),
                    default=Decimal('0'),
                    output_field=DecimalField()
                )
            )
        )
    )
    
    stock_dict = {item['product_id']: float(item['total_qty'] or 0) for item in stock_by_product}

    data = []
    for p in products:
        total_quantity = stock_dict.get(p.id, 0.0)
        data.append({
            "id": p.id,
            "name": p.name,
            "sales_rate": p.sales_price,
            "purchase_rate": p.purchase_price,
            "quantity": total_quantity,
            "code": p.id,
            "taxes": list(p.tax.all().values("id", "tax_name", "percentage", "tax_type")),
        })
    
    return JsonResponse({"results": data})


def product_detail_api(request, pk):
    print(pk)
    p = Product.objects.get(pk=pk)
    taxes = p.tax.all().values("id", "tax_name", "percentage", "tax_type")    
    data = {
        "id": p.id,
        "name": p.name,
        "hsn": getattr(p, 'hsn', ''),
        "uom": getattr(p, 'uom', ''),
        "purchase_rate": getattr(p, 'purchase_price', 0),
        "sales_rate": getattr(p, 'sales_price', 0),
        "quantity": 0,
        "discount_percent": getattr(p, 'discount', 0),
        "taxes": list(taxes), 
    }
    # print(data)
    return JsonResponse(data)



class OtherAccountViewSet(viewsets.ModelViewSet):
    queryset = OtherAccount.objects.all().order_by('name')
    serializer_class = OtherAccountSerializer
    # permission_classes = [IsAuthenticated] # Uncomment and use your desired permission class

    def get_queryset(self):
        queryset = self.queryset
        query = self.request.query_params.get('q', None)
        
        if query is not None:
            # Filter by name or code matching the query
            queryset = queryset.filter(
                Q(name__icontains=query) | Q(code__icontains=query)
            )
            
        return queryset


class UomCategoryViewSet(viewsets.ModelViewSet):
    queryset = UomCategory.objects.all().order_by('name')
    print('@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@')
    # print(queryset, "queryset")
    serializer_class = UomCategorySerializer

    def get_queryset(self):
        queryset = self.queryset
        query = self.request.query_params.get('q', None)
        print(query, "query")
        print(type(query), "query type")
        if query:
            queryset = queryset.filter(
                Q(name__icontains=query) | Q(code__icontains=query)
            )
        print(queryset, "queryset")
        return queryset
    
    @transaction.atomic
    def perform_create(self, serializer):
        from rest_framework.exceptions import ValidationError as DRFValidationError
        
        name = serializer.validated_data.get('name')
        if UomCategory.objects.filter(name__iexact=name).exists():
            raise DRFValidationError({"name": [f"A category with the name '{name}' already exists."]})
        try:
            serializer.save()
        except IntegrityError as e:
            transaction.set_rollback(True)
            raise DRFValidationError({"name": [f"A category with the name '{name}' already exists."]})

    @transaction.atomic
    def perform_update(self, serializer):
        from rest_framework.exceptions import ValidationError as DRFValidationError
        
        category = self.get_object()
        name = serializer.validated_data.get('name')
        if UomCategory.objects.filter(name__iexact=name).exclude(id=category.id).exists():
            raise DRFValidationError({"name": [f"A category with the name '{name}' already exists."]})
        try:
            serializer.save()
        except IntegrityError as e:
            transaction.set_rollback(True)
            raise DRFValidationError({"name": [f"A category with the name '{name}' already exists."]})

class UomCategoryListView(APIView):
    """
    List all UOM Categories with search functionality
    """
    def get(self, request, format=None):
        # Get the query parameter for search
        query = request.GET.get('q', '')

        # Filter UOM categories based on the query
        uom_categories = UomCategory.objects.filter(name__icontains=query)

        # Serialize the filtered UOM categories
        serializer = UomCategorySerializer(uom_categories, many=True)

        # Return the response with the filtered list
        return Response({'success': True, 'items': serializer.data}, status=status.HTTP_200_OK)



class UnitOfMeasureViewSet(viewsets.ModelViewSet):
    queryset = UnitOfMeasure.objects.select_related('category').all()
    serializer_class = UnitOfMeasureSerializer

    def get_queryset(self):
        queryset = super().get_queryset()
        q = self.request.query_params.get('q')  # ✅ better to use query_params in DRF
        if q:
            queryset = queryset.filter(name__icontains=q)
        return queryset.order_by('name')

    @transaction.atomic
    def perform_create(self, serializer):
        from rest_framework.exceptions import ValidationError as DRFValidationError
        
        name = serializer.validated_data.get('name')
        category = serializer.validated_data.get('category')
        
        if UnitOfMeasure.objects.filter(name__iexact=name, category=category).exists():
            raise DRFValidationError({"name": ["A UOM with this name and category already exists."]})
        
        try:
            uom = serializer.save()
            
            try:
                UomChangeLog.objects.create(
                    uom=uom,
                    action='create',
                    field='all',
                    old_value='',
                    new_value=str(UnitOfMeasureSerializer(uom).data),
                    user=self.request.user if self.request.user.is_authenticated else None,
                )
            except Exception as log_error:
                print(f"Warning: Failed to create UOM log: {log_error}")
        except IntegrityError as e:
            transaction.set_rollback(True)
            raise DRFValidationError({"name": ["A UOM with this name and category already exists."]})

    @transaction.atomic
    def perform_update(self, serializer):
        instance = self.get_object()
        old_data = UnitOfMeasureSerializer(instance).data  # serialize current state
        uom = serializer.save()

        # ✅ iterate only over changed fields
        for field, new_value in serializer.validated_data.items():
            old_value = old_data.get(field)
            if str(old_value) != str(new_value):
                UomChangeLog.objects.create(
                    uom=uom,
                    action='update',
                    field=field,
                    old_value=str(old_value),
                    new_value=str(new_value),
                    user=self.request.user if self.request.user.is_authenticated else None,
                )


class UomSearchView(APIView):
    def get(self, request):
        query = request.GET.get('q', '').strip()
        if query:
            uoms = UnitOfMeasure.objects.filter(
                Q(name__icontains=query) | Q(code__icontains=query)
            )
        else:
            uoms = UnitOfMeasure.objects.all()

        serializer = UnitOfMeasureSerializer(uoms, many=True)
        
        print(serializer.data)
        return Response({'success': True, 'items': serializer.data}, status=status.HTTP_200_OK)
def invoice_list(request):
    query = request.GET.get('q', '').strip()
    from_date = request.GET.get('from_date', '')
    to_date = request.GET.get('to_date', '')
    items_per_page = int(request.GET.get('items_per_page', 10))
    page = request.GET.get('page', 1)

    invoices = Invoice.objects.all().select_related('supplier').order_by('-bill_date')

    # --- Search by text ---
    if query:
        invoices = invoices.filter(
            Q(supplier__name__icontains=query) |
            Q(bill_number__icontains=query) |
            Q(invoice_number__icontains=query)|
            Q(status__icontains=query)
        )

    # --- Date filtering ---
    if from_date:
        from_date = datetime.strptime(from_date, "%Y-%m-%d")
        invoices = invoices.filter(bill_date__gte=from_date)
    if to_date:
        to_date = datetime.strptime(to_date, "%Y-%m-%d")
        invoices = invoices.filter(bill_date__lte=to_date)

    # --- Pagination ---
    paginator = Paginator(invoices, items_per_page)
    page_obj = paginator.get_page(page)

    context = {
        'page_obj': page_obj,
        'query': query,
        'from_date': request.GET.get('from_date', ''),
        'to_date': request.GET.get('to_date', ''),
        'items_per_page': items_per_page,
        'start_index': page_obj.start_index() if page_obj.paginator.count > 0 else 0,
    }

    return render(request, 'purchasebill/invoice_list.html', context)


from django.db import transaction
from django.forms.models import model_to_dict
from django.contrib import messages


def group_invoice_logs(logs):

    grouped_logs = []
    for log in logs:
        changes_list = []

        if log.action == InvoiceLog.ACTION_UPDATE:
            # Placeholder for updates since actual 'changes' dict is missing in your view's save logic
            changes_list.append({
                "field_changed": "Invoice Update",
                "old_value": "See Snapshot", # Can't show diff without previous snapshot
                "new_value": log.summary,
            })
        elif log.action == InvoiceLog.ACTION_CREATE:
            changes_list.append({
                "field_changed": "Created", # Matches your creation log logic
                "old_value": None,
                "new_value": log.summary,
            })
        elif log.action == InvoiceLog.ACTION_DELETE:
            changes_list.append({
                "field_changed": "Deleted",
                "old_value": "N/A",
                "new_value": log.summary,
            })

        # Append the grouped log data
        grouped_logs.append({
            "changed_by": log.changed_by.get_full_name() if log.changed_by else "System",
            "change_timestamp": log.created_at,
            "changes": changes_list,
        })

    return grouped_logs



@login_required
def invoice_edit(request, pk):
    invoice = get_object_or_404(Invoice, pk=pk)

    if request.method == 'POST':
        action = request.POST.get('action', 'save_draft')
        original_status = invoice.status
        
        print(f"🔍 Action received: {action}")
        print(f"🔍 Original status: {original_status}")
        
        data = request.POST.copy()
        data['invoice_type'] = 'purchase'
        
        if action == 'post':
            data['status'] = 'posted'
        else:
            data['status'] = 'draft'
        
        print(f"🔍 Setting status to: {data['status']}")
            
        form = InvoiceForm(data, instance=invoice)
        line_formset = InvoiceLineFormSet(request.POST, instance=invoice)

        print(f"🔍 Form valid: {form.is_valid()}")
        print(f"🔍 Formset valid: {line_formset.is_valid()}")
        
        if not form.is_valid():
            print(f"❌ Form errors: {form.errors}")
        if not line_formset.is_valid():
            print(f"❌ Formset errors: {line_formset.errors}")

        if form.is_valid() and line_formset.is_valid():
            try:
                with transaction.atomic():
                    invoice = form.save(commit=False)
                    if not invoice.created_by:
                        invoice.created_by = request.user
                    invoice.type = request.user.user_type
                    invoice.type_id = request.user.user_id
                    
                    if action == 'post':
                        invoice.status = 'posted'
                        if not invoice.posted_by:
                            invoice.posted_by = request.user
                    else:
                        invoice.status = 'draft'
                    
                    invoice.save()
                    print(f"✅ Invoice saved with status: {invoice.status}, ID: {invoice.id}")

                    form.save_m2m()

                    lines = line_formset.save(commit=False)
                    saved_count = 0
                    for line in lines:
                        if line.product_id:
                            line.invoice = invoice
                            line.save()
                            saved_count += 1
                        else:
                            print(f"⚠️ Skipping line without product")
                    
                    for obj in line_formset.deleted_objects:
                        obj.delete()
                    
                    line_formset.save_m2m()
                    print(f"✅ Saved {len([l for l in lines if l.product_id])} invoice lines with products")

                    update_invoice_tax_summary(invoice)

                    is_transitioning_to_posted = original_status == 'draft' and invoice.status == 'posted'
                    
                    if is_transitioning_to_posted:
                        for line in invoice.lines.all():
                            StockOnProduct.objects.update_or_create(
                                invoice=invoice,
                                product=line.product,
                                batch=line.batch,
                                warehouse=invoice.warehouse,
                                defaults={
                                    "uom": line.uom,
                                    "movement_type": "in" if invoice.invoice_type == "purchase" else "out",
                                    "qty": line.qty,
                                    "free_qty": getattr(line, "free_qty", 0),
                                }
                            )

                    snapshot = model_to_dict(invoice)
                    product_details = []
                    for line in invoice.lines.all():
                        product_details.append({
                            "product_id": line.product_id,
                            "product_name": str(line.product),
                            "qty": float(line.qty),
                            "free_qty": float(getattr(line, "free_qty", 0)),
                            "purchase_rate": float(line.purchase_rate),
                            "line_total": float(line.line_total),
                            "grand_total": float(line.grand_total),
                        })
                    snapshot["lines"] = product_details
                    snapshot_json = json.dumps(snapshot, default=str)
                    
                    if action == 'post':
                        if is_transitioning_to_posted:
                            summary_text = f"Invoice posted by {request.user.username} with {len(product_details)} product(s). Stock updated."
                        else:
                            summary_text = f"Invoice updated and kept as posted by {request.user.username} with {len(product_details)} product(s)."
                    else:
                        summary_text = f"Invoice saved as draft by {request.user.username} with {len(product_details)} product(s)."

                    InvoiceLog.objects.create(
                        invoice=invoice,
                        action="update" if action == 'save_draft' else "post",
                        summary=summary_text,
                        changed_by=request.user,
                        snapshot=snapshot_json,
                        changes=None
                    )

                    if action == 'post':
                        if is_transitioning_to_posted:
                            messages.success(request, "Invoice posted successfully! Stock has been updated.")
                        else:
                            messages.success(request, "Invoice updated successfully!")
                    else:
                        messages.success(request, "Invoice saved as draft successfully!")
                    
                    return redirect(reverse('purchasebill:invoice_edit', kwargs={'pk': invoice.pk}))

            except Exception as e:
                print("❌ Error saving invoice:", e)
                messages.error(request, f"Error updating invoice: {e}")

        else:
            print("❌ Form or formset invalid", form.errors, line_formset.errors)
            messages.error(request, "Please correct the errors below.")

    else:
        form = InvoiceForm(instance=invoice)
        line_formset = InvoiceLineFormSet(instance=invoice)
    invoice_logs = InvoiceLog.objects.filter(invoice=invoice).select_related('changed_by')
    grouped_logs = group_invoice_logs(invoice_logs)
    return render(request, 'purchasebill/invoice_edit.html', {
        'form': form,
        'invoice': invoice,
        'line_formset': line_formset,
        'grouped_logs': grouped_logs,
    })
