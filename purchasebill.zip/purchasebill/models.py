from django.db import models
from customer.models import Customer
from product.models import Product,TaxRate
from django.contrib.auth.models import User
from django.db.models import JSONField as BuiltinJSONField
from django.conf import settings
import json
from django.utils.translation import gettext_lazy as _
from employe.models import Branch
from warehouse.models import Warehouse
from django.db import models
from authentication.models import CustomUser
class UomCategory(models.Model):
    MEASURE_TYPES = [
        ('unit', 'Unit'),
        ('time', 'Time'),
        ('weight', 'Weight'),
        ('length', 'Length'),
        ('volume', 'Volume'),
    ]

    name = models.CharField(max_length=100, unique=True)
    code = models.CharField(max_length=20,null=True, blank=True)
    measure_type = models.CharField(max_length=20, choices=MEASURE_TYPES, default='unit')

    def __str__(self):
        return f"{self.name} ({self.get_measure_type_display()})"


class UnitOfMeasure(models.Model):
    TYPE_CHOICES = [
        ('reference', 'Reference'),
        ('bigger', 'Bigger than Reference'),
        ('smaller', 'Smaller than Reference'),
    ]

    name = models.CharField(max_length=100, unique=True)
    category = models.ForeignKey(UomCategory, on_delete=models.CASCADE, related_name='uoms')
    type = models.CharField(max_length=20, choices=TYPE_CHOICES, default='reference')
    factor = models.DecimalField(
        max_digits=20, decimal_places=10,
        help_text="Factor to convert this UoM to the reference UoM. Example: 1 Kilogram = 1000 Gram → factor=0.001 for Gram"
    )
    precision = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    active = models.BooleanField(default=True)

    class Meta:
        unique_together = ('name', 'category')

    def __str__(self):
        return f"{self.name} "


class UomChangeLog(models.Model):
    ACTION_CHOICES = [
        ('create', 'Created'),
        ('update', 'Updated'),
        ('delete', 'Deleted'),
    ]

    uom = models.ForeignKey(UnitOfMeasure, on_delete=models.CASCADE, related_name='logs')
    action = models.CharField(max_length=10, choices=ACTION_CHOICES, default='update')
    field = models.CharField(max_length=100)
    old_value = models.CharField(max_length=255, null=True, blank=True)
    new_value = models.CharField(max_length=255)
    user = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.field} changed by {self.user} on {self.timestamp}"

    class Meta:
        verbose_name_plural = "UoM Change Logs"



class OtherAccount(models.Model):
    code = models.CharField(max_length=10, unique=True)  # Unique code for the account
    name = models.CharField(max_length=100, unique=True)  # Account name
    account_type = models.CharField(max_length=50)  # Type of the account (e.g., "Expense", "Revenue")

    def __str__(self):
        return f"{self.name} ({self.code})"

class Invoice(models.Model):
    INVOICE_TYPES = [
        ('purchase', 'Purchase Invoice'),
        ('return', 'Purchase Return'),
    ]
    
    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('posted', 'Posted'),
    ]
    
    DISCOUNT_TYPES = [
        ('percent', 'Percentage'),
        ('fixed', 'Fixed Amount'),
    ]
    USER_TYPES = [
        ('distributer', 'Distributer'),
        ('subdistributer', 'SubDistributer'),
        ('lco', 'LCO'),
    ]
    invoice_type = models.CharField(max_length=20, choices=INVOICE_TYPES, default='purchase')
    supplier = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='invoices')
    bill_date = models.DateField(null=True, blank=True)
    bill_number = models.CharField(max_length=50, null=True, blank=True,unique=True)
    invoice_date = models.DateField(null=True, blank=True)
    invoice_number = models.CharField(max_length=50, unique=True,blank=True, null=True)
    
    branch = models.ForeignKey(Branch, on_delete=models.SET_NULL, null=True, blank=True)
    warehouse = models.ForeignKey(Warehouse, on_delete=models.SET_NULL, null=True, blank=True)
    
    other_accounts = models.ManyToManyField(OtherAccount, blank=True)
    related_invoice = models.ForeignKey('self', on_delete=models.SET_NULL, null=True, blank=True, related_name='returns')
    
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    type = models.CharField(max_length=50,choices=USER_TYPES, default='lco', help_text="Type of user",blank=True, null=True)
    type_id = models.TextField(null=True, blank=True)
    
    bill_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    tax_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    discount_type = models.CharField(max_length=10, choices=DISCOUNT_TYPES, null=True, blank=True)
    discount_rate = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    other_amount_total = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    total_mrp = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    total_mrp_with_discount = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    grand_total = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    
    remarks = models.TextField(null=True, blank=True)
    currency = models.CharField(max_length=10, default='INR',null=True, blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    created_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, related_name='created_invoices')
    posted_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True, related_name='posted_invoices')
    
    class Meta:
        ordering = ['-invoice_date']
        indexes = [models.Index(fields=['invoice_number', 'supplier', 'invoice_type'])]
    
    def __str__(self):
        return f"{self.invoice_number} ({self.get_invoice_type_display()})"
    def save(self, *args, **kwargs):
        # Auto-generate invoice number only if posted and no number exists
        if self.status == 'posted' and not self.invoice_number:
            self.invoice_number = self.generate_invoice_number()
        super().save(*args, **kwargs)

    def generate_invoice_number(self):
        """
        Example: INV-YYYYMMDD-001
        You can customize the format as per your requirement.
        """
        from django.utils import timezone
        today = timezone.now().date()
        date_str = today.strftime('%Y%m%d')
        # Count invoices posted today to increment
        last_invoice = Invoice.objects.filter(
            invoice_number__startswith=f'INV-{date_str}'
        ).order_by('invoice_number').last()

        if last_invoice and last_invoice.invoice_number:
            last_number = int(last_invoice.invoice_number.split('-')[-1])
            new_number = last_number + 1
        else:
            new_number = 1

        return f'INV-{date_str}-{new_number:03d}'


class InvoiceLine(models.Model):
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, related_name='lines')
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='invoice_lines')
    hsn = models.CharField(max_length=20, null=True, blank=True)
    uom = models.ForeignKey(UnitOfMeasure, on_delete=models.SET_NULL, null=True, blank=True)
    batch = models.CharField(max_length=50, null=True, blank=True)
    
    purchase_rate = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    sales_rate = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    
    qty = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    free_qty = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    
    discount_percent = models.DecimalField(max_digits=5, decimal_places=2, default=0.00)
    discount_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)
    
    tax_percent = models.DecimalField(max_digits=5, decimal_places=2, default=0, blank=True, null=True)
    tax_amount = models.DecimalField(max_digits=15, decimal_places=2, default=0,blank=True, null=True)
    tax = models.ForeignKey(TaxRate, on_delete=models.SET_NULL, null=True, blank=True)

    line_total = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)  # after discount, before tax
    grand_total = models.DecimalField(max_digits=15, decimal_places=2, default=0.00)  # after tax

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['id']
        indexes = [
            models.Index(fields=['invoice', 'product']),
        ]

    def __str__(self):
        return f"{self.product.name} ({self.invoice.invoice_number})"

    def calculate_totals(self):
        """Compute totals based on purchase rate, quantity, manual discount, and tax."""

        base_amount = self.purchase_rate * self.qty

        # Use discount_amount directly from frontend (ignore discount_percent)
        discount = self.discount_amount or 0

        subtotal = base_amount - discount
        self.line_total = subtotal
        self.tax_amount = (subtotal * (self.tax_percent or 0)) / 100
        self.grand_total = subtotal + self.tax_amount

        return self.grand_total


    def save(self, *args, **kwargs):
        # Auto-calculate before saving
        self.calculate_totals()
        super().save(*args, **kwargs)


class StockOnProduct(models.Model):
    MOVEMENT_CHOICES = [
        ('in', 'Stock In'),
        ('out', 'Stock Out'),
    ]

    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, related_name='stock_movements')
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='stock_entries')
    batch = models.CharField(max_length=50, null=True, blank=True)
    warehouse = models.ForeignKey(Warehouse, on_delete=models.SET_NULL, null=True, blank=True)
    uom = models.ForeignKey(UnitOfMeasure, on_delete=models.SET_NULL, null=True, blank=True)

    movement_type = models.CharField(max_length=10, choices=MOVEMENT_CHOICES, default='in')
    qty = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    free_qty = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Stock Movement"
        verbose_name_plural = "Stock Movements"
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['product', 'batch', 'warehouse']),
        ]

    def __str__(self):
        direction = "IN" if self.movement_type == 'in' else "OUT"
        return f"{self.product.name} ({direction}) - {self.qty} {self.uom}"

    @property
    def signed_qty(self):
        """Return +qty for stock in, -qty for stock out."""
        return self.qty if self.movement_type == 'in' else -self.qty




class InvoiceTaxSummary(models.Model):
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, related_name='tax_summaries')
    tax = models.ForeignKey(TaxRate, on_delete=models.CASCADE)
    taxable_amount = models.DecimalField(max_digits=15, decimal_places=2)
    tax_amount = models.DecimalField(max_digits=15, decimal_places=2)
    class Meta:
        unique_together = ('invoice', 'tax')



    
class InvoiceLog(models.Model):
    ACTION_CREATE = "create"
    ACTION_UPDATE = "update"
    ACTION_DELETE = "delete"
    ACTION_CHOICES = (
        (ACTION_CREATE, "Create"),
        (ACTION_UPDATE, "Update"),
        (ACTION_DELETE, "Delete"),
    )

    invoice = models.ForeignKey(
        Invoice,   # replace 'yourapp' with the actual app name where Invoice model lives
        on_delete=models.CASCADE,
        related_name="change_logs",
        null=True,
        blank=True,
        help_text="Purchase Invoice this log row applies to (may be null for deleted records)."
    )

    action = models.CharField(max_length=10, choices=ACTION_CHOICES)

    if BuiltinJSONField:
        changes = BuiltinJSONField(null=True, blank=True)
        snapshot = BuiltinJSONField(null=True, blank=True)
        meta = BuiltinJSONField(null=True, blank=True)
    else:
        changes = models.TextField(null=True, blank=True, help_text="JSON string of changes")
        snapshot = models.TextField(null=True, blank=True, help_text="JSON snapshot")
        meta = models.TextField(null=True, blank=True, help_text="JSON meta")

    summary = models.CharField(max_length=400, blank=True, null=True)

    changed_by = models.ForeignKey(
        CustomUser,
        null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name="purchase_change_logs"
    )

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["invoice"]),
            models.Index(fields=["action"]),
        ]

    def __str__(self):
        return f"{self.get_action_display()} - Invoice#{self.invoice_id if self.invoice_id else 'n/a'} @ {self.created_at.isoformat()}"

    # helpers for TextField fallbacks
    def get_changes_dict(self):
        if BuiltinJSONField:
            return self.changes or {}
        try:
            return json.loads(self.changes) if self.changes else {}
        except Exception:
            return {}

    def set_changes_dict(self, d: dict):
        if BuiltinJSONField:
            self.changes = d
        else:
            self.changes = json.dumps(d, default=str)

    def set_snapshot_dict(self, d: dict):
        if BuiltinJSONField:
            self.snapshot = d
        else:
            self.snapshot = json.dumps(d, default=str)




from django.db.models import Sum, F
from django.db import transaction

def update_invoice_tax_summary(invoice):
    """
    Updates InvoiceTaxSummary based on the related InvoiceLine items.
    Groups by tax rate and sums taxable + tax amounts.
    """
    if not invoice.id:
        return

    # Clear any old summaries
    InvoiceTaxSummary.objects.filter(invoice=invoice).delete()

    # Group invoice lines by tax
    line_summary = (
        InvoiceLine.objects
        .filter(invoice=invoice)
        .values('tax')
        .annotate(
            taxable_amount=Sum(F('qty') * F('purchase_rate')),
            tax_amount=Sum(F('tax_amount'))
        )
        .order_by('tax')
    )

    # Create new tax summaries
    for entry in line_summary:
        tax_id = entry.get('tax')
        taxable = entry.get('taxable_amount') or 0
        tax_amt = entry.get('tax_amount') or 0
        if not tax_id:
            continue
        InvoiceTaxSummary.objects.create(
            invoice=invoice,
            tax_id=tax_id if tax_id else None,
            taxable_amount=taxable,
            tax_amount=tax_amt
        )
