# blog/urls.py
from django.urls import path
from . import views
from django.contrib.auth import views as auth_view


app_name = 'employee'  

urlpatterns = [
    # ledgeraccount
    path('employee_list', views.employee_list, name='employee_list'),
    path('employee_create', views.employee_create, name='employee_create'),
    path('<int:emp_id>/delete/', views.employee_delete, name='employee_delete'),
    path("<int:employee_id>/edit/", views.employee_edit, name="employee_edit"),


    path('branch_list', views.branch_list, name='branch_list'),
    path('branch_create', views.branch_create, name='branch_create'),
    path('branch/<int:pk>/edit/', views.branch_edit, name='branch_edit'),


    path('positions/list-ajax/', views.list_positions_ajax, name='list_positions_ajax'),
    path('positions/create-ajax/', views.create_position_ajax, name='create_position_ajax'),
    path('positions/update-ajax/', views.update_position_ajax, name='update_position_ajax'),

    # Departments
    path('departments/list-ajax/', views.list_departments_ajax, name='list_departments_ajax'),
    path('departments/create-ajax/', views.create_department_ajax, name='create_department_ajax'),
    path('departments/update-ajax/', views.update_department_ajax, name='update_department_ajax'),
    path('api/branches/', views.get_branches_by_lco, name='get_branches_by_lco'),


    path('ajax/marital-status/list/', views.list_marital_status_ajax, name='list_marital_status_ajax'),
    path('ajax/marital-status/create/', views.create_marital_status_ajax, name='create_marital_status_ajax'),
    path('ajax/marital-status/update/', views.update_marital_status_ajax, name='update_marital_status_ajax'),



]   


