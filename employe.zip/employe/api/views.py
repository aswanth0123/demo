from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated  # change to AllowAny for open endpoint
from rest_framework.parsers import JSONParser, MultiPartParser, FormParser
from django.db import transaction
import re
from employe.models import Employee
from .serializers import EmployeeSerializer
# employe/api/views.py  (append)
import re
import pprint
import traceback
import logging
from LCO.models import LCO
from django.db import transaction, IntegrityError
from django.shortcuts import get_object_or_404

from rest_framework import status, serializers as drf_serializers
from rest_framework.parsers import JSONParser, MultiPartParser, FormParser
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.generics import GenericAPIView

# adjust these imports to your app structure
from .serializers import EmployeeSerializer
from employe.models import Employee, JobPosition, Department, Branch
import re
import json
logger = logging.getLogger(__name__)
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated  # keep consistent with other endpoints
from .serializers import BranchListSerializer, DepartmentListSerializer, JobPositionListSerializer
from employe.models import Branch, Department, JobPosition
from django.contrib.auth import get_user_model
User = get_user_model()



# If you want these open during development, change IsAuthenticated -> AllowAny
def _simplify_errors(errors):
    """
    Recursively simplify serializer error structures to single strings per field
    or a dict of first messages.
    """
    if isinstance(errors, dict):
        return {k: _simplify_errors(v) for k, v in errors.items()}
    if isinstance(errors, (list, tuple)):
        if not errors:
            return ""
        return _simplify_errors(errors[0])
    return str(errors)


def _extract_message(simplified_errors):
    """
    Prefer non_field_errors, otherwise first field message, otherwise string.
    Returns a single human-friendly string.
    """
    if not simplified_errors:
        return "An unknown error occurred."
    if isinstance(simplified_errors, str):
        return simplified_errors
    if isinstance(simplified_errors, dict):
        if 'non_field_errors' in simplified_errors:
            return str(simplified_errors['non_field_errors']) or "An error occurred."
        for v in simplified_errors.values():
            if v:
                return str(v)
        return "An error occurred."
    if isinstance(simplified_errors, (list, tuple)) and simplified_errors:
        return str(simplified_errors[0])
    return str(simplified_errors)


def _flatten_error_messages(self_or_errors):
    msgs = []
    errors = self_or_errors
    if errors is None:
        return msgs
    if isinstance(errors, dict):
        for v in errors.values():
            msgs.extend(_flatten_error_messages(v))
        return msgs
    if isinstance(errors, (list, tuple)):
        for item in errors:
            msgs.extend(_flatten_error_messages(item))
        return msgs
    try:
        msgs.append(str(errors))
    except Exception:
        msgs.append("An error occurred.")
    return msgs


def _combine_messages_into_sentence(errors):
    flat = _flatten_error_messages(errors)
    normalized = [m.strip() for m in flat if isinstance(m, str) and m.strip()]
    seen = set()
    ordered = []
    for m in normalized:
        if m not in seen:
            seen.add(m)
            ordered.append(m)
    if not ordered:
        return "An unknown error occurred."
    parts = [p.rstrip(".! ") for p in ordered]
    sentence = ". ".join(parts)
    if not sentence.endswith("."):
        sentence = sentence + "."
    return sentence


# ----------------- request redaction for safe printing -----------------
_REDACT_KEYS = {"password", "confirm_password", "confirmPassword", "token", "access_token", "refresh_token"}


def _redact_request_preview(d: dict):
    out = {}
    for k, v in (d or {}).items():
        if k in _REDACT_KEYS:
            out[k] = "***REDACTED***"
        else:
            out[k] = v
    return out


# ----------------- friendly DB integrity messages -----------------
_DUPLICATE_KEY_RE = re.compile(r"Key \((?P<col>[\w_]+)\)=\(", re.IGNORECASE)
_CONSTRAINT_RE = re.compile(r'constraint "(?P<constraint>[^"]+)"', re.IGNORECASE)


def _friendly_from_integrity_error(integ: IntegrityError) -> str:
    """
    Convert DB IntegrityError into a short non-leaking message.
    """
    try:
        cause = getattr(integ, "__cause__", None)
        if cause is not None:
            diag = getattr(cause, "diag", None)
            if diag is not None:
                constraint = getattr(diag, "constraint_name", None)
                if constraint:
                    lc = constraint.lower()
                    if "username" in lc:
                        return "Username already exists."
                    if "email" in lc:
                        return "Email already exists."
                    if "employee_id" in lc or "employeeemployeeid" in lc:
                        return "Employee ID already exists."
    except Exception:
        pass

    text = str(integ) or ""
    low = text.lower()

    m = _DUPLICATE_KEY_RE.search(text)
    if m:
        col = m.group("col").lower()
        if col in ("username", "user_name"):
            return "Username already exists."
        if "email" in col:
            return "Email already exists."
        if col in ("employee_id", "employeeid", "empid"):
            return "Employee ID already exists."
        return f"{col.replace('_', ' ').capitalize()} already exists."

    m2 = _CONSTRAINT_RE.search(text)
    if m2:
        constraint = m2.group("constraint").lower()
        if "username" in constraint:
            return "Username already exists."
        if "email" in constraint:
            return "Email already exists."
        if "employee_id" in constraint or "employeeemployeeid" in constraint.replace('.', ''):
            return "Employee ID already exists."

    if "username" in low and ("duplicate" in low or "already exists" in low or "violates" in low):
        return "Username already exists."
    if "email" in low and ("duplicate" in low or "already exists" in low or "violates" in low):
        return "Email already exists."
    if "employee_id" in low or "employee id" in low:
        return "Employee ID already exists."

    return "A record with a duplicate value already exists."


# ----------------- coercion helpers for multipart/form-data related fields -----------------

def _coerce_related_value(raw):
    """
    Coerce a variety of incoming formats into:
      - int (PK) when possible
      - a parsed dict if JSON string parsed to dict (the serializer may accept FlexibleRelatedField)
      - None if blank
    Handles:
      - list/tuple -> takes first element
      - dict with 'value' -> returns value coerced to int if numeric string
      - JSON string like '{"label":"X","value":6}' -> returns 6 (or the parsed dict)
      - numeric string -> int
      - string '[object Object]' -> raise ValueError (frontend bug)
    """
    if raw is None:
        return None

    # If DRF gave us a list (common with multipart/form-data), use the first element
    if isinstance(raw, (list, tuple)) and raw:
        raw = raw[0]

    # dicts
    if isinstance(raw, dict):
        if 'value' in raw:
            v = raw['value']
            if isinstance(v, str) and v.strip().isdigit():
                return int(v.strip())
            return v
        return raw

    # ints
    if isinstance(raw, int):
        return raw

    # strings
    if isinstance(raw, str):
        s = raw.strip()
        if s == '[object Object]':
            raise ValueError("Frontend sent '[object Object]' for a related field. Send the numeric PK (e.g. department.value) or JSON.stringify(theObject).")
        # numeric string
        if s.isdigit():
            return int(s)
        # JSON encoded object
        if (s.startswith('{') and s.endswith('}')) or (s.startswith('[') and s.endswith(']')):
            try:
                parsed = json.loads(s)
            except json.JSONDecodeError:
                # not valid JSON -> return raw string (serializer will error)
                return s
            # if parsed is dict with 'value'
            if isinstance(parsed, dict) and 'value' in parsed:
                v = parsed['value']
                if isinstance(v, str) and v.strip().isdigit():
                    return int(v.strip())
                return v
            # if parsed is int
            if isinstance(parsed, int):
                return parsed
            # return parsed structure (dict/list)
            return parsed
        # otherwise return string as-is (serializer will show field error)
        return s

    # fallback
    return raw





def _take_first(raw):
    """If raw is a list-like, return first element, else return raw unchanged."""
    if isinstance(raw, (list, tuple)) and raw:
        return raw[0]
    return raw


def _map_request_to_serializer(raw_data):
    """
    Map incoming frontend JSON / multipart/form-data shapes into serializer-friendly fields.

    - Parses label/value objects (dicts or JSON-strings) for country/state/district
      and returns the label (as plain string). If label absent, falls back to value coerced to string.
    - Writes both 'country' (for serializer with source='nationality') and legacy 'nationality'.
    - Emergency contact: optional, but if provided must be exactly 10 digits (non-digits stripped).
    - Image handling unchanged from your prior implementation.
    - NEW: Accepts 'lco' in many shapes: int, numeric string, dict with 'id'/'value'/'pk', JSON-string of dict,
      or keys like 'lcoId' / 'lco_id' / 'lcoObject'. The returned mapped['lco'] will be an int PK or None.
    """
    mapped = {}

    mapped['employee_name'] = _take_first(
        raw_data.get('name') or raw_data.get('employee_name') or raw_data.get('employeeName')
    )
    mapped['email'] = _take_first(
        raw_data.get('email') or raw_data.get('emailAddress') or raw_data.get('workEmail') or raw_data.get('work_email')
    )

    # ---------- Helper to parse label/value objects ----------
    def _extract_label_or_value(raw):
        """
        Accepts dict, JSON-string like '{"label":"India","value":101}', plain string, or numeric.
        Returns:
          - label (preferred) as a plain string,
          - else value coerced to string,
          - else None.
        Treats "", "null", "none", "undefined" (case-insensitive) as None.
        """
        if raw is None:
            return None

        if isinstance(raw, dict):
            label = raw.get('label')
            if label not in (None, ''):
                return str(label).strip()
            val = raw.get('value')
            return str(val).strip() if val not in (None, '') else None

        if isinstance(raw, str):
            s = raw.strip()
            if s == '':
                return None
            low = s.lower()
            if low in ("null", "none", "undefined"):
                return None
            if s.startswith('{') and s.endswith('}'):
                try:
                    obj = json.loads(s)
                    if isinstance(obj, dict):
                        label = obj.get('label')
                        if label not in (None, ''):
                            return str(label).strip()
                        val = obj.get('value')
                        return str(val).strip() if val not in (None, '') else None
                except Exception:
                    # not valid JSON; fall back to returning the raw string (unless it's a placeholder)
                    pass
            return s

        try:
            return str(raw)
        except Exception:
            return None

    # --------------------------------------------------------

    # nationality / country
    raw_nat = raw_data.get('nationality') if 'nationality' in raw_data else (raw_data.get('country') or raw_data.get('countryName') or raw_data.get('nationalityName'))
    nat_val = None
    if raw_nat not in (None, ''):
        try:
            nat_val = _take_first(raw_nat)
        except Exception:
            nat_val = raw_nat
    country_label = _extract_label_or_value(nat_val)
    mapped['country'] = country_label
    mapped['nationality'] = country_label

    # state
    raw_state = raw_data.get('state') or raw_data.get('stateName')
    state_val = None
    if raw_state not in (None, ''):
        try:
            state_val = _take_first(raw_state)
        except Exception:
            state_val = raw_state
    mapped['state'] = _extract_label_or_value(state_val)

    mapped['city'] = _take_first(raw_data.get('city'))
    mapped['address_line1'] = _take_first(raw_data.get('address') or raw_data.get('address_line1'))

    # district
    raw_district = raw_data.get('district') or raw_data.get('districtName') or raw_data.get('districts')
    district_val = None
    if raw_district not in (None, ''):
        try:
            district_val = _take_first(raw_district)
        except Exception:
            district_val = raw_district
    mapped['district'] = _extract_label_or_value(district_val)

    gender = raw_data.get('gender')
    if gender:
        mapped['gender'] = str(_take_first(gender)).strip().lower()

    mapped['date_of_birth'] = _take_first(raw_data.get('dateOfBirth') or raw_data.get('date_of_birth'))
    mapped['marital_status'] = (
        str(_take_first(raw_data.get('maritalStatus') or raw_data.get('marital_status') or '')).strip().lower()
    )

    # Emergency contact
    emg_raw = raw_data.get('emgPhone') or raw_data.get('emergency_contact') or None
    if emg_raw not in (None, '', []):
        try:
            emg_val = _take_first(emg_raw)
        except Exception:
            emg_val = emg_raw
        emg_digits = re.sub(r'\D', '', str(emg_val or ''))
        if emg_digits == '':
            mapped['emergency_contact'] = None
        else:
            if len(emg_digits) != 10:
                raise ValueError("Invalid Emergency contact number. It must contain exactly 10 digits.")
            mapped['emergency_contact'] = emg_digits
    else:
        mapped['emergency_contact'] = None

    mapped['emergency_contact_name'] = _take_first(
        raw_data.get('emgContactName') or raw_data.get('emergency_contact_name')
    )

    mapped['visa_number'] = _take_first(raw_data.get('passportNo') or raw_data.get('visaNumber') or raw_data.get('visa_number'))
    visa_exp = _take_first(raw_data.get('visaExpDate') or raw_data.get('visa_expiry_date'))
    if visa_exp not in (None, '', []):
        mapped['visa_expiry_date'] = visa_exp

    # PINCODE
    pincode_raw = raw_data.get('pinCode') or raw_data.get('pincode')
    if pincode_raw not in (None, ''):
        pincode_val = _take_first(pincode_raw)
        pincode_str = str(pincode_val).strip()
        if not re.match(r'^[1-9][0-9]{5}$', pincode_str):
            raise ValueError("Invalid Pincode .")
        mapped['pincode'] = pincode_str

    mapped['work_mobile'] = _take_first(raw_data.get('mobile') or raw_data.get('workMobile') or raw_data.get('work_mobile'))
    mapped['work_email'] = _take_first(raw_data.get('workEmail') or raw_data.get('work_email'))
    mapped['work_location'] = _take_first(
        raw_data.get('workLocation') or raw_data.get('work_location') or raw_data.get('workLocation')
    )

    mapped['employee_id'] = _take_first(raw_data.get('employeeId') or raw_data.get('employee_id'))

    # ----------------- IMAGE HANDLING -----------------
    raw_image = raw_data.get('image') if 'image' in raw_data else raw_data.get('photo')
    image_val = None
    try:
        image_val = _take_first(raw_image)
    except Exception:
        image_val = None

    if image_val is None:
        mapped['image'] = None
    else:
        if isinstance(image_val, str):
            s = image_val.strip().lower()
            if s in ("", "null", "none", "undefined"):
                mapped['image'] = None
            else:
                mapped['image'] = None
        else:
            if isinstance(image_val, (InMemoryUploadedFile, TemporaryUploadedFile, UploadedFile)) or hasattr(image_val, 'read'):
                mapped['image'] = image_val
            else:
                mapped['image'] = None

    mapped['password'] = raw_data.get('password')
    mapped['confirm_password'] = raw_data.get('confirmPassword') or raw_data.get('confirm_password')

    # ----------------- related fields (reuse your _coerce_related_value if present) -----------------
    try:
        mapped['job_position'] = _coerce_related_value(raw_data.get('position') or raw_data.get('job_position'))
        mapped['department'] = _coerce_related_value(raw_data.get('department'))
        mapped['branch'] = _coerce_related_value(raw_data.get('branch'))
        mapped['manager'] = _coerce_related_value(raw_data.get('manager'))
    except NameError:
        # fallback implementation if _coerce_related_value is not available in this module
        def _coerce_pk_like(raw):
            if raw is None:
                return None
            if isinstance(raw, int):
                return raw
            if isinstance(raw, dict):
                for k in ("id", "value", "pk"):
                    v = raw.get(k)
                    if v not in (None, ""):
                        try:
                            return int(v)
                        except Exception:
                            pass
                return None
            if isinstance(raw, str):
                s = raw.strip()
                if s == "":
                    return None
                if s.startswith('{') and s.endswith('}'):
                    try:
                        obj = json.loads(s)
                        if isinstance(obj, dict):
                            return _coerce_pk_like(obj)
                    except Exception:
                        pass
                if s.isdigit():
                    try:
                        return int(s)
                    except Exception:
                        pass
                m = re.search(r"(\d+)$", s)
                if m:
                    try:
                        return int(m.group(1))
                    except Exception:
                        pass
            return None

        mapped['job_position'] = _coerce_pk_like(raw_data.get('position') or raw_data.get('job_position'))
        mapped['department'] = _coerce_pk_like(raw_data.get('department'))
        mapped['branch'] = _coerce_pk_like(raw_data.get('branch'))
        mapped['manager'] = _coerce_pk_like(raw_data.get('manager'))

    # ----------------- NEW: LCO handling -----------------
    # Accept many shapes for LCO; prefer explicit keys: lco, lcoId, lco_id, lcoObject
    lco_candidates = (
        raw_data.get('lco'),
        raw_data.get('lcoId'),
        raw_data.get('lco_id'),
        raw_data.get('lcoObject'),
        raw_data.get('lcoData'),
    )
    lco_raw = None
    for cand in lco_candidates:
        if cand is not None:
            lco_raw = cand
            break

    # helper same as fallback above (or use _coerce_related_value if available)
    def _coerce_pk_like_local(raw):
        if raw is None:
            return None
        if isinstance(raw, int):
            return raw
        if isinstance(raw, dict):
            for k in ("id", "value", "pk"):
                v = raw.get(k)
                if v not in (None, ""):
                    try:
                        return int(v)
                    except Exception:
                        pass
            # maybe nested label/value
            # nothing matched -> try to find numeric-like attributes
            for v in raw.values():
                try:
                    return int(v)
                except Exception:
                    continue
            return None
        if isinstance(raw, str):
            s = raw.strip()
            if s == "":
                return None
            if s.startswith('{') and s.endswith('}'):
                try:
                    obj = json.loads(s)
                    if isinstance(obj, dict):
                        return _coerce_pk_like_local(obj)
                except Exception:
                    pass
            if s.isdigit():
                try:
                    return int(s)
                except Exception:
                    pass
            m = re.search(r"(\d+)$", s)
            if m:
                try:
                    return int(m.group(1))
                except Exception:
                    pass
        return None

    # Try to use existing _coerce_related_value if available (keeps behaviour consistent)
    try:
        lco_val = None
        if lco_raw is not None:
            try:
                # _coerce_related_value may raise ValueError for bad shapes; bubble up
                lco_val = _coerce_related_value(lco_raw)
            except Exception:
                # fallback to local coercion
                lco_val = _coerce_pk_like_local(_take_first(lco_raw) if hasattr(lco_raw, '__iter__') and not isinstance(lco_raw, (str, bytes)) else lco_raw)
        else:
            lco_val = None
        mapped['lco'] = lco_val
    except NameError:
        mapped['lco'] = _coerce_pk_like_local(_take_first(lco_raw) if lco_raw is not None else None)

    # ensure emails lowercased
    if mapped.get('email'):
        mapped['email'] = str(mapped['email']).strip().lower()
    if mapped.get('work_email'):
        mapped['work_email'] = str(mapped['work_email']).strip().lower()

    return mapped






# ----------------- Create API -----------------

from django.conf import settings
from employe.models import Employee, EmployeeChangeLog
from django.utils import timezone

class EmployeeCreateAPIView(APIView):
    """
    POST /employe/create/ (or similar)

    Accepts `lco` optionally in multiple shapes:
      - lco: 10
      - lco: "10"
      - lco: {"id": 10, "name": "..."}
      - lco: '{"id":10,"name":"..."}'
    If lco missing it's treated as null (optional).
    After successful create, an EmployeeChangeLog row is created recording the creation.
    """
    permission_classes = [IsAuthenticated]
    parser_classes = [JSONParser, MultiPartParser, FormParser]

    def _snapshot_employee_for_log(self, instance, fields=None, redact=None):
        if fields is None:
            fields = [
                "employee_id", "employee_name", "email", "nationality", "state", "district",
                "city", "address_line1", "gstin", "gender", "date_of_birth", "marital_status",
                "emergency_contact_name", "emergency_contact", "visa_number", "visa_expiry_date",
                "pincode", "job_position_id", "work_mobile", "work_email", "work_location",
                "department_id", "branch_id", "manager_id", "lco_id", "aadhaar_number"
            ]
        redact_set = set(redact or getattr(settings, "SENSITIVE_LOG_FIELDS", ["aadhaar_number"]))
        out = {}
        for f in fields:
            try:
                if f.endswith("_id"):
                    rel_name = f[:-3]
                    rel_obj = getattr(instance, rel_name, None)
                    val = getattr(rel_obj, "pk", None) if rel_obj is not None else None
                else:
                    val = getattr(instance, f, None)
            except Exception:
                val = None
            try:
                if hasattr(val, "isoformat"):
                    val = val.isoformat()
            except Exception:
                pass
            if f in redact_set and val not in (None, ""):
                out[f] = "******"
            else:
                out[f] = val
        return out

    def post(self, request, *args, **kwargs):
        print("=== EMPLOYEE CREATE START ===")
        try:
            request_preview = dict(request.data)
        except Exception:
            request_preview = str(request.data)
        print("Raw request.data preview (redacted):")
        try:
            print(pprint.pformat(request_preview))
        except Exception:
            print(str(request_preview))

        # Map frontend request to serializer-ready payload
        try:
            # You likely have an existing mapping helper in your codebase.
            # _map_request_to_serializer should convert request field names to serializer field names.
            mapped = _map_request_to_serializer(request.data)
        except Exception as ve:
            msg = str(ve)
            print("Coercion error:", msg)
            return Response({"status": "error", "errors": {"message": msg}}, status=drf_status.HTTP_400_BAD_REQUEST)

        # ---- COERCE LCO: accept dict/json-string or scalar id ----
        try:
            lco_val = mapped.get('lco', None)
            if lco_val is not None:
                # dict with id
                if isinstance(lco_val, dict):
                    mapped['lco'] = lco_val.get('id') or lco_val.get('value')
                elif isinstance(lco_val, str):
                    s = lco_val.strip()
                    # JSON string?
                    if s.startswith('{') and s.endswith('}'):
                        try:
                            obj = json.loads(s)
                            if isinstance(obj, dict):
                                mapped['lco'] = obj.get('id') or obj.get('value') or mapped.get('lco')
                        except Exception:
                            # leave original string
                            pass
                    else:
                        # numeric string -> int
                        if s.isdigit():
                            mapped['lco'] = int(s)
                # ints left as-is
        except Exception:
            logger.exception("Error coercing lco field from mapped payload")

        print("Mapped payload for serializer (redacted):")
        try:
            print(pprint.pformat(mapped))
        except Exception:
            print(str(mapped))

        # If client provided employee_id, ensure it does not already exist.
        provided_eid = mapped.get('employee_id')
        if provided_eid:
            try:
                provided_eid_str = str(provided_eid).strip()
            except Exception:
                provided_eid_str = provided_eid
            if Employee.objects.filter(employee_id__iexact=provided_eid_str).exists():
                print("DEBUG: Provided employee_id already exists:", provided_eid_str)
                return Response({
                    "status": "error",
                    "errors": {"message": "EmployeeId already exists."}
                }, status=drf_status.HTTP_409_CONFLICT)
            mapped['employee_id'] = provided_eid_str

        # Debug: inspect related-field raw values
        related_fields = ['job_position', 'department', 'branch', 'manager', 'lco']
        for field in related_fields:
            raw_value = mapped.get(field, None)
            print(f"DEBUG related field '{field}': value={raw_value!r} type={type(raw_value).__name__}")

        # Pre-check for email duplicates (friendly early error)
        incoming_email = mapped.get('email')
        if incoming_email:
            email_l = str(incoming_email).strip().lower()
            if Employee.objects.filter(email__iexact=email_l).exists():
                return Response({"status": "error", "errors": {"message": "An employee with this email already exists."}}, status=drf_status.HTTP_409_CONFLICT)
            if User.objects.filter(email__iexact=email_l).exists():
                return Response({"status": "error", "errors": {"message": "A user with this email already exists in auth table."}}, status=drf_status.HTTP_409_CONFLICT)

        # Validate with serializer
        serializer = EmployeeSerializer(data=mapped)
        if not serializer.is_valid():
            print("DEBUG serializer.is_valid() returned False. serializer.errors:")
            try:
                print(pprint.pformat(serializer.errors))
            except Exception:
                print(str(serializer.errors))
            combined = _combine_messages_into_sentence(serializer.errors) if "_combine_messages_into_sentence" in globals() else _first_error_message(serializer.errors)
            return Response({
                "status": "error",
                "errors": {"message": combined, "fields": serializer.errors}
            }, status=drf_status.HTTP_400_BAD_REQUEST)

        # Attempt create inside atomic transaction and create change log
        try:
            with transaction.atomic():
                employee = serializer.save()

                # generate snapshot and create EmployeeChangeLog row
                try:
                    snapshot = self._snapshot_employee_for_log(employee)
                except Exception:
                    snapshot = {}

                # build changes payload: old = None, new = snapshot field value
                changes_payload = {k: {"old": None, "new": v} for k, v in (snapshot or {}).items()}

                meta = {"created_at": timezone.now().isoformat()}
                try:
                    meta["remote_addr"] = request.META.get("REMOTE_ADDR")
                    meta["user_agent"] = request.META.get("HTTP_USER_AGENT")
                except Exception:
                    pass

                try:
                    EmployeeChangeLog.objects.create(
                        employee=employee,
                        changed_by=(request.user if getattr(request, "user", None) and request.user.is_authenticated else None),
                        action=EmployeeChangeLog.ACTION_CREATE,
                        changes=changes_payload,
                        summary=f"Created employee {employee.employee_name or employee.pk}",
                        meta=meta
                    )
                except Exception as e:
                    # Logging failure should not break create
                    logger.exception("Failed to write EmployeeChangeLog: %s", e)
                    traceback.print_exc()

            print("Employee created pk=%s employee_id=%s" % (employee.pk, employee.employee_id))
            return Response({
                "status": "success",
                "detail": "Employee created successfully.",
                "employee": EmployeeSerializer(employee).data
            }, status=drf_status.HTTP_201_CREATED)

        except serializers.ValidationError as valerr:
            combined = _first_error_message(valerr.detail) if "_first_error_message" in globals() else str(valerr.detail)
            return Response({"status": "error", "errors": {"message": combined}}, status=drf_status.HTTP_400_BAD_REQUEST)

        except IntegrityError as integ:
            logger.exception("IntegrityError during create: %s", integ)
            friendly = _friendly_from_integrity_error(integ) if "_friendly_from_integrity_error" in globals() else "Integrity error while creating employee."
            return Response({"status": "error", "errors": {"message": friendly}}, status=drf_status.HTTP_400_BAD_REQUEST)

        except Exception as exc:
            logger.exception("Unexpected exception during employee create: %s", exc)
            traceback.print_exc()
            return Response({"status": "error", "errors": {"message": "An unexpected error occurred. Please try again later."}}, status=drf_status.HTTP_500_INTERNAL_SERVER_ERROR)




from datetime import datetime
from io import IOBase
def _is_file_like(obj):
    """Return True if obj is an UploadedFile or file-like (has read)."""
    if obj is None:
        return False
    if isinstance(obj, (InMemoryUploadedFile, TemporaryUploadedFile, UploadedFile)):
        return True
    # file-like object (io.BytesIO, open file, etc.)
    if isinstance(obj, IOBase) or hasattr(obj, "read"):
        return True
    return False

# ----------------- Update by employee_id API -----------------
from rest_framework import status as drf_status, serializers as drf_serializers


def _try_parse_date_to_iso(s):
    """
    Try parsing common date formats and return ISO 'YYYY-MM-DD' string.
    Raises ValueError if parsing fails.
    """
    if s is None:
        raise ValueError("Invalid visa expiry date format. Use YYYY-MM-DD.")
    s_str = str(s).strip()
    if s_str == "":
        raise ValueError("Invalid visa expiry date format. Use YYYY-MM-DD.")

    # already ISO-like
    if re.match(r'^\d{4}-\d{2}-\d{2}$', s_str):
        return s_str

    formats = ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%m/%d/%Y", "%Y/%m/%d")
    for fmt in formats:
        try:
            dt = datetime.strptime(s_str, fmt)
            return dt.strftime("%Y-%m-%d")
        except Exception:
            pass

    # try YYYYMMDD
    if re.match(r'^\d{8}$', s_str):
        try:
            dt = datetime.strptime(s_str, "%Y%m%d")
            return dt.strftime("%Y-%m-%d")
        except Exception:
            pass

    raise ValueError("Invalid visa expiry date format. Use YYYY-MM-DD.")


import json
import re
# (keep your other imports)
def _map_request_to_serializer_partial(raw_data):
    """
    Map request shapes into serializer-friendly fields for PARTIAL updates.
    Preserves your original behavior and includes robust LCO coercion that
    handles JSON-like strings with invalid JSON numbers such as {"id": 09, ...}.
    """
    import json
    import re

    mapped = {}

    def _present(key):
        try:
            return key in raw_data
        except Exception:
            try:
                return raw_data.get(key, None) is not None
            except Exception:
                return False

    def _first_of(*keys):
        for k in keys:
            if _present(k):
                return _take_first(raw_data.get(k))
        return None

    def _is_placeholder_string(val):
        return val is None or (isinstance(val, str) and val.strip().lower() in ("", "null", "none", "undefined"))

    def _extract_label_str(raw):
        """Return label or value string from dict/JSON-string or plain string."""
        if raw is None:
            return None
        if isinstance(raw, dict):
            label = raw.get('label')
            if label not in (None, ''):
                return str(label).strip()
            val = raw.get('value')
            return str(val).strip() if val not in (None, '') else None
        if isinstance(raw, str):
            s = raw.strip()
            if s == '':
                return None
            low = s.lower()
            if low in ("null", "none", "undefined"):
                return None
            if s.startswith('{') and s.endswith('}'):
                try:
                    obj = json.loads(s)
                    if isinstance(obj, dict):
                        label = obj.get('label')
                        if label not in (None, ''):
                            return str(label).strip()
                        val = obj.get('value')
                        return str(val).strip() if val not in (None, '') else None
                except Exception:
                    pass
            return s
        try:
            return str(raw)
        except Exception:
            return None

    # ---------------- basic scalar fields ----------------
    if _present('name') or _present('employee_name') or _present('employeeName'):
        mapped['employee_name'] = _first_of('name', 'employee_name', 'employeeName')

    if _present('email') or _present('emailAddress') or _present('workEmail') or _present('work_email'):
        mapped['email'] = _first_of('email', 'emailAddress', 'workEmail', 'work_email')

    # ---------- nationality / country (present-only) ----------
    if _present('nationality') or _present('country') or _present('countryName') or _present('nationalityName'):
        raw_nat = _first_of('nationality', 'country', 'countryName', 'nationalityName')
        if _is_placeholder_string(raw_nat):
            mapped['country'] = None
            mapped['nationality'] = None
        else:
            parsed = _extract_label_str(raw_nat)
            mapped['country'] = parsed
            mapped['nationality'] = parsed

    # ---------- state (present-only) ----------
    if _present('state') or _present('stateName'):
        raw_state = _first_of('state', 'stateName')
        if _is_placeholder_string(raw_state):
            mapped['state'] = None
        else:
            mapped['state'] = _extract_label_str(raw_state)

    if _present('city'):
        mapped['city'] = _first_of('city')

    if _present('address') or _present('address_line1'):
        mapped['address_line1'] = _first_of('address', 'address_line1')

    # District (present-only)
    if _present('district') or _present('districtName') or _present('districts'):
        raw_district = _first_of('district', 'districtName', 'districts')
        if _is_placeholder_string(raw_district):
            mapped['district'] = None
        else:
            mapped['district'] = _extract_label_str(raw_district)

    if _present('gender'):
        g = _first_of('gender')
        mapped['gender'] = (str(_take_first(g)).strip().lower() if g is not None else None)

    if _present('dateOfBirth') or _present('date_of_birth'):
        mapped['date_of_birth'] = _first_of('dateOfBirth', 'date_of_birth')

    if _present('maritalStatus') or _present('marital_status'):
        v = _first_of('maritalStatus', 'marital_status')
        mapped['marital_status'] = (str(_take_first(v)).strip().lower()) if v is not None else None

    # ---------- Emergency contact (present-only) ----------
    if _present('emgPhone') or _present('emergency_contact'):
        emg_raw = _first_of('emgPhone', 'emergency_contact')
        if _is_placeholder_string(emg_raw):
            mapped['emergency_contact'] = None
        else:
            emg_val = _take_first(emg_raw)
            emg_digits = re.sub(r'\D', '', str(emg_val or ''))
            if emg_digits == '':
                mapped['emergency_contact'] = None
            else:
                if len(emg_digits) != 10:
                    raise ValueError("Invalid Emergency contact number. It must contain exactly 10 digits.")
                mapped['emergency_contact'] = emg_digits

    if _present('emgContactName') or _present('emergency_contact_name'):
        mapped['emergency_contact_name'] = _first_of('emgContactName', 'emergency_contact_name')

    # ---------------- Visa fields (optional) ----------------
    if _present('passportNo') or _present('visaNumber') or _present('visa_number'):
        visa_raw = _first_of('passportNo', 'visaNumber', 'visa_number')
        if _is_placeholder_string(visa_raw):
            mapped['visa_number'] = None
        else:
            mapped['visa_number'] = visa_raw

    if _present('visaExpDate') or _present('visa_expiry_date'):
        visa_exp_raw = _first_of('visaExpDate', 'visa_expiry_date')
        if _is_placeholder_string(visa_exp_raw):
            mapped['visa_expiry_date'] = None
        else:
            mapped['visa_expiry_date'] = _try_parse_date_to_iso(visa_exp_raw)

    # ---------- PINCODE ----------
    if _present('pinCode') or _present('pincode'):
        p_raw = _first_of('pinCode', 'pincode')
        if p_raw in (None, '') or (isinstance(p_raw, str) and p_raw.strip().lower() in ("", "null", "none", "undefined")):
            raise ValueError("Invalid Pincode .")
        p_val = _take_first(p_raw)
        p_str = str(p_val).strip()
        if not re.match(r'^[1-9][0-9]{5}$', p_str):
            raise ValueError("Invalid Pincode .")
        mapped['pincode'] = p_str

    # work fields
    if _present('mobile') or _present('workMobile') or _present('work_mobile'):
        mapped['work_mobile'] = _first_of('mobile', 'workMobile', 'work_mobile')
    if _present('workEmail') or _present('work_email'):
        mapped['work_email'] = _first_of('workEmail', 'work_email')
    if _present('workLocation') or _present('work_location'):
        mapped['work_location'] = _first_of('workLocation', 'work_location')

    # employee_id
    if _present('employeeId') or _present('employee_id'):
        mapped['employee_id'] = _first_of('employeeId', 'employee_id')

    # ----------------- IMAGE handling (present-only if actual file) -----------------
    image_key_present = _present('image') or _present('photo')
    if image_key_present:
        raw_image = raw_data.get('image') if _present('image') else raw_data.get('photo')
        try:
            image_val = _take_first(raw_image)
        except Exception:
            image_val = None

        if _is_file_like(image_val):
            mapped['image'] = image_val
        else:
            if _is_placeholder_string(image_val):
                mapped['image'] = None

    # ---------------- password fields (present-only) ----------------
    if _present('password'):
        mapped['password'] = raw_data.get('password')
    if _present('confirmPassword') or _present('confirm_password'):
        mapped['confirm_password'] = raw_data.get('confirmPassword') or raw_data.get('confirm_password')

    # --------------- related fields: coerce only if present ---------------
    try:
        if _present('position') or _present('job_position'):
            mapped['job_position'] = _coerce_related_value(raw_data.get('position') or raw_data.get('job_position'))
        if _present('department'):
            mapped['department'] = _coerce_related_value(raw_data.get('department'))
        if _present('branch'):
            mapped['branch'] = _coerce_related_value(raw_data.get('branch'))
        if _present('manager'):
            mapped['manager'] = _coerce_related_value(raw_data.get('manager'))
    except ValueError:
        raise

    # ----------------- NEW: LCO handling (present-only) -----------------
    if any(_present(k) for k in ('lco', 'lcoId', 'lco_id', 'lcoObject', 'lcoData', 'lcoPk', 'lco_pk')):
        # grab first present candidate
        raw_lco = None
        for cand in ('lco', 'lcoId', 'lco_id', 'lcoObject', 'lcoData', 'lcoPk', 'lco_pk'):
            if _present(cand):
                raw_lco = _first_of(cand)
                break

        if _is_placeholder_string(raw_lco):
            mapped['lco'] = None
        else:
            final = None

            # helper: attempt to parse JSON string, but tolerate invalid-number-with-leading-zero cases by regex fallback
            def _parse_json_like_or_extract_int(s):
                # try normal json first
                try:
                    parsed = json.loads(s)
                    if isinstance(parsed, dict):
                        for k in ('id', 'value', 'pk'):
                            v = parsed.get(k)
                            if v not in (None, ''):
                                try:
                                    return int(v)
                                except Exception:
                                    return parsed.get(k)
                        return parsed
                    if isinstance(parsed, int):
                        return parsed
                    return parsed
                except Exception:
                    # attempt to find "id": 09  or 'id': 09  or "value": 09 etc.
                    for key in ('id', 'value', 'pk'):
                        m = re.search(rf'["\']{key}["\']\s*:\s*0*([0-9]+)', s)
                        if m:
                            try:
                                return int(m.group(1))
                            except Exception:
                                return m.group(1)
                    # last resort: find the first group of digits (may be risky but better than nothing)
                    m2 = re.search(r'([0-9]+)', s)
                    if m2:
                        try:
                            return int(m2.group(1))
                        except Exception:
                            return m2.group(1)
                    return s

            # If a helper exists, try it first (keeps consistent behavior)
            coerced = None
            try:
                coerced = _coerce_related_value(raw_lco)
            except Exception:
                coerced = None

            if isinstance(coerced, int):
                final = coerced
            elif isinstance(coerced, dict):
                # prefer pk-like keys
                for k in ('id', 'value', 'pk'):
                    v = coerced.get(k)
                    if v not in (None, ''):
                        try:
                            final = int(v)
                        except Exception:
                            final = v
                        break
                if final is None:
                    final = coerced
            elif isinstance(coerced, str):
                final = _parse_json_like_or_extract_int(coerced)
            else:
                # no helper or helper returned None -> inspect raw_lco directly
                if isinstance(raw_lco, int):
                    final = raw_lco
                elif isinstance(raw_lco, dict):
                    for k in ('id', 'value', 'pk'):
                        v = raw_lco.get(k)
                        if v not in (None, ''):
                            try:
                                final = int(v)
                            except Exception:
                                final = v
                            break
                    if final is None:
                        final = raw_lco
                elif isinstance(raw_lco, str):
                    final = _parse_json_like_or_extract_int(raw_lco)
                elif isinstance(raw_lco, (list, tuple)) and raw_lco:
                    first_elem = _take_first(raw_lco)
                    try:
                        final = _coerce_related_value(first_elem)
                    except Exception:
                        final = first_elem
                else:
                    final = raw_lco

            # if final is string of digits, convert
            if isinstance(final, str) and final.strip().isdigit():
                try:
                    final = int(final.strip())
                except Exception:
                    pass

            mapped['lco'] = final

    # normalize emails only if present
    if 'email' in mapped and mapped.get('email') is not None:
        mapped['email'] = str(mapped['email']).strip().lower()
    if 'work_email' in mapped and mapped.get('work_email') is not None:
        mapped['work_email'] = str(mapped['work_email']).strip().lower()

    return mapped





# ----------------- Update API by employee_id (full code) -----------------

# place this in the same module where your helpers and imports exist
class EmployeeUpdateByPKAPIView(APIView):
    """
    Partial update of Employee found by primary key (pk) in URL.
    PATCH /employe/edit/<pk>/  -> partial update
    PUT /employe/edit/<pk>/    -> treated as partial update (for convenience)

    NOTE:
    - Accepts `lco` in the incoming mapped payload (as a PK or flexible object) and will pass it
      to the serializer (the serializer must have an `lco` PrimaryKeyRelatedField).
    - Tracks LCO in change log: snapshots for relation fields are stored as {"id": pk, "label": str(obj)}.
    - To clear existing photo, submit image as "null" / empty string / "none" etc. (handled via _clear_photo flag).
    """
    permission_classes = [IsAuthenticated]
    parser_classes = [JSONParser, MultiPartParser, FormParser]

    def _find_employee_or_404(self, pk):
        return get_object_or_404(Employee, pk=pk)

    def _is_image_provided(self, request):
        if getattr(request, "FILES", None):
            if 'image' in request.FILES or 'photo' in request.FILES:
                return True

        try:
            if hasattr(request, "data"):
                if 'image' in request.data:
                    val = request.data.get('image')
                    if _is_file_like(_take_first(val)):
                        return True
                    if isinstance(val, str) and val.strip().lower() in ("", "null", "none", "undefined"):
                        return False
                if 'photo' in request.data:
                    val = request.data.get('photo')
                    if _is_file_like(_take_first(val)):
                        return True
                    if isinstance(val, str) and val.strip().lower() in ("", "null", "none", "undefined"):
                        return False
        except Exception:
            logger.exception("Error inspecting image presence")
        return False

    def _precheck_uniques_for_update(self, instance, mapped):
        new_eid = mapped.get('employee_id')
        if new_eid:
            try:
                new_eid_str = str(new_eid).strip()
            except Exception:
                new_eid_str = new_eid
            if new_eid_str.lower() != (instance.employee_id or "").lower():
                if Employee.objects.filter(employee_id__iexact=new_eid_str).exclude(pk=instance.pk).exists():
                    return False, Response(
                        {"status": "error", "errors": {"message": "EmployeeId already exists."}},
                        status=drf_status.HTTP_409_CONFLICT
                    )
                mapped['employee_id'] = new_eid_str

        incoming_email = mapped.get('email')
        if incoming_email:
            email_l = str(incoming_email).strip().lower()

            if Employee.objects.filter(email__iexact=email_l).exclude(pk=instance.pk).exists():
                return False, Response(
                    {"status": "error", "errors": {"message": "This email already exists."}},
                    status=drf_status.HTTP_409_CONFLICT
                )

            existing_user = User.objects.filter(email__iexact=email_l).first()
            linked_user = getattr(instance, "user", None)
            if existing_user:
                if linked_user and existing_user.pk == linked_user.pk:
                    pass
                else:
                    return False, Response(
                        {"status": "error", "errors": {"message": "A user with this email already exists in auth table."}},
                        status=drf_status.HTTP_409_CONFLICT
                    )

        return True, None

    def _serialize_for_snapshot(self, val):
        """
        Convert a Python value or model instance into JSON-serializable snapshot form.
        - model instance -> {"id": pk, "label": <friendly label>}
        - File/FieldFile -> relative name string or None
        - datelike -> isoformat string
        - primitives -> left as-is
        """
        import datetime
        if val is None:
            return None

        # Django model instance -> {"id": pk, "label": str(obj) or chosen attr}
        try:
            pk = getattr(val, "pk", None)
            if pk is not None:
                label = None
                for a in ("name", "employee_name", "title", "code"):
                    try:
                        vv = getattr(val, a, None)
                        if vv:
                            label = str(vv)
                            break
                    except Exception:
                        continue
                if label is None:
                    label = str(val)
                return {"id": pk, "label": label}
        except Exception:
            pass

        # File-like -> name
        try:
            if hasattr(val, "name") and not callable(getattr(val, "name")):
                name = getattr(val, "name", None)
                return name if name else None
        except Exception:
            pass

        # datelike
        if isinstance(val, (datetime.date, datetime.datetime)):
            try:
                return val.isoformat()
            except Exception:
                return str(val)

        # primitives
        if isinstance(val, (bool, int, float, str)):
            return val

        # fallback
        try:
            return str(val)
        except Exception:
            return None

    def _snapshot_for_keys(self, instance, keys):
        """
        Build snapshot dict for the provided keys. For relation fields we return {"id": pk, "label": ...}
        For image/photo field return file name (relative path) or None.
        """
        out = {}
        for k in keys:
            if k.startswith("_"):
                continue
            try:
                # prefer to detect relation fields via model
                try:
                    f = instance._meta.get_field(k)
                    # ForeignKey / relation
                    if getattr(f, "is_relation", False) and getattr(f, "related_model", None):
                        rel_obj = getattr(instance, k, None)
                        out[k] = self._serialize_for_snapshot(rel_obj)
                        continue
                except Exception:
                    # field not found or not a relation — fallback below
                    pass

                if k == "image":
                    # actual model field is `photo`
                    v = getattr(instance, "photo", None)
                    out[k] = self._serialize_for_snapshot(getattr(v, "name", v) if v else None)
                else:
                    v = getattr(instance, k, None)
                    out[k] = self._serialize_for_snapshot(v)
            except Exception:
                out[k] = None
        return out

    def _redact_changes(self, changes):
        redact = set(getattr(settings, "SENSITIVE_LOG_FIELDS", ["aadhaar_number"]))
        for f in list(changes.keys()):
            key_lower = f.lower()
            if key_lower in redact or any(r.lower() == key_lower for r in redact):
                changes[f] = {
                    "old": "******" if changes[f].get("old") not in (None, "") else changes[f].get("old"),
                    "new": "******" if changes[f].get("new") not in (None, "") else changes[f].get("new")
                }
        return changes

    def _perform_update(self, instance, mapped, request):
        """
        Perform serializer.save and create an EmployeeChangeLog for changed fields.
        request: required so we can attach request.user and request.META to log meta.
        """
        try:
            logger.debug("Performing update. Mapped payload:\n%s", pprint.pformat(mapped))
            print("DEBUG - mapped payload:\n", pprint.pformat(mapped))
        except Exception:
            pass

        clear_photo_flag = bool(mapped.get("_clear_photo", False))
        old_photo_name = None
        if clear_photo_flag:
            try:
                old_photo = getattr(instance, "photo", None)
                old_photo_name = getattr(old_photo, "name", None) if old_photo else None
            except Exception:
                old_photo_name = None

        # build keys_to_track including 'lco' if present in mapped
        keys_to_track = []
        for k in mapped.keys():
            if k.startswith("_"):
                continue
            if k == "image":
                keys_to_track.append("image")
            else:
                keys_to_track.append(k)

        # ensure we always include lco in snapshot if lco present in mapped
        if 'lco' in mapped and 'lco' not in keys_to_track:
            keys_to_track.append('lco')

        try:
            before_snapshot = self._snapshot_for_keys(instance, keys_to_track)
        except Exception:
            before_snapshot = {}

        # Use serializer; ensure EmployeeSerializer has an `lco` field defined (PrimaryKeyRelatedField)
        serializer = EmployeeSerializer(instance, data=mapped, partial=True, context={"request": None})
        try:
            if not serializer.is_valid():
                try:
                    logger.debug("Update serializer invalid: %s", pprint.pformat(serializer.errors))
                    print("DEBUG - serializer.errors:\n", pprint.pformat(serializer.errors))
                except Exception:
                    pass

                combined = _combine_messages_into_sentence(serializer.errors)
                return False, Response({
                    "status": "error",
                    "errors": {"message": combined, "fields": serializer.errors}
                }, status=drf_status.HTTP_400_BAD_REQUEST)

            try:
                with transaction.atomic():
                    updated = serializer.save()

                    # handle explicit clear photo flag if present (we already tracked earlier)
                    if clear_photo_flag:
                        try:
                            from django.core.files.storage import default_storage
                            from django.conf import settings as django_settings
                            default_rel = getattr(django_settings, "DEFAULT_IMAGE_REL_PATH", None)
                            if old_photo_name and old_photo_name != default_rel:
                                if default_storage.exists(old_photo_name):
                                    try:
                                        default_storage.delete(old_photo_name)
                                    except Exception:
                                        logger.exception("Failed to delete old photo from storage: %s", old_photo_name)
                            # set photo field to None if clearing
                            updated.photo = None
                            try:
                                updated.save(update_fields=['photo'])
                            except Exception:
                                updated.save()
                        except Exception:
                            logger.exception("Error while clearing photo after update.")

                try:
                    after_snapshot = self._snapshot_for_keys(updated, keys_to_track)
                except Exception:
                    after_snapshot = {}

                # compute changes comparing snapshot values (dicts compare naturally)
                changes = {}
                for key in keys_to_track:
                    before_val = before_snapshot.get(key)
                    after_val = after_snapshot.get(key)
                    if before_val != after_val:
                        changes[key] = {"old": before_val, "new": after_val}

                # remove sensitive or irrelevant keys
                changes.pop('password', None)
                changes.pop('confirm_password', None)

                if changes:
                    changes = self._redact_changes(changes)
                    meta = {"updated_at": timezone.now().isoformat()}
                    try:
                        meta["remote_addr"] = request.META.get("REMOTE_ADDR")
                        meta["user_agent"] = request.META.get("HTTP_USER_AGENT")
                    except Exception:
                        pass

                    try:
                        EmployeeChangeLog.objects.create(
                            employee=updated,
                            changed_by=(request.user if getattr(request, "user", None) and request.user.is_authenticated else None),
                            action=EmployeeChangeLog.ACTION_UPDATE,
                            changes=changes,
                            summary=f"Updated fields: {', '.join(list(changes.keys())[:8])}",
                            meta=meta
                        )
                    except Exception as e:
                        logger.exception("Failed to create EmployeeChangeLog after update: %s", e)

                logger.info("Employee (pk=%s) updated successfully.", instance.pk)
                return True, Response({
                    "status": "success",
                    "detail": "Employee updated successfully.",
                    "employee": EmployeeSerializer(updated, context={'request': None}).data
                }, status=drf_status.HTTP_200_OK)

            except drf_serializers.ValidationError as valerr:
                try:
                    logger.debug("ValidationError from save(): %s", pprint.pformat(valerr.detail))
                    print("DEBUG - ValidationError in save():\n", pprint.pformat(valerr.detail))
                except Exception:
                    pass
                combined = _combine_messages_into_sentence(valerr.detail)
                return False, Response({"status": "error", "errors": {"message": combined}}, status=drf_status.HTTP_400_BAD_REQUEST)

        except IntegrityError as integ:
            logger.warning("IntegrityError during update: %s", str(integ))
            logger.debug(traceback.format_exc())
            try:
                friendly = _friendly_from_integrity_error(integ)
            except Exception:
                friendly = "Integrity error during update."
            return False, Response({"status": "error", "errors": {"message": friendly}}, status=drf_status.HTTP_409_CONFLICT)

        except Exception as exc:
            logger.exception("Unexpected exception during employee update: %s", str(exc))
            print("DEBUG - unexpected exception during update: ", str(exc))
            traceback.print_exc()
            return False, Response({"status": "error", "errors": {"message": "An unexpected error occurred. Please try again later."}}, status=drf_status.HTTP_500_INTERNAL_SERVER_ERROR)

    def patch(self, request, pk, *args, **kwargs):
        logger.info("Employee PATCH update request for pk=%s", pk)

        try:
            content_type = getattr(request, "content_type", request.META.get("CONTENT_TYPE"))
            print("---- EmployeeUpdateByPKAPIView incoming request preview ----")
            print("CONTENT_TYPE:", content_type)
            try:
                preview_data = request.data
                try:
                    preview_preview = pprint.pformat(preview_data)
                    if len(preview_preview) > 2000:
                        preview_preview = preview_preview[:1500] + "...(truncated)"
                except Exception:
                    preview_preview = str(preview_data)[:1000]
            except Exception:
                preview_preview = "<unavailable>"
            print("REQUEST.DATA preview:", preview_preview)
            try:
                files_info = {k: getattr(v, "name", str(type(v))) for k, v in request.FILES.items()}
            except Exception:
                files_info = "<unavailable>"
            print("REQUEST.FILES keys:", files_info)
            print("-----------------------------------------------------------")
        except Exception:
            logger.exception("Error while printing request preview")

        instance = self._find_employee_or_404(pk)

        # map incoming request to serializer fields — uses your mapping helpers which should
        # already include LCO handling (mapped['lco'] => PK or None)
        try:
            mapped = _map_request_to_serializer_partial(request.data)
            logger.debug("Mapped request to serializer fields: %s", pprint.pformat(mapped))
            print("DEBUG - mapped request:\n", pprint.pformat(mapped))
        except Exception as ve:
            msg = str(ve)
            logger.info("Coercion/validation error while mapping update request: %s", msg)
            print("DEBUG - mapping error:", msg)
            return Response({"status": "error", "errors": {"message": msg}}, status=drf_status.HTTP_400_BAD_REQUEST)

        # ------------------ password handling ------------------
        try:
            def _is_empty_val(v):
                return v is None or (isinstance(v, str) and v.strip() == "")

            pwd_present = 'password' in mapped
            conf_present = 'confirm_password' in mapped or 'confirmPassword' in mapped

            if 'confirmPassword' in mapped and 'confirm_password' not in mapped:
                mapped['confirm_password'] = mapped.pop('confirmPassword')

            if pwd_present and _is_empty_val(mapped.get('password')):
                mapped.pop('password', None)
                if 'confirm_password' in mapped:
                    mapped.pop('confirm_password', None)

            if not pwd_present and conf_present and _is_empty_val(mapped.get('confirm_password')):
                mapped.pop('confirm_password', None)

            if 'password' in mapped:
                p = mapped.get('password')
                cp = mapped.get('confirm_password')
                if cp is None or _is_empty_val(cp):
                    return Response({"status": "error", "errors": {"message": "confirm_password is required when changing password."}}, status=drf_status.HTTP_400_BAD_REQUEST)
                if str(p) != str(cp):
                    return Response({"status": "error", "errors": {"message": "password and confirm_password do not match."}}, status=drf_status.HTTP_400_BAD_REQUEST)

            logger.debug("Mapped payload after password handling: %s", pprint.pformat(mapped))
            print("DEBUG - mapped payload after password handling:\n", pprint.pformat(mapped))
        except Exception:
            logger.exception("Error while normalizing password fields")

        # ---------------- image handling and clear flag ----------------
        try:
            def _is_explicit_clear(v):
                return v is None or (isinstance(v, str) and v.strip().lower() in ("", "null", "none", "undefined"))

            if 'image' in mapped:
                img_val = mapped.get('image')
                if self._is_image_provided(request):
                    logger.debug("Image file provided in request.FILES; leaving 'image' as-is.")
                else:
                    if _is_explicit_clear(img_val):
                        mapped.pop('image', None)
                        mapped['_clear_photo'] = True
                        logger.debug("Explicit image clear requested; setting _clear_photo flag.")
                    else:
                        mapped.pop('image', None)
                        logger.debug("No image uploaded and no explicit clear requested; removing 'image' to preserve existing photo.")
            else:
                if 'photo' in mapped:
                    if self._is_image_provided(request):
                        logger.debug("Image file provided in request.FILES (photo); leaving 'photo' as-is.")
                    else:
                        if _is_explicit_clear(mapped.get('photo')):
                            mapped.pop('photo', None)
                            mapped['_clear_photo'] = True
                            logger.debug("Explicit photo clear requested; setting _clear_photo flag.")
                        else:
                            mapped.pop('photo', None)
                            logger.debug("No photo uploaded and no explicit clear requested; removing 'photo' to preserve existing photo.")
        except Exception:
            logger.exception("Error while deciding about image presence; continuing without mutating mapped image key.")

        # Pre-check uniqueness (employee_id, email etc.)
        ok, resp = self._precheck_uniques_for_update(instance, mapped)
        if not ok:
            logger.debug("Uniqueness precheck failed: %s", resp.data if hasattr(resp, 'data') else resp)
            return resp

        # Finally perform update (pass request so changelog may include remote/user info)
        success, response = self._perform_update(instance, mapped, request)
        try:
            logger.debug("Update result response: %s", pprint.pformat(getattr(response, 'data', '<no data>')))
            print("DEBUG - update response:\n", pprint.pformat(getattr(response, 'data', '<no data>')))
        except Exception:
            pass
        return response

    def put(self, request, pk, *args, **kwargs):
        # treat PUT as partial update for convenience
        return self.patch(request, pk, *args, **kwargs)



    




    

    




class BranchListAPIView(generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = BranchListSerializer
    queryset = Branch.objects.all().order_by('name')
    pagination_class = None  # no pagination for select lists


class DepartmentListAPIView(generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = DepartmentListSerializer
    queryset = Department.objects.all().order_by('name')
    pagination_class = None


class JobPositionListAPIView(generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = JobPositionListSerializer
    queryset = JobPosition.objects.all().order_by('name')
    pagination_class = None






from .serializers import EmployeeShortSerializer
class ManagerListAPIView(generics.ListAPIView):
    """
    Returns a minimal list of employees to use as "manager" select options.

    Query params:
    - q=<text>           → search employee_name or employee_id (case-insensitive)
    - exclude=<id1,id2>  → comma separated list of employee PKs to exclude
    - limit=<n>          → limit the number of results returned
    """
    permission_classes = [IsAuthenticated]  # change to AllowAny if you want public
    serializer_class = EmployeeShortSerializer
    queryset = Employee.objects.all().order_by("employee_name")

    def get_queryset(self):
        qs = super().get_queryset()

        # Only active employees if your model has an is_active flag.
        # If you don't have is_active, remove the filter below.
        if hasattr(Employee, "is_active"):
            qs = qs.filter(is_active=True)

        q = self.request.query_params.get("q")
        if q:
            q = q.strip()
            qs = qs.filter(
                Q(employee_name__icontains=q) |
                Q(employee_id__icontains=q)
            )

        exclude = self.request.query_params.get("exclude")
        if exclude:
            try:
                ids = [int(x) for x in exclude.split(",") if x.strip().isdigit()]
                if ids:
                    qs = qs.exclude(pk__in=ids)
            except ValueError:
                pass

        limit = self.request.query_params.get("limit")
        if limit and limit.isdigit():
            qs = qs[: int(limit)]

        return qs
    




from math import ceil
from django.core.paginator import Paginator, EmptyPage
from django.db.models import Q
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.parsers import JSONParser, MultiPartParser, FormParser
from django.db.models import Case, When, IntegerField, Value

class EmployeeListAPIView(APIView):
    """
    GET / POST endpoint that returns paginated employees with simple search.
    If `name` provided, search ONLY employee_name (icontains).
    If `mobile` provided, search mobile fields as before.
    """
    permission_classes = [IsAuthenticated]
    parser_classes = [JSONParser, MultiPartParser, FormParser]

    DEFAULT_LIMIT = 8  # fallback if frontend doesn't provide a valid value

    # ----------------- source helpers -----------------
    def _load_source(self, request):
        try:
            raw = request.body.decode("utf-8")
        except Exception:
            raw = ""

        try:
            if request.data:
                return request.data
        except Exception:
            pass

        if raw:
            try:
                parsed = json.loads(raw)
                if isinstance(parsed, dict):
                    return parsed
            except Exception:
                pass

        return request.query_params

    def _get_from_source(self, source, key, default=None):
        if source is None:
            return default
        try:
            v = source.get(key, default)
        except Exception:
            try:
                v = source[key]
            except Exception:
                v = default
        if isinstance(v, (list, tuple)):
            return v[0] if v else default
        return v

    # ----------------- param extraction -----------------
    def _extract_params(self, request):
        source = self._load_source(request)

        def _g(k, default=None):
            v = self._get_from_source(source, k, default)
            if v is None:
                return None
            if isinstance(v, str):
                v = v.strip()
                return v if v != "" else None
            return v

        name = _g("name")
        mobile = _g("mobile")

        page_raw = _g("page") or "1"
        limit_raw = _g("limit") or str(self.DEFAULT_LIMIT)

        try:
            page = int(page_raw)
            if page < 1:
                page = 1
        except Exception:
            page = 1

        try:
            limit = int(limit_raw)
            # Do not cap here — accept the frontend-sent value, but ensure it's positive
            if limit < 1:
                limit = self.DEFAULT_LIMIT
        except Exception:
            limit = self.DEFAULT_LIMIT

        params = {"name": name, "mobile": mobile, "page": page, "limit": limit}
        return params

    # ----------------- queryset builder -----------------
    def _build_queryset(self, params):
        """
        Build queryset:
          - mobile filter searches mobile/emergency fields (same as before)
          - name filter searches ONLY employee_name__icontains
        """
        qs = Employee.objects.all()
        name = params.get("name")
        mobile = params.get("mobile")

        if mobile:
            qs = qs.filter(Q(work_mobile__icontains=mobile) | Q(emergency_contact__icontains=mobile))

        if name:
            # SEARCH NAME ONLY (case-insensitive partial match)
            qs = qs.filter(employee_name__icontains=name).order_by("-created_at")
        else:
            qs = qs.order_by("-created_at")

        return qs

    # ----------------- pagination -----------------
    def _paginate_qs(self, qs, page, limit):
        paginator = Paginator(qs, limit)
        total_count = paginator.count
        total_pages = paginator.num_pages if paginator.num_pages > 0 else 1
        try:
            page_obj = paginator.page(page)
            items = page_obj.object_list
        except EmptyPage:
            items = []
        return items, total_count, total_pages

    # ----------------- ensure absolute image URLs -----------------
    def _absolutize_image_urls(self, results, request):
        if not isinstance(results, (list, tuple)):
            return results

        for item in results:
            try:
                img = item.get("image")
            except Exception:
                item["image"] = None
                continue

            if not img:
                item["image"] = None
                continue

            if isinstance(img, str) and (img.startswith("http://") or img.startswith("https://")):
                continue

            if isinstance(img, str):
                if not img.startswith("/"):
                    img = "/" + img
                try:
                    item["image"] = request.build_absolute_uri(img)
                except Exception:
                    item["image"] = img
            else:
                item["image"] = None

        return results

    # ----------------- serialization -----------------
    def _serialize_page(self, items, request):
        serializer = EmployeeSerializer(items, many=True, context={"request": request})
        data = serializer.data
        data = self._absolutize_image_urls(data, request)
        for instance, obj in zip(items, data):
            try:
                obj['id'] = getattr(instance, 'pk', None)
            except Exception:
                obj['id'] = None
        return data

    # ----------------- handlers -----------------
    def get(self, request, *args, **kwargs):
        params = self._extract_params(request)
        qs = self._build_queryset(params)
        items, total_count, total_pages = self._paginate_qs(qs, params["page"], params["limit"])
        results = self._serialize_page(items, request)
        return Response({
            "status": "success",
            "page": params["page"],
            "limit": params["limit"],
            "total_count": total_count,
            "total_pages": total_pages,
            "results": results
        }, status=status.HTTP_200_OK)

    def post(self, request, *args, **kwargs):
        params = self._extract_params(request)
        qs = self._build_queryset(params)
        items, total_count, total_pages = self._paginate_qs(qs, params["page"], params["limit"])
        results = self._serialize_page(items, request)
        return Response({
            "status": "success",
            "page": params["page"],
            "limit": params["limit"],
            "total_count": total_count,
            "total_pages": total_pages,
            "results": results
        }, status=status.HTTP_200_OK)









from django.shortcuts import get_object_or_404
from django.core.paginator import Paginator, EmptyPage
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from django.utils import timezone
import json

from employe.models import Employee, EmployeeChangeLog

MAX_DETAIL_LENGTH = 400   # limit details text size for modal display

IMAGE_FIELD_NAMES = {
    "image", "photo", "avatar", "picture", "profile_image", "photo_url", "image_url"
}

import json
import logging

from django.shortcuts import get_object_or_404
from django.core.paginator import Paginator, EmptyPage
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status

from employe.models import Employee, EmployeeChangeLog

logger = logging.getLogger(__name__)

MAX_DETAIL_LENGTH = 400   # limit details text size for modal display

IMAGE_FIELD_NAMES = {
    "image", "photo", "avatar", "picture", "profile_image", "photo_url", "image_url"
}


def _is_image_field_name(field_name: str) -> bool:
    if not field_name:
        return False
    return str(field_name).strip().lower() in IMAGE_FIELD_NAMES


def _user_display_name(user):
    """Friendly display for user who made the change."""
    if not user:
        return None
    try:
        if callable(getattr(user, "get_full_name", None)):
            fullname = user.get_full_name()
            if fullname:
                return fullname
    except Exception:
        pass
    for attr in ("get_username", "email", "username", "pk"):
        try:
            if attr == "get_username" and callable(getattr(user, "get_username", None)):
                val = user.get_username()
            else:
                val = getattr(user, attr, None)
            if val:
                return str(val)
        except Exception:
            continue
    return None


def _parse_changes(raw):
    """
    Normalize stored change payload into a dict of field -> {'old':..., 'new':...}
    Accepts dict or JSON-string; returns dict or {} on failure.
    """
    if not raw:
        return {}
    if isinstance(raw, dict):
        return raw
    try:
        if isinstance(raw, str):
            parsed = json.loads(raw)
            if isinstance(parsed, dict):
                return parsed
    except Exception:
        pass
    return {}


def _get_field_label(model, field_name: str) -> str:
    """
    Return a short friendly label for a model field, using verbose_name if available,
    otherwise generate a readable label from the field name.
    """
    if not field_name:
        return ""
    try:
        f = model._meta.get_field(field_name)
        label = str(getattr(f, "verbose_name", "") or "")
        if label:
            return label
    except Exception:
        pass
    return field_name.replace("_", " ").title()


def _display_for_frontend(value):
    """
    Convert Python values to a frontend-friendly representation:
      - None or empty/whitespace-only string -> "Null" (literal string)
      - otherwise return value as-is (strings remain strings)
    """
    # Treat None or empty/whitespace-only strings as "Null"
    if value is None:
        return "Null"
    if isinstance(value, str):
        if value.strip() == "":
            return "Null"
        return value
    # Leave other scalar values (ints, booleans, etc.) as-is
    return value



def _render_value(model, field_name: str, value, fk_cache: dict):
    """
    Render a stored value into a human-friendly representation:
      - None -> None (caller will convert via _display_for_frontend)
      - For choice fields: return choice label if present.
      - For ForeignKey fields: try to resolve related object's str() (cached).
      - Otherwise return original value.
    fk_cache is a dict used to cache related-model lookups keyed by (related_model_label, pk).
    """
    if value is None:
        return None
    try:
        f = model._meta.get_field(field_name)
    except Exception:
        # unknown field, return raw value
        return value

    # choices handling
    try:
        if getattr(f, "choices", None):
            choices_map = dict(f.choices)
            return choices_map.get(value, value)
    except Exception:
        pass

    # ForeignKey handling
    try:
        if getattr(f, "is_relation", False) and getattr(f, "related_model", None):
            rel = f.related_model
            cache_key = (rel._meta.label, value)
            if cache_key in fk_cache:
                return fk_cache[cache_key]
            try:
                obj = rel.objects.filter(pk=value).first()
                if obj is not None:
                    s = str(obj)
                    fk_cache[cache_key] = s
                    return s
            except Exception:
                pass
    except Exception:
        pass

    # default
    return value


def _diff_string_from_changes(changes, model, fk_cache, limit=MAX_DETAIL_LENGTH):
    """
    Produce compact 'Label: "old" → "new", ...' summary string.
    Skip image-like fields' old/new details; append 'image changed' at the end if any image fields exist.
    Uses model to render values and friendly labels. Converts None -> "Null".
    """
    if not changes:
        return ""
    parts = []
    image_changed = False
    for field, vals in changes.items():
        if _is_image_field_name(field):
            image_changed = True
            continue

        old_s = new_s = ""
        try:
            if isinstance(vals, dict):
                old_raw = vals.get("old")
                new_raw = vals.get("new")
                old_rendered = _render_value(model, field, old_raw, fk_cache)
                new_rendered = _render_value(model, field, new_raw, fk_cache)
                old_disp = _display_for_frontend(old_rendered) if old_rendered is not None else _display_for_frontend(None)
                new_disp = _display_for_frontend(new_rendered) if new_rendered is not None else _display_for_frontend(None)
            else:
                # non-dict stored change (rare)
                old_disp = ""
                new_disp = _display_for_frontend(vals)
        except Exception:
            old_disp = _display_for_frontend(None)
            new_disp = _display_for_frontend(None)

        old_s = str(old_disp).replace("\n", " ").strip()
        new_s = str(new_disp).replace("\n", " ").strip()
        label = _get_field_label(model, field)
        parts.append(f'{label}: "{old_s}" → "{new_s}"')

        if len(", ".join(parts)) > limit - 60:
            break

    out = ", ".join(parts)
    if image_changed:
        out = (out + "; image changed") if out else "image changed"

    if len(out) > limit:
        out = out[:limit].rstrip() + "…"
    return out

class EmployeeChangeLogAPIView(APIView):
    """
    Endpoint for employee change logs with friendly labels.

    GET /employe/<employee_pk>/changelog/?page=1&limit=20&mode=fields
    GET /employe/<employee_pk>/changelog/?page=1&limit=20&mode=diff
    GET /employe/<employee_pk>/changelog/?log_id=<log_pk>
    """
    permission_classes = [IsAuthenticated]
    parser_classes = []

    DEFAULT_LIMIT = 20
    MAX_LIMIT = 200

    def get(self, request, pk, *args, **kwargs):
        # Ensure employee exists
        employee = get_object_or_404(Employee, pk=pk)

        # per-request FK cache for resolving related display names
        fk_cache = {}

        # detail mode if log_id specified
        log_id = request.query_params.get("log_id")
        if log_id:
            log = get_object_or_404(EmployeeChangeLog, pk=log_id, employee=employee)

            date = log.created_at.isoformat() if getattr(log, "created_at", None) else None
            user_disp = _user_display_name(getattr(log, "changed_by", None))
            action_label = dict(EmployeeChangeLog.ACTION_CHOICES).get(log.action, log.action)

            if log.action == EmployeeChangeLog.ACTION_CREATE:
                details = "Data created"
                changes_list = []
            elif log.action == EmployeeChangeLog.ACTION_DELETE:
                details = "Record deleted"
                changes_list = []
            else:
                parsed = _parse_changes(getattr(log, "changes", None)) or {}
                changes_list = []
                image_fields = []
                non_image_fields = []

                for field, vals in parsed.items():
                    label = _get_field_label(Employee, field)
                    if _is_image_field_name(field):
                        image_fields.append(field)
                        # Per your request: old value empty string, new value a short marker
                        changes_list.append({
                            "field": label,
                            "field_key": field,
                            "old": "",
                            "new": "Image Updated"
                        })
                    else:
                        non_image_fields.append(field)
                        if isinstance(vals, dict):
                            old_raw = vals.get("old", None)
                            new_raw = vals.get("new", None)
                            old = _render_value(Employee, field, old_raw, fk_cache)
                            new = _render_value(Employee, field, new_raw, fk_cache)
                        else:
                            old = None
                            new = _render_value(Employee, field, vals, fk_cache)

                        changes_list.append({
                            "field": label,
                            "field_key": field,
                            "old": _display_for_frontend(old),
                            "new": _display_for_frontend(new)
                        })

                # Decide details
                if non_image_fields == [] and image_fields:
                    details = "IMAGE CHANGED ONLY"
                else:
                    # use summary if present otherwise build compact diff
                    details = str(log.summary) if getattr(log, "summary", None) else _diff_string_from_changes(parsed, Employee, fk_cache)

            return Response({
                "status": "success",
                "log": {
                    "id": log.pk,
                    "date": date,
                    "user": user_disp,
                    "action": action_label,
                    "details": details,
                    "changes": changes_list
                }
            }, status=status.HTTP_200_OK)

        # ---------------- list mode ----------------
        qs = employee.change_logs.all().order_by("-created_at")

        # pagination params
        try:
            page = int(request.query_params.get("page", "1"))
        except Exception:
            page = 1
        try:
            limit = int(request.query_params.get("limit", str(self.DEFAULT_LIMIT)))
        except Exception:
            limit = self.DEFAULT_LIMIT

        if page < 1:
            page = 1
        if limit < 1:
            limit = self.DEFAULT_LIMIT
        limit = min(limit, self.MAX_LIMIT)

        paginator = Paginator(qs, limit)
        total_count = paginator.count
        total_pages = paginator.num_pages if paginator.num_pages > 0 else 1
        try:
            page_obj = paginator.page(page)
            logs = list(page_obj.object_list)
        except EmptyPage:
            logs = []

        mode = (request.query_params.get("mode") or "fields").strip().lower()
        results = []
        for log in logs:
            date = log.created_at.isoformat() if getattr(log, "created_at", None) else None
            user_disp = _user_display_name(getattr(log, "changed_by", None))
            action_label = dict(EmployeeChangeLog.ACTION_CHOICES).get(log.action, log.action)

            details = None
            changes_list = []

            if log.action == EmployeeChangeLog.ACTION_CREATE:
                details = "Data created"
                changes_list = []
            elif log.action == EmployeeChangeLog.ACTION_DELETE:
                details = "Record deleted"
                changes_list = []
            else:
                parsed = _parse_changes(getattr(log, "changes", None)) or {}
                image_fields = [f for f in parsed.keys() if _is_image_field_name(f)]
                non_image_fields = [f for f in parsed.keys() if not _is_image_field_name(f)]

                # Build structured changes_list using friendly labels and rendered values
                fk_cache_local = {}  # cache per-log
                for field in non_image_fields:
                    vals = parsed.get(field)
                    if isinstance(vals, dict):
                        old = _render_value(Employee, field, vals.get("old", None), fk_cache_local)
                        new = _render_value(Employee, field, vals.get("new", None), fk_cache_local)
                    else:
                        old = None
                        new = _render_value(Employee, field, vals, fk_cache_local)
                    changes_list.append({
                        "field": _get_field_label(Employee, field),
                        "field_key": field,
                        "old": _display_for_frontend(old),
                        "new": _display_for_frontend(new)
                    })

                for field in image_fields:
                    # Per your request: show empty old and a marker as new value
                    changes_list.append({
                        "field": _get_field_label(Employee, field),
                        "field_key": field,
                        "old": "",
                        "new": "Image Updated"
                    })

                # If only image fields changed -> special message
                if non_image_fields == [] and image_fields:
                    details = "IMAGE CHANGED ONLY"
                else:
                    if getattr(log, "summary", None):
                        try:
                            parts = [p.strip() for p in str(log.summary).split(",") if p.strip()]
                            mapped = []
                            for p in parts:
                                # map field keys to labels if possible, otherwise keep text
                                try:
                                    mapped.append(_get_field_label(Employee, p) if p in [f.name for f in Employee._meta.fields] else p)
                                except Exception:
                                    mapped.append(p)
                            details = ", ".join(mapped) if mapped else str(log.summary)
                        except Exception:
                            details = str(log.summary)
                    else:
                        if mode == "diff":
                            details = _diff_string_from_changes(parsed, Employee, fk_cache)
                            if not details:
                                details = "Updated" + ("; image changed" if image_fields else "")
                        else:
                            visible_fields = [f for f in parsed.keys() if not _is_image_field_name(f)]
                            if visible_fields:
                                friendly_names = [_get_field_label(Employee, f) for f in visible_fields]
                                details = "Updated fields: " + ", ".join(friendly_names)
                                if image_fields:
                                    details = details + "; image changed"
                            else:
                                details = "image changed" if image_fields else "Updated"

            results.append({
                "id": log.pk,
                "date": date,
                "user": user_disp,
                "action": action_label,
                "details": details,
                "changes": changes_list
            })

        return Response({
            "status": "success",
            "page": page,
            "limit": limit,
            "total_count": total_count,
            "total_pages": total_pages,
            "results": results
        }, status=status.HTTP_200_OK)

