from rest_framework import serializers
from employe.models import Employee, JobPosition, Department, Branch
from rest_framework import serializers
from employe.models import Branch, Department, JobPosition
from django.contrib.auth import get_user_model
import logging
logger = logging.getLogger(__name__)
User = get_user_model()
USERNAME_FIELD = getattr(User, "USERNAME_FIELD", "username")
import re
import uuid
from LCO.models import LCO

class FlexibleRelatedField(serializers.PrimaryKeyRelatedField):
    """
    Accepts:
      - numeric PK (int or numeric string)
      - an object with {'value': pk} (common from frontends)
      - a textual identifier (code/name) for JobPosition (tries code then name)
    """

    def to_internal_value(self, data):
        # handle nested object like {"label":"X","value":7}
        if isinstance(data, dict) and "value" in data:
            data = data["value"]

        if data is None or data == "":
            return None

        if isinstance(data, str) and data.strip().isdigit():
            return super().to_internal_value(int(data.strip()))

        qs = self.get_queryset()
        if qs is not None and hasattr(qs.model, "code") and isinstance(data, str):
            val = data.strip()
            try:
                return qs.get(code__iexact=val)
            except qs.model.DoesNotExist:
                pass
            try:
                return qs.get(name__iexact=val)
            except qs.model.DoesNotExist:
                pass

        return super().to_internal_value(data)
    

DEFAULT_IMAGE_REL_PATH = "employees/photos/demo_profile.png"
import json
from django.db import IntegrityError, transaction

class EmployeeSerializer(serializers.ModelSerializer):
    """
    Employee serializer with LCO support.

    - Accepts `lco` (PrimaryKey) when creating/updating.
    - Exposes `country` mapped to model field `nationality`.
    - Image is mapped to `photo` model field via source='photo'.
    - Accepts password & confirm_password for create/change password.
    """
    # expose country to API but map to model field 'nationality'
    country = serializers.CharField(source='nationality', required=False, allow_null=True, allow_blank=True)

    # Input-only password fields
    password = serializers.CharField(write_only=True, required=False, min_length=8)
    confirm_password = serializers.CharField(write_only=True, required=False)

    # API uses "image" but model field is photo -> use source='photo'
    image = serializers.ImageField(source='photo', required=False, allow_null=True, use_url=True)

    # Related fields
    job_position = FlexibleRelatedField(queryset=JobPosition.objects.all(), required=False, allow_null=True)
    department = serializers.PrimaryKeyRelatedField(queryset=Department.objects.all())
    branch = serializers.PrimaryKeyRelatedField(queryset=Branch.objects.all())
    manager = serializers.PrimaryKeyRelatedField(queryset=Employee.objects.all(), required=False, allow_null=True)

    # NEW: LCO field (optional)
    lco = serializers.PrimaryKeyRelatedField(queryset=LCO.objects.all(), required=False, allow_null=True)

    # Allow client-provided employee id
    employee_id = serializers.CharField(required=False, allow_blank=False)

    class Meta:
        model = Employee
        fields = [
            'email', 'employee_id', 'image', 'employee_name', 'country',
            'state', 'city', 'address_line1', 'gstin', 'district',
            'gender', 'date_of_birth', 'marital_status',
            'emergency_contact_name', 'emergency_contact',
            'visa_number', 'visa_expiry_date',
            'pincode', 'job_position', 'work_mobile', 'work_email', 'work_location',
            'department', 'branch', 'manager', 'lco',            # <-- lco included
            'password', 'confirm_password',
            'created_at', 'updated_at', 'user',
        ]
        read_only_fields = ('created_at', 'updated_at')

    # ---------------- Helper to parse label/value shapes ----------------
    @staticmethod
    def _extract_label_str(raw):
        """
        Accept dict, JSON-string like '{"label":"India","value":101}', plain string, or numeric.
        Return label (preferred) as plain string, else value coerced to string, else None.
        """
        if raw is None:
            return None

        # Dict-like
        if isinstance(raw, dict):
            label = raw.get('label')
            if label not in (None, ''):
                return str(label).strip()
            val = raw.get('value')
            return str(val).strip() if val not in (None, '') else None

        # String: try JSON parsing
        if isinstance(raw, str):
            s = raw.strip()
            if s == '':
                return None
            if s.startswith('{') and s.endswith('}'):
                try:
                    obj = json.loads(s)
                    if isinstance(obj, dict):
                        label = obj.get('label')
                        if label not in (None, ''):
                            return str(label).strip()
                        val = obj.get('value')
                        return str(val).strip() if val not in (None, '') else None
                except Exception:
                    # not valid JSON -> fall back to raw string
                    pass
            return s

        # Other scalar -> coerce to string
        return str(raw)

    # ----------------- field validators -----------------
    def validate_employee_id(self, value):
        if value is None:
            return value
        eid = value.strip()
        qs = Employee.objects.filter(employee_id__iexact=eid)
        if self.instance is None:
            if qs.exists():
                raise serializers.ValidationError("An Employee with this employee_id already exists.")
        else:
            if qs.exclude(pk=self.instance.pk).exists():
                raise serializers.ValidationError("Another Employee with this employee_id already exists.")
        return eid

    def validate_email(self, value):
        email = value.strip().lower()
        # Employee-level uniqueness
        if self.instance is None:
            if Employee.objects.filter(email__iexact=email).exists():
                raise serializers.ValidationError("This email already exists.")
        else:
            if Employee.objects.filter(email__iexact=email).exclude(pk=self.instance.pk).exists():
                raise serializers.ValidationError("Another employee with this email already exists.")

        # auth user uniqueness logic
        user_qs = User.objects.filter(email__iexact=email)
        if self.instance is None:
            if user_qs.exists():
                raise serializers.ValidationError("This email already exists.")
        else:
            linked_user = getattr(self.instance, "user", None)
            if linked_user:
                if user_qs.exclude(pk=linked_user.pk).exists():
                    raise serializers.ValidationError("Another auth user with this email already exists.")
            else:
                if user_qs.exists():
                    raise serializers.ValidationError("Another auth user with this email already exists.")
        return email

    def validate_emergency_contact(self, value):
        """
        Optional: if provided (non-empty) enforce exactly 10 digits.
        Normalize to digits-only string on return.
        """
        if value in (None, ""):
            return None
        digits = re.sub(r'\D', '', str(value or ''))
        if digits == '':
            return None
        if len(digits) != 10:
            raise serializers.ValidationError("Emergency contact must contain exactly 10 digits.")
        return digits

    # keep the validator name validate_nationality so DRF will run it for the underlying field
    # since country field uses source='nationality'.
    def validate_nationality(self, value):
        return self._extract_label_str(value)

    def validate_state(self, value):
        return self._extract_label_str(value)

    def validate_district(self, value):
        return self._extract_label_str(value)

    # validate other fields (existing validate() logic preserved)
    def validate(self, data):
        # ---------- password logic ----------
        pwd = data.get("password")
        cpwd = data.get("confirm_password")

        if self.instance is None:
            if not pwd or not cpwd:
                raise serializers.ValidationError({'message': 'password and confirm_password are required for new employee.'})
            if pwd != cpwd:
                raise serializers.ValidationError({'message': 'Passwords do not match.'})
        else:
            if pwd or cpwd:
                if not pwd or not cpwd:
                    raise serializers.ValidationError({'message': 'Both password and confirm_password are required to change password.'})
                if pwd != cpwd:
                    raise serializers.ValidationError({'message': 'Passwords do not match.'})

        # ---------- visa two-way validation ----------
        def _is_blank(val):
            return val is None or (isinstance(val, str) and val.strip().lower() in ("", "null", "none", "undefined"))

        if 'visa_number' in data:
            visa_val = data.get('visa_number')
        else:
            visa_val = getattr(self.instance, 'visa_number', None) if self.instance is not None else None

        if 'visa_expiry_date' in data:
            visa_exp_val = data.get('visa_expiry_date')
        else:
            visa_exp_val = getattr(self.instance, 'visa_expiry_date', None) if self.instance is not None else None

        visa_present = not _is_blank(visa_val)
        visa_exp_present = not _is_blank(visa_exp_val)

        if visa_present and not visa_exp_present:
            raise serializers.ValidationError({"visa_expiry_date": "Visa expiry date required when visa number is provided."})
        if visa_exp_present and not visa_present:
            raise serializers.ValidationError({"visa_number": "Visa number required when visa expiry date is provided."})

        return data

    # --------------- internal helper to create auth user ---------------
    def _generate_internal_username(self):
        for _ in range(5):
            candidate = f"user_{uuid.uuid4().hex[:12]}"
            if not User.objects.filter(**{User.USERNAME_FIELD: candidate}).exists():
                return candidate
        return f"user_{uuid.uuid4().hex}"

    def _create_auth_user(self, email, password):
        email = (email or "").strip().lower()
        if User.objects.filter(email__iexact=email).exists():
            raise serializers.ValidationError({'message': 'A user with this email already exists.'})

        create_kwargs = {'email': email}
        if User.USERNAME_FIELD and User.USERNAME_FIELD.lower() == 'email':
            create_kwargs[User.USERNAME_FIELD] = email
        else:
            create_kwargs[User.USERNAME_FIELD] = self._generate_internal_username()

        try:
            user = User.objects.create_user(**create_kwargs, password=password)
            try:
                user.is_superuser = False
                user.is_staff = False
            except Exception:
                pass
            user.save()
            return user
        except TypeError:
            user = User(**create_kwargs)
            user.set_password(password)
            try:
                user.is_superuser = False
                user.is_staff = False
            except Exception:
                pass
            user.save()
            return user
        except Exception as e:
            err_text = str(e) or ""
            low = err_text.lower()
            m = re.search(r"key \((?P<col>[\w_]+)\)=\(", err_text, re.IGNORECASE)
            if "email" in low and ("duplicate key" in low or "violates unique constraint" in low or "already exists" in low):
                raise serializers.ValidationError({'message': 'Email already exists.'})
            if m:
                col = m.group("col").lower()
                if "email" in col:
                    raise serializers.ValidationError({'message': 'Email already exists.'})
                if col in ("employee_id", "employeeid", "empid"):
                    raise serializers.ValidationError({'message': 'Employee ID already exists.'})
                nice = col.replace('_', ' ').capitalize()
                raise serializers.ValidationError({'message': f'{nice} already exists.'})
            m2 = re.search(r'constraint "(?P<constraint>[^"]+)"', err_text, re.IGNORECASE)
            if m2:
                constraint = m2.group('constraint').lower()
                if "email" in constraint:
                    raise serializers.ValidationError({'message': 'Email already exists.'})
                if "employee_id" in constraint or "employeeemployeeid" in constraint.replace('.', ''):
                    raise serializers.ValidationError({'message': 'Employee ID already exists.'})
            logger.exception("Unexpected error when creating auth user: %s", err_text)
            raise serializers.ValidationError({'message': 'Failed to create auth user.'})

    # --------------- create & update ---------------
    def create(self, validated_data):
        password = validated_data.pop('password', None)
        validated_data.pop('confirm_password', None)

        email = validated_data.get('email', '').strip().lower()
        user = self._create_auth_user(email, password)

        with transaction.atomic():
            instance = super().create(validated_data)
            try:
                instance.user = user
                instance.save(update_fields=['user'])
            except Exception:
                logger.exception("Failed to link created auth user to employee instance.")
                raise

            if not instance.employee_id:
                instance.employee_id = f"EMP{int(instance.pk):06d}"
                instance.save(update_fields=['employee_id'])

            if not getattr(instance, 'photo'):
                instance.photo = DEFAULT_IMAGE_REL_PATH
                instance.save(update_fields=['photo'])

        return instance

    def update(self, instance, validated_data):
        password = validated_data.pop('password', None)
        validated_data.pop('confirm_password', None)

        old_email = instance.email or ''
        with transaction.atomic():
            instance = super().update(instance, validated_data)

            user = getattr(instance, 'user', None)
            if not user:
                user = User.objects.filter(email__iexact=old_email).first()
                if user:
                    instance.user = user
                    instance.save(update_fields=['user'])

            if user:
                new_email = instance.email.strip().lower() if instance.email else None
                if new_email and new_email.lower() != (old_email or '').lower():
                    setattr(user, User.USERNAME_FIELD, new_email)
                    user.email = new_email
                if password:
                    user.set_password(password)
                try:
                    user.is_superuser = False
                    user.save()
                except Exception:
                    user.save()

        return instance

    # --------------- representation (ensure label-only for country/state/district) ---------------
    def to_representation(self, instance):
        base = super().to_representation(instance)

        def related_to_label_value(rel_obj, label_attr='name'):
            if not rel_obj:
                return None
            label = getattr(rel_obj, label_attr, None) or str(rel_obj)
            return {"label": label, "value": getattr(rel_obj, 'pk', None)}

        nat = self._extract_label_str(getattr(instance, "nationality", None))
        state = self._extract_label_str(getattr(instance, "state", None))
        district = self._extract_label_str(getattr(instance, "district", None))

        rep = {
            "employeeId": base.get("employee_id"),
            "name": base.get("employee_name"),
            "email": base.get("email"),
            "workEmail": base.get("work_email"),
            "mobile": base.get("work_mobile"),
            "country": nat,
            "state": state,
            "city": base.get("city"),
            "address": base.get("address_line1"),
            "gstin": base.get("gstin"),
            "district": district,
            "gender": base.get("gender"),
            "dateOfBirth": base.get("date_of_birth"),
            "maritalStatus": base.get("marital_status"),
            "emgContactName": base.get("emergency_contact_name"),
            "emgPhone": base.get("emergency_contact"),
            "visaNumber": base.get("visa_number"),
            "visaExpDate": base.get("visa_expiry_date"),
            "pinCode": base.get("pincode"),
            "workLocation": base.get("work_location"),
            "position": related_to_label_value(getattr(instance, "job_position", None), label_attr='name'),
            "department": related_to_label_value(getattr(instance, "department", None), label_attr='name'),
            "branch": related_to_label_value(getattr(instance, "branch", None), label_attr='name'),
            "manager": related_to_label_value(getattr(instance, "manager", None), label_attr='employee_name'),
            "lco": related_to_label_value(getattr(instance, "lco", None), label_attr='name'),  # LCO
            "image": None,
            "createdAt": base.get("created_at"),
            "updatedAt": base.get("updated_at"),
            "user": base.get("user"),
        }

        # Build image URL from model field `photo`
        photo_field = getattr(instance, "photo", None)
        if photo_field:
            try:
                rep["image"] = photo_field.url
            except Exception:
                try:
                    rep["image"] = str(photo_field)
                except Exception:
                    rep["image"] = None
        else:
            rep["image"] = None

        return rep



class BranchListSerializer(serializers.ModelSerializer):
    label = serializers.SerializerMethodField()

    class Meta:
        model = Branch
        # fields useful for a select option; include any others you want
        fields = ['id', 'name', 'branch_email', 'branch_mobile', 'label']
    
    def get_label(self, obj):
        # label used by frontend select: "Branch Name — +91xxx • email"
        parts = [obj.name]
        if obj.branch_mobile:
            parts.append(obj.branch_mobile)
        if obj.branch_email:
            parts.append(obj.branch_email)
        return " — ".join(parts)


class DepartmentListSerializer(serializers.ModelSerializer):
    label = serializers.SerializerMethodField()

    class Meta:
        model = Department
        fields = ['id', 'name', 'code', 'label']

    def get_label(self, obj):
        return f"{obj.name}" + (f" ({obj.code})" if obj.code else "")


class JobPositionListSerializer(serializers.ModelSerializer):
    label = serializers.SerializerMethodField()

    class Meta:
        model = JobPosition
        fields = ['id', 'code', 'name', 'label']

    def get_label(self, obj):
        return f"{obj.name}" + (f" — {obj.code}" if obj.code else "")




class EmployeeShortSerializer(serializers.ModelSerializer):
    name = serializers.CharField(source="employee_name")   # map employee_name -> name

    class Meta:
        model = Employee
        fields = ("id", "employee_id", "name")