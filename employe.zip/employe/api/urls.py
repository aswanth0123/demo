from django.urls import path
from .views import EmployeeCreateAPIView, BranchListAPIView, DepartmentListAPIView, JobPositionListAPIView,ManagerListAPIView,EmployeeUpdateByPKAPIView,EmployeeListAPIView,EmployeeChangeLogAPIView

urlpatterns = [
    path('create', EmployeeCreateAPIView.as_view(), name='employee-create-update'),
    path('edit/<int:pk>', EmployeeUpdateByPKAPIView.as_view(), name='employee-update'),

    path('branches/', BranchListAPIView.as_view(), name='branch-list'),
    path('departments/', DepartmentListAPIView.as_view(), name='department-list'),
    path('jobpositions/', JobPositionListAPIView.as_view(), name='jobposition-list'),
    path("managers/", ManagerListAPIView.as_view(), name="manager-list"),


    path('list/', EmployeeListAPIView.as_view(), name='employee-list'),

    path('log/<int:pk>', EmployeeChangeLogAPIView.as_view(), name='employee-changelog'),



]
