from django.contrib import admin
from .models import Branch
from .models import Department
from .models import Employee,JobPosition


@admin.register(Branch)
class BranchAdmin(admin.ModelAdmin):
    list_display = (
        'name',
        'branch_city',
        'branch_country',
        'branch_phone',
        'branch_mobile',
        'branch_email',
    )
    search_fields = ('name', 'branch_city', 'branch_country')
    list_filter = ('branch_country',)





@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display  = ('name', 'code')
    search_fields = ('name', 'code')





@admin.register(Employee)
class EmployeeAdmin(admin.ModelAdmin):
    list_display  = ('employee_name','department','branch','job_position','work_email')
    search_fields = ('employee_name','email','work_email')
    list_filter   = ('department','branch','certification_level')



@admin.register(JobPosition)
class JobPositionAdmin(admin.ModelAdmin):
    list_display  = ('code', 'name')
    search_fields = ('code', 'name')
    ordering      = ('code',)