# Standard Library
import json
import re,os
import time
import traceback
from datetime import datetime, date
from decimal import Decimal, ROUND_HALF_UP
from urllib.parse import urlencode

# Django - Core
from django.apps import apps
from django.conf import settings
from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.core.paginator import Paginator
from django.core.validators import EmailValidator
from django.db import transaction, IntegrityError
from django.db.models import Q
from django.http import JsonResponse, Http404, HttpResponseBadRequest, HttpResponseNotAllowed
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.utils import timezone
from django.utils.dateparse import parse_date as dj_parse_date
from django.views.decorators.http import require_http_methods, require_POST, require_GET
from django.core.validators import EmailValidator, RegexValidator
from collections import defaultdict
from django.contrib.messages import get_messages
from decimal import Decimal, InvalidOperation
from django.core.cache import cache

from .models import BranchChangeLog

from urllib.parse import urlparse, urlunparse, parse_qs, urlencode
from django.utils.timezone import localtime, now
# Local imports (your apps)
from .models import (
    Employee, Branch, Department, JobPosition, EmployeeChangeLog,MaritalStatus  # Add others if needed
)
from LCO.models import LCO
from warehouse.models import *
# Logging
import logging
logger = logging.getLogger(__name__)

PHONE_REGEX = re.compile(r'^\+?\d{7,15}$')

User = get_user_model()

# ==================== PERFORMANCE OPTIMIZATION FUNCTIONS ====================

def get_cached_job_positions():
    """Get job positions with 1-hour cache"""
    cache_key = 'job_positions_all'
    positions = cache.get(cache_key)
    if positions is None:
        positions = list(JobPosition.objects.order_by('name').only('id', 'name', 'code'))
        cache.set(cache_key, positions, 3600)  # Cache for 1 hour
    return positions

def get_cached_departments():
    """Get departments with 1-hour cache"""
    cache_key = 'departments_all'
    departments = cache.get(cache_key)
    if departments is None:
        departments = list(Department.objects.order_by('name').only('id', 'name', 'code'))
        cache.set(cache_key, departments, 3600)
    return departments

def get_cached_marital_statuses():
    """Get marital statuses with 1-hour cache"""
    cache_key = 'marital_statuses_all'
    statuses = cache.get(cache_key)
    if statuses is None:
        statuses = list(MaritalStatus.objects.all().only('id', 'name'))
        cache.set(cache_key, statuses, 3600)
    return statuses

def get_optimized_managers(user_id, employee_id=None):
    """Get managers with optimized query"""
    # Get manager position IDs first (more efficient than icontains)
    manager_position_ids = list(JobPosition.objects.filter(
        name__iexact='manager'
    ).values_list('id', flat=True))
    
    if not manager_position_ids:
        return []
    
    query = Employee.objects.filter(
        type_id=user_id,
        job_position_id__in=manager_position_ids
    ).select_related('job_position').only(
        'id', 'employee_name', 'job_position__name'
    )
    
    if employee_id:
        query = query.exclude(pk=employee_id)
    
    return list(query.order_by('employee_name'))



@login_required
def employee_list(request):
    # clear flashed messages (optional)
    storage = get_messages(request)
    for _ in storage:
        pass

    # Read query params
    q       = request.GET.get('q', '').strip()
    dept_id = request.GET.get('dept', '').strip()
    ipp_raw = request.GET.get('items_per_page', '10')
    page_no = request.GET.get('page', '1')

    try:
        items_per_page = int(ipp_raw)
    except (ValueError, TypeError):
        items_per_page = 10

    try:
        page_number = int(page_no)
    except (ValueError, TypeError):
        page_number = 1

    # Base queryset (we will narrow it according to logged in user)
    qs = Employee.objects.all()

    # Restrict to employees created by the logged-in user for LCO / distributer / subdistributer
    user = request.user
    lco =None
    try:
        if getattr(user, "user_type", None) == "lco" and getattr(user, "lco", None) is not None:
            # show only employees whose emp_type/type_id match this LCO
            code = getattr(user.lco, "code", None)
            lco = user.lco.name
            if code is not None:
                qs = qs.filter(emp_type="lco", type_id=str(code))
            else:
                # if code missing, return empty queryset (safer than showing others)
                qs = Employee.objects.none()

        elif getattr(user, "user_type", None) == "distributer" and getattr(user, "distributer", None) is not None:
            code = getattr(user.distributer, "code", None)
            if code is not None:
                qs = qs.filter(emp_type="distributer", type_id=str(code))
            else:
                qs = Employee.objects.none()

        elif getattr(user, "user_type", None) == "subdistributer" and getattr(user, "subdistributer", None) is not None:
            code = getattr(user.subdistributer, "code", None)
            if code is not None:
                qs = qs.filter(emp_type="subdistributer", type_id=str(code))
            else:
                qs = Employee.objects.none()
        else:
            # other user types (admin, staff, etc.) - show all employees
            qs = Employee.objects.all()
    except Exception:
        # in case of any unexpected attribute errors, fallback to empty queryset
        qs = Employee.objects.none()

    # Text search
    if q:
        qs = qs.filter(employee_name__icontains=q)

    # Department filter (if provided)
    if dept_id:
        try:
            qs = qs.filter(department_id=int(dept_id))
        except (ValueError, TypeError):
            pass

    # Order newest-first (or change to whatever you prefer)
    qs = qs.order_by('-id')

    # Paginate
    paginator = Paginator(qs, items_per_page)
    page_obj = paginator.get_page(page_number)

    # Departments for dropdown
    departments = Department.objects.order_by('name')

    # Generate HSL color for each department (consistent)
    dept_color_map = {}
    for dept in departments:
        hue = (dept.id * 137) % 360
        dept_color_map[dept.id] = f"hsl({hue},55%,75%)"

    # Annotate employees on current page with badge_color (safe)
    for emp in page_obj.object_list:
        try:
            emp.badge_color = dept_color_map.get(emp.department.id, 'hsl(0,0%,80%)')
        except Exception:
            emp.badge_color = 'hsl(0,0%,80%)'

    return render(request, 'employe/employe_list.html', {
        'employees':      page_obj.object_list,
        'page_obj':       page_obj,
        'q':              q,
        'dept_id':        dept_id,
        'departments':    departments,
        'items_per_page': items_per_page,
        'page':           page_number,
        'lco':lco
    })



@login_required
def branch_list(request):
    """
    List branches with search, pagination, and filtering by LCO.
    """
    # — flash‐message clear (optional)
    storage = get_messages(request)
    for _ in storage:
        pass

    # — Read query params
    q = request.GET.get('q', '')
    lco_id = request.GET.get('lco', '')
    ipp_raw = request.GET.get('items_per_page', '10')
    page_no = request.GET.get('page', '1')

    try:
        items_per_page = int(ipp_raw)
    except ValueError:
        items_per_page = 10

    try:
        page_number = int(page_no)
    except ValueError:
        page_number = 1

    # — Base queryset
    qs = Branch.objects.filter(type_id=request.user.user_id)
    if request.user.is_superuser:
        qs = Branch.objects.all()
    # — Text search
    if q:
        qs = qs.filter(
            Q(name__icontains=q) |
            Q(branch_code__icontains=q) |
            Q(branch_city__icontains=q) |
            Q(branch_email__icontains=q) |
            Q(branch_mobile__icontains=q) |
            Q(lco__name__icontains=q)
        )

    # — LCO filter
    if lco_id:
        qs = qs.filter(lco_id=lco_id)

    # — Order newest-first
    qs = qs.order_by('-created_at')

    # — Paginate
    paginator = Paginator(qs, items_per_page)
    page_obj = paginator.get_page(page_number)

    # — All LCOs for the dropdown
    lcos = LCO.objects.order_by('name')

    return render(request, 'employe/branch_list.html', {
        'branches': page_obj.object_list,
        'page_obj': page_obj,
        'q': q,
        'lco_id': lco_id,
        'lcos': lcos,
        'items_per_page': items_per_page,
        'page': page_number,
    })


EMP_ID_RE = re.compile(r'^EMP(\d{4})$')
PHONE_REGEX = re.compile(r'^\+?\d{7,15}$')
GSTIN_REGEX  = re.compile(r'^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$')

def get_next_employee_id():
    """
    Generates the next employee code in the form EMP-0001, EMP-0002, etc.
    """
    last = Employee.objects.order_by('-id').first()
    if not last or not last.employee_id:
        return "EMP0001"
    m = EMP_ID_RE.match(last.employee_id)
    if m:
        next_num = int(m.group(1)) + 1
    else:
        next_num = last.id + 1
    return f"EMP{next_num:04d}"


def _parse_bool(val):
    if isinstance(val, bool):
        return val
    if not val:
        return False
    return str(val).lower() in ("1", "true", "yes", "on")




def _get_model(app_label, model_name):
    try:
        return apps.get_model(app_label, model_name)
    except LookupError:
        return None

def get_branches_by_lco(request):
    lco_id = request.GET.get('lco_id')
    data = []
    lco =  LCO.objects.get(id=lco_id)

    if lco_id:
        branches = Branch.objects.filter(lco=lco).order_by('name')
        data = [{"id": b.id, "name": b.name} for b in branches]

    return JsonResponse(data, safe=False)



@login_required
def employee_create(request):

    # local imports (safe to run inside function)


    # print(">>> employee_create: ENTRY (method=%s)" % request.method)

    def _get_model(app_label, model_name):
        try:
            return apps.get_model(app_label, model_name)
        except LookupError:
            return None

    # Use cached and optimized queries
    try:
        marital_statuses = get_cached_marital_statuses()
    except Exception:
        marital_statuses = []
    
    try:
        job_positions = get_cached_job_positions()
    except Exception:
        job_positions = []
    
    try:
        departments = get_cached_departments()
    except Exception:
        departments = []
    
    try:
        managers = get_optimized_managers(request.user.user_id)
    except Exception:
        managers = []
    branches = Branch.objects.none()
    user = request.user
    type_id = None
    if user.is_authenticated:
        try:
            if user.user_type == "distributer" and hasattr(user, 'distributer'):
                type_id = user.distributer.code
                # Get all LCOs under sub-distributors of this distributor (optimized)
                lcos = LCO.objects.filter(
                    sub_distributer__distributer=user.distributer,
                    is_active=True
                ).select_related('sub_distributer', 'sub_distributer__distributer').only('id')
                lco_ids = list(lcos.values_list('id', flat=True))
                branches = Branch.objects.filter(
                    lco_id__in=lco_ids
                ).select_related('lco').only('id', 'name', 'lco__name').order_by('name')

            elif user.user_type == "subdistributer" and hasattr(user, 'subdistributer'):
                type_id = user.subdistributer.code
                # LCOs under this sub-distributor (optimized)
                lcos = LCO.objects.filter(
                    sub_distributer=user.subdistributer,
                    is_active=True
                ).select_related('sub_distributer').only('id')
                lco_ids = list(lcos.values_list('id', flat=True))
                branches = Branch.objects.filter(
                    lco_id__in=lco_ids
                ).select_related('lco').only('id', 'name', 'lco__name').order_by('name')

            elif user.user_type == "lco" and hasattr(user, 'lco'):
                type_id = user.lco.code
                # Only branches under this LCO (optimized)
                branches = Branch.objects.filter(
                    lco=user.lco
                ).select_related('lco').only('id', 'name', 'lco__name').order_by('name')

            else:
                # Optional: Superadmin or others see nothing or everything
                # branches = Branch.objects.all().order_by('name')
                pass

        except Exception as e:
            # print("Error fetching branches:", e)
            branches = Branch.objects.none()
    
    # Override with type_id filter if not already set (optimized)
    if not branches.exists() and hasattr(request.user, 'user_id'):
        branches = Branch.objects.filter(
            type_id=request.user.user_id
        ).select_related('lco').only('id', 'name', 'lco__name').order_by('name')
    
    if request.user.is_superuser:
        branches = Branch.objects.all().select_related('lco').only('id', 'name', 'lco__name').order_by('name')
    
    # one-time success token for GET
    try:
        show_success_modal = bool(request.session.pop('emp_success_token', False))
        created_employee_name = request.session.pop('emp_success_name', "")
    except Exception:
        show_success_modal = False
        created_employee_name = ""

    # small helpers
    def to_camel(s):
        parts = s.split('_')
        return parts[0] + ''.join(p.title() for p in parts[1:]) if s else s

    def to_snake(s):
        if not s:
            return s
        s1 = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', s)
        s2 = re.sub('([a-z0-9])([A-Z])', r'\1_\2', s1)
        return s2.replace('-', '_').lower()

    def normalize_date_string(s):
        if s is None:
            return s
        s = str(s).strip()
        if not s:
            return s
        if len(s) >= 2 and ((s[0] == s[-1] == '"') or (s[0] == s[-1] == "'")):
            s = s[1:-1].strip()
        s = re.sub(r'[\u2010\u2011\u2012\u2013\u2014\u2015\u2212]', '-', s)
        s = s.replace('/', '-')
        s = re.sub(r'\s+', ' ', s).strip()
        return s

    def parse_date_flexible(s):
        if not s:
            return None
        s = normalize_date_string(s)
        try:
            return datetime.date.fromisoformat(s)
        except Exception:
            pass
        try:
            d = dj_parse_date(s)
            if d:
                return d
        except Exception:
            pass
        for fmt in ('%d-%m-%Y', '%d/%m/%Y', '%m-%d-%Y', '%m/%d/%Y', '%Y/%m/%d', '%Y.%m.%d', '%d.%m.%Y', '%d %b %Y', '%d %B %Y'):
            try:
                return datetime.datetime.strptime(s, fmt).date()
            except Exception:
                pass
        try:
            from dateutil import parser as _du
            dt = _du.parse(s, dayfirst=True, yearfirst=False)
            return dt.date()
        except Exception:
            pass
        return None

    def get_choice_default(model_cls, field_name, fallback):
        try:
            f = model_cls._meta.get_field(field_name)
            choices = getattr(f, 'choices', None) or []
            if choices:
                return choices[0][0]
        except Exception:
            pass
        return fallback

    # template posted fields
    template_post_fields = [
        'name', 'email', 'mobile', 'gender', 'branch', 'position', 'department', 'manager',
        'workEmail', 'workMobile', 'workPhone', 'employeeId', 'workLocation', 'visaNumber',
        'workPermitNumber', 'visaExpDate', 'address', 'dateOfBirth', 'maritalStatus', 'country',
        'state', 'district', 'city', 'pinCode', 'aadhaarNumber', 'passportNumber', 'numberOfChildren',
        'emgContactName', 'emgPhone', 'password', 'confirmPassword', 'work_permit',
        # new multi-select
        'allowed_branches',
         'basicSalary', 'da', 'hra','type','username','is_active'
    ]

    # Build posted dict
    if request.method == "POST":
        # Get scalar posted values (trim)
        posted = {k: (request.POST.get(k, '') or '').strip() for k in template_post_fields}
         # Extract the new fields: basic salary, DA, HRA
        basic_salary = posted.get('basicSalary', 0.00)
        da = posted.get('da', 0.00)
        hra = posted.get('hra', 0.00)
        # Get multi-select as list (strings)
        posted_allowed_branches = request.POST.getlist('allowed_branches')
        posted['allowed_branches'] = posted_allowed_branches
        safe_posted = posted.copy()
        if 'password' in safe_posted:
            safe_posted['password'] = '***'
        if 'confirmPassword' in safe_posted:
            safe_posted['confirmPassword'] = '***'
        # print("DEBUG: posted (safe):", safe_posted)
    else:
        posted = {k: '' for k in template_post_fields}
        # ensure posted.allowed_branches exists for template convenience
        posted['allowed_branches'] = []

    # defaults for GET render/preserve
    employee_data_defaults = {
        "employee_name": posted.get('name', ''),
        "email": posted.get('email', ''),
        "country": posted.get('country', ''),
        "state": posted.get('state', ''),
        "district": posted.get('district', ''),
        "date_of_birth": posted.get('dateOfBirth', ''),
        "marital_status": posted.get('maritalStatus', ''),
        "gender": posted.get('gender', ''),
        # "lco_id": posted.get('lco', ''),
        "branch_id": posted.get('branch', ''),
        "position_id": posted.get('position', ''),
        "department_id": posted.get('department', ''),
        "manager_id": posted.get('manager', ''),
        "work_email": posted.get('workEmail', ''),
        "work_mobile": posted.get('workMobile', ''),
        "personal_mobile": posted.get('mobile', ''),
        "work_phone": posted.get('workPhone', ''),
        "employee_id": posted.get('employeeId', ''),
        "work_location": posted.get('workLocation', ''),
        "visa_number": posted.get('visaNumber', ''),
        "visa_expiry_date": posted.get('visaExpDate', ''),
        "pincode": posted.get('pinCode', ''),
        "city": posted.get('city', ''),
        "address_line1": posted.get('address', ''),
        "emergency_contact_name": posted.get('emgContactName', ''),
        "emergency_contact": posted.get('emgPhone', ''),
        "aadhaar_number": posted.get('aadhaarNumber', ''),
        "passport_number": posted.get('passportNumber', ''),
        "number_of_children": posted.get('numberOfChildren', ''),
        "work_permit": posted.get('workPermitNumber', ''),
        "allowed_branches": posted.get('allowed_branches', []),  # keep list for template
        "type": posted.get('type', '') ,
        "username": posted.get('username', ''),
        "emp_type": request.user.user_type,
        "type_id": type_id,
    
    }

    # GET -> render
    if request.method == "GET":
        # print("DEBUG: GET request")
        # print(branches)
        context = {
            "branches": branches,
            "departments": departments,
            "job_positions": job_positions,
            "managers": managers,
            # "lcos": lco_choices,
            # "selected_lco_id": selected_lco_id,
            # "disable_lco_select": disable_lco_select,
            "errors": defaultdict(str),
            "employee_data": employee_data_defaults,
            "posted": posted,
            "show_success_modal": show_success_modal,
            "created_employee_name": created_employee_name,
            "non_field_errors": '',
            'marital_statuses': marital_statuses,
        }
        return render(request, 'employe/employee_create.html', context)

    # ---------- POST processing ----------

    # Employee data to be saved (from posted)
    marital_status = posted.get('maritalStatus', '')
    if marital_status:
        marital_status = MaritalStatus.objects.filter(id=marital_status).first()
    else:
        marital_status = None



    is_active = posted.get('is_active') == '1'  # 'is_active' will be '1' if checked, otherwise None
    

        
    employee_data = {
        "employee_name": posted.get("name", ""),
        "email": posted.get("email", ""),
        "country": posted.get("country", ""),
        "state": posted.get("state", ""),
        "district": posted.get("district", ""),
        "date_of_birth": posted.get("dateOfBirth", ""),
        "marital_status":marital_status ,
        "gender": posted.get("gender", ""),
        # "lco_id": posted.get("lco", ""),
        "branch_id": posted.get("branch", ""),
        "position_id": posted.get("position", ""),
        "department_id": posted.get("department", ""),
        "manager_id": posted.get("manager", ""),
        "work_email": posted.get("workEmail", ""),
        "work_mobile": posted.get("workMobile", ""),
        "personal_mobile": posted.get("mobile", ""),
        "work_phone": posted.get("workPhone", ""),
        "employee_id": posted.get("employeeId", ""),
        "work_location": posted.get("workLocation", ""),
        "visa_number": posted.get("visaNumber", ""),
        "visa_expiry_date": posted.get("visaExpDate", ""),
        "pincode": posted.get("pinCode", ""),
        "city": posted.get("city", ""),
        "address_line1": posted.get("address", ""),
        "emergency_contact_name": posted.get("emgContactName", ""),
        "emergency_contact": posted.get("emgPhone", ""),
        "aadhaar_number": posted.get("aadhaarNumber", ""),
        "passport_number": posted.get("passportNumber", ""),
        "number_of_children": posted.get("numberOfChildren", ""),
        "work_permit": posted.get("workPermitNumber", ""),
        "allowed_branches": posted.get('allowed_branches', []),
        "basic_salary": basic_salary,
        "da": da,
        "hra": hra,
        "type": posted.get('type', ''),
        "username": posted.get('username', ''),
        "is_active": is_active,
    }

    # Handle image upload
    image = request.FILES.get('photo') or request.FILES.get('image') or request.FILES.get('employee-image-upload')
    if image:
        # print("DEBUG: uploaded file name=%s size=%s" % (getattr(image, 'name', ''), getattr(image, 'size', 'n/a')))
        pass

    password = posted.get("password", "")
    confirm_password = posted.get("confirmPassword", "")

    errors = {}
    type = (posted.get('type') or '').strip()
    if type and type not in ('limited', 'admin'):
        errors['type'] = "Invalid type selected."
    # Server-side validations (keep your current rules)
    if not employee_data["employee_name"]:
        errors["name"] = "Full Name is required."

    # if not employee_data["email"]:
    #     errors["email"] = "Email is required."
    if employee_data["email"]:
        try:
            EmailValidator()(employee_data["email"])
        except ValidationError:
            errors["email"] = "Enter a valid email address."

    # uniqueness checks (defensive)
    try:
        if Employee is not None and employee_data["email"]:
            if Employee.objects.filter(email__iexact=employee_data["email"]).exists():
                errors["email"] = "Email already exists."
    except Exception as exc:
        # print("DEBUG: email uniqueness check failed:", exc)
        pass

    if not employee_data["employee_id"]:
        errors["employee_id"] = "Employee ID is required."
    else:
        try:
            if Employee is not None and Employee.objects.filter(employee_id__iexact=employee_data["employee_id"]).exists():
                errors["employee_id"] = "Employee ID already exists."
        except Exception as exc:
            # print("DEBUG: employee_id uniqueness check failed:", exc)
            pass

    if not employee_data["country"]:
        errors["country"] = "Country is required."

    if not employee_data["gender"]:
        errors["gender"] = "Gender is required."

    # Date parsing
    raw_dob = employee_data.get("date_of_birth", "")
    parsed_dob = parse_date_flexible(raw_dob)
    # if not raw_dob:
    #     errors["dateOfBirth"] = "Date of birth is required."
    # elif parsed_dob is None:
    #     errors["dateOfBirth"] = "Invalid date. Use YYYY-MM-DD or DD-MM-YYYY."
    if parsed_dob:
        employee_data["date_of_birth"] = parsed_dob.isoformat()

    # if not employee_data["marital_status"]:
    #     errors["maritalStatus"] = "Marital status is required."

    if not employee_data['username']:
        errors['username'] = "Username is required."
    else:
        try:
            if User.objects.filter(username__iexact=employee_data["username"]).exists():
                errors["username"] = "Username already exists."
        except Exception as exc:
            # print("DEBUG: username uniqueness check failed:", exc)
            pass

    # Work Email validation
    # if not employee_data["work_email"]:
    #     errors["workEmail"] = "Work Email is required."
    # else:
    #     try:
    #         EmailValidator()(employee_data["work_email"])
    #     except ValidationError:
    #         errors["workEmail"] = "Enter a valid work email address."

    # if not employee_data["work_mobile"]:
    #     errors["workMobile"] = "Work Mobile is required."

    # if not employee_data["work_location"]:
    #     errors["workLocation"] = "Work Location is required."

    # Aadhaar/passport checks
    aad = employee_data.get("aadhaar_number", "")
    if aad and not re.fullmatch(r'\d{12}', aad):
        errors["aadhaarNumber"] = "Aadhaar must be exactly 12 digits."

    passport_val = employee_data.get("passport_number", "")
    if passport_val and not re.fullmatch(r'[A-Za-z0-9\-/\s]{3,20}', passport_val):
        errors["passportNumber"] = "Enter a valid passport number (3–20 characters)."

    # Number-of-children
    noc_raw = employee_data.get("number_of_children", "")
    number_of_children_val = None
    if noc_raw != "":
        try:
            noc_int = int(noc_raw)
            if noc_int < 0:
                errors["numberOfChildren"] = "Number of children cannot be negative."
            else:
                number_of_children_val = noc_int
        except ValueError:
            errors["numberOfChildren"] = "Number of children must be an integer."

    # Resolve FK relations (branch/department/position/manager/lco)
    selected_branch = None
    if employee_data["branch_id"]:
        try:
            if Branch is not None:
                selected_branch = Branch.objects.get(pk=employee_data["branch_id"])
        except Exception:
            errors["branch"] = "Selected Branch not found."

    selected_department = None
    if not employee_data["department_id"]:
        errors["department"] = "Department is required."
    else:
        try:
            if Department is not None:
                selected_department = Department.objects.get(pk=employee_data["department_id"])
        except Exception:
            errors["department"] = "Selected Department not found."

    selected_position = None
    if employee_data["position_id"]:
        try:
            if JobPosition is not None:
                selected_position = JobPosition.objects.get(pk=employee_data["position_id"])
        except Exception:
            errors["position"] = "Selected Position not found."

    selected_manager = None
    if employee_data["manager_id"]:
        try:
            if Employee is not None:
                selected_manager = Employee.objects.get(pk=employee_data["manager_id"])
        except Exception:
            errors["manager"] = "Selected Manager not found."

    selected_lco = None
    # if employee_data["lco_id"]:
    #     try:
    #         if LCO is not None:
    #             selected_lco = LCO.objects.get(pk=employee_data["lco_id"])
    #     except Exception:
    #         errors["lco"] = "Selected LCO not found."

    # --- Validate allowed_branches posted values and build allowed_branch_ids list ---
    allowed_branch_ids = []
    invalid_allowed = []
    posted_allowed = posted.get('allowed_branches', []) or []
    if posted_allowed:
        for v in posted_allowed:
            try:
                bid = int(v)
            except (ValueError, TypeError):
                invalid_allowed.append(v)
                continue
            try:
                if Branch is not None and Branch.objects.filter(pk=bid).exists():
                    allowed_branch_ids.append(bid)
                else:
                    invalid_allowed.append(v)
            except Exception:
                invalid_allowed.append(v)
    # if invalid, flag error (non-fatal: you can choose to ignore invalid ones; here we report)
    if invalid_allowed:
        errors['allowed_branches'] = "One or more selected branches are invalid."

    # Password handling
    create_user_flag = False
    if password or confirm_password:
        if password != confirm_password:
            errors["password"] = "Passwords do not match."
            errors["confirmPassword"] = "Passwords do not match."
        elif len(password) < 6:
            errors["password"] = "Password must be at least 6 characters."
        else:
            create_user_flag = True

    # If errors -> normalize and re-render (always include posted)
    if errors:
        # print("DEBUG: validation errors detected:", errors)
        norm_errors = {}
        for k, v in errors.items():
            norm_errors[k] = v
            try:
                norm_errors[to_camel(k)] = v
                norm_errors[to_snake(k)] = v
            except Exception:
                pass

        form_field_names = [
            'name','email','mobile','gender','username','branch','position','department','manager',
            'workEmail','workMobile','workPhone','employeeId','employee_id','workLocation','visaNumber','workPermitNumber','visaExpDate',
            'address','dateOfBirth','maritalStatus','country','state','district','city','pinCode',
            'aadhaarNumber','passportNumber','numberOfChildren','emgContactName','emgPhone',
            'password','confirmPassword','allowed_branches','is_active'
        ]

        def lookup_msg(key):
            if key in norm_errors and norm_errors[key]:
                return norm_errors[key]
            sn = to_snake(key); cm = to_camel(key)
            for try_key in (sn, cm, sn.lower(), cm.lower(), key.lower()):
                if try_key in norm_errors and norm_errors[try_key]:
                    return norm_errors[try_key]
            alt_map = {
                'employeeId': 'employee_id',
                'dateOfBirth': 'date_of_birth',
                'workEmail': 'work_email',
                'workMobile': 'work_mobile',
                'pinCode': 'pincode',
                'aadhaarNumber': 'aadhaar_number',
                'passportNumber': 'passport_number',
                'numberOfChildren': 'number_of_children',
                'workPermitNumber': 'work_permit',
                'workLocation': 'work_location'
            }
            if key in alt_map:
                ak = alt_map[key]
                if ak in norm_errors and norm_errors[ak]:
                    return norm_errors[ak]
                if to_camel(ak) in norm_errors and norm_errors[to_camel(ak)]:
                    return norm_errors[to_camel(ak)]
            return ''

        final_errors = {}
        for fname in form_field_names:
            msg = lookup_msg(fname)
            if msg:
                final_errors[fname] = msg

        non_field = norm_errors.get('__all__') or norm_errors.get('non_field_errors') or ''
        safe_errors = defaultdict(str, final_errors)

        # Normalize employee_data for template so posted values persist
        norm_emp = {}
        for k, v in employee_data.items():
            norm_emp[k] = v
            try:
                norm_emp[to_camel(k)] = v
                norm_emp[to_snake(k)] = v
            except Exception:
                pass

        context = {
            "errors": safe_errors,
            "field_errors": final_errors,
            "branches": branches,
            "departments": departments,
            "job_positions": job_positions,
            "managers": managers,
            # "lcos": lco_choices,
            # "selected_lco_id": selected_lco_id,
            # "disable_lco_select": disable_lco_select,
            "employee_data": norm_emp,
            "posted": posted,
            "non_field_errors": non_field,
            "show_success_modal": False,
            "created_employee_name": "",
            'marital_statuses': marital_statuses
        }
        return render(request, 'employe/employee_create.html', context)

    # ---------- Create Employee ----------
    cert_default = get_choice_default(Employee, 'certification_level', 'NA') if Employee is not None else 'NA'
    work_permit_default = get_choice_default(Employee, 'work_permit', 'no') if Employee is not None else 'no'
    work_permit_value = posted.get('workPermitNumber', '').strip()
    work_permit = work_permit_value if work_permit_value else None

    field_of_study_default = 'Not specified'
    school_default = 'Not specified'



    emp_kwargs = {
        "employee_name": employee_data["employee_name"],
        "email": employee_data["email"] or None,
        "nationality": employee_data["country"] or None,
        "state": employee_data["state"] or None,
        "district": employee_data["district"] or None,
        "gender": employee_data["gender"] or None,
        "date_of_birth": parsed_dob if parsed_dob is not None else None,
        "marital_status": employee_data["marital_status"] or None,
        "branch": selected_branch,
        "job_position": selected_position,
        "department": selected_department,
        "manager": selected_manager,
        "work_email": employee_data["work_email"] or None,
        "personal_mobile": employee_data["personal_mobile"],
        "work_mobile": employee_data["work_mobile"] or None,
        "work_phone": employee_data["work_phone"],
        "employee_id": employee_data["employee_id"] or None,
        "work_location": employee_data["work_location"] or None,
        "visa_number": employee_data["visa_number"] or None,
        "pincode": employee_data["pincode"] or None,
        "city": employee_data["city"] or None,
        "address_line1": employee_data["address_line1"] or None,
        "emergency_contact_name": employee_data["emergency_contact_name"] or None,
        "emergency_contact": employee_data["emergency_contact"] or None,
        "aadhaar_number": employee_data.get("aadhaar_number") or None,
        "passport_number": employee_data.get("passport_number") or None,
        "number_of_children": number_of_children_val if number_of_children_val is not None else None,
        # model defaults
        "certification_level": cert_default,
        "field_of_study": field_of_study_default,
        "school": school_default,
        "work_permit": work_permit,
        # New fields for salary
    "basic_salary": basic_salary or None,
    "da": da or None,
    "hra": hra or None,
    "type": employee_data.get("type") or 'limited',
    "created_by": request.user,
    "emp_type": request.user.user_type,
    "type_id": type_id,
    # Include the is_active field here
    "is_active": employee_data["is_active"],
    }

    # print("DEBUG: emp_kwargs prepared -> keys:", list(emp_kwargs.keys()))

    try:
        with transaction.atomic():
            new_emp = Employee(**emp_kwargs)

            # attach photo if provided
            if image:
                try:
                    new_emp.photo.save(image.name, image, save=False)
                except Exception:
                    try:
                        setattr(new_emp, 'photo', image)
                    except Exception:
                        pass

            # model validation
            try:
                new_emp.full_clean()
            except ValidationError as ve:
                vdict = {}
                for fld, msgs in ve.message_dict.items():
                    vdict[fld] = msgs[0] if isinstance(msgs, (list, tuple)) else str(msgs)
                # print("employee_create: model.full_clean() errors ->", vdict)
                final_errors = {}
                for k, vv in vdict.items():
                    final_errors[k] = vv
                    try:
                        final_errors[to_camel(k)] = vv
                        final_errors[to_snake(k)] = vv
                    except Exception:
                        pass
                context = {
                    "errors": defaultdict(str, final_errors),
                    "field_errors": final_errors,
                    "branches": branches,
                    "departments": departments,
                    "job_positions": job_positions,
                    "managers": managers,
                    # "lcos": lco_choices,
                    "employee_data": employee_data,
                    "posted": posted,
                    "non_field_errors": '',
                    "show_success_modal": False,
                    "created_employee_name": "",
                    'marital_statuses': marital_statuses
                }
                return render(request, 'employe/employee_create.html', context)

            # save primary model row
            new_emp.save()
            # print(f"employee_create: saved Employee pk={new_emp.pk} name={new_emp.employee_name}")

            # --- set allowed branches M2M (if model has the m2m field) ---
            try:
                if hasattr(new_emp, 'allowed_branches'):
                    # allowed_branch_ids is a list of ints built earlier; set it (empty list clears)
                    new_emp.allowed_branches.set(allowed_branch_ids)
                    # print("DEBUG: allowed_branches set ->", allowed_branch_ids)
                else:
                    # print("DEBUG: Employee model has no attribute 'allowed_branches' - skipping M2M set")
                    pass
            except Exception as e:
                # print("ERROR: failed to set allowed_branches:", e)
                pass

            if create_user_flag:
                UserModel = get_user_model()
                username_field = getattr(UserModel, 'USERNAME_FIELD', 'username')
                username_value = (
                    employee_data.get('username') or
                    employee_data.get('employee_id') or
                    f"emp{int(time.time())}"
                )

                try:
                    # Step 1: Create user with required base fields
                    created_user = UserModel.objects.create_user(
                        **{
                            username_field: username_value,
                            'password': password,
                            'user_type': 'employee',  # or other type as needed
                            'employee': new_emp,      # Link to created Employee
                            'user_id': new_emp.employee_id,

                            # Add these only if relevant in your context:
                            # 'distributer': employee_data.get('distributer'),
                            # 'subdistributer': employee_data.get('subdistributer'),
                            # 'lco': employee_data.get('lco'),
                        }
                    )

                    # Step 2: Optionally set names from employee_name
                    full_name = (employee_data.get('employee_name') or '').strip()
                    if full_name:
                        parts = full_name.split(None, 1)
                        created_user.first_name = parts[0]
                        created_user.last_name = parts[1] if len(parts) > 1 else ''
                        created_user.save(update_fields=['first_name', 'last_name'])

                    # print(f"Custom user created and linked to employee: {created_user}")

                except Exception as exc:
                    # print("employee_create: failed creating CustomUser:", exc)
                    pass


            # changelog (best-effort)
            try:
                if EmployeeChangeLog is not None:
                    # include allowed_branches ids in the snapshot (employee_data already contains them)
                    EmployeeChangeLog.objects.create(
                        employee=new_emp,
                        changed_by=(request.user if getattr(request, "user", None) and request.user.is_authenticated else None),
                        action=(getattr(EmployeeChangeLog, 'ACTION_CREATE', 'create')),
                        changes=json.dumps({"old": None, "new": employee_data}, default=str),
                        summary=f"Created Employee: {new_emp.employee_name}"
                    )
                    # print("employee_create: EmployeeChangeLog created")
            except Exception as exc:
                # print("employee_create: changelog creation failed:", exc)
                pass

    except IntegrityError as ie:
        # print("employee_create: IntegrityError while creating employee/user:", ie)
        errors = {"__all__": "A unique constraint prevented saving. " + str(ie)}
        context = {
            "errors": defaultdict(str, errors),
            "branches": branches,
            "departments": departments,
            "job_positions": job_positions,
            "managers": managers,
            # "lcos": lco_choices,
            "employee_data": employee_data,
            "posted": posted,
            "non_field_errors": errors.get("__all__", ""),
            "show_success_modal": False,
            "created_employee_name": "",
            'marital_statuses': marital_statuses
        }
        return render(request, 'employe/employee_create.html', context)
    except Exception as exc:
        # print("employee_create: Unexpected error creating employee/user:", exc)
        errors = {"__all__": "An unexpected error occurred while saving. Contact admin."}
        context = {
            "errors": defaultdict(str, errors),
            "branches": branches,
            "departments": departments,
            "job_positions": job_positions,
            "managers": managers,
            # "lcos": lco_choices,
            "employee_data": employee_data,
            "posted": posted,
            "non_field_errors": errors.get("__all__", ""),
            "show_success_modal": False,
            "created_employee_name": "",
            'marital_statuses': marital_statuses
        }
        return render(request, 'employe/employee_create.html', context)

    # success: set one-time session token and redirect back (so your modal appears)
    try:
        request.session['emp_success_token'] = f"emp_created:{new_emp.pk}:{int(time.time())}"
        request.session['emp_success_name'] = new_emp.employee_name
        # print("employee_create: set session success token")
    except Exception as exc:
        # print("employee_create: warning - could not set session token:", exc)
        messages.success(request, f"Employee {new_emp.employee_name} created.")

    return redirect(reverse('employee:employee_create'))









@require_http_methods(["GET", "POST"])
@login_required
def employee_edit(request, employee_id):
    """
    Full updated employee_edit view.
    Sync linked auth User's email (and username when appropriate) when employee email changes.
    """
    # Local imports (safe if you paste this function standalone)

    # print(">>> employee_edit: ENTRY (method=%s, employee_id=%s)" % (request.method, employee_id))

    def _get_model(app_label, model_name):
        try:
            return apps.get_model(app_label, model_name)
        except LookupError:
            return None

    # Use direct model imports (already imported at top)
    employee = get_object_or_404(Employee, pk=employee_id)
    
    # Use cached and optimized queries
    try:
        job_positions = get_cached_job_positions()
    except Exception as e:
        # print(f"Error fetching job positions: {e}")
        job_positions = []

    try:
        departments = get_cached_departments()
    except Exception as e:
        # print(f"Error fetching departments: {e}")
        departments = []
    
    try:
        managers = get_optimized_managers(request.user.user_id, employee_id=employee_id)
    except Exception as e:
        # print(f"Error fetching managers: {e}")
        managers = []
    branches = Branch.objects.none()
    user = request.user
    # print(f"DEBUG: User type: {user.user_type}")
    # print(user.lco.code)
    type_id = None
    if user.is_authenticated:
        try:
            if user.user_type == "distributer" and hasattr(user, 'distributer'):
                type_id = user.distributer.code
                # Get all LCOs under sub-distributors of this distributor (optimized)
                lcos = LCO.objects.filter(
                    sub_distributer__distributer=user.distributer,
                    is_active=True
                ).select_related('sub_distributer', 'sub_distributer__distributer').only('id')
                lco_ids = list(lcos.values_list('id', flat=True))
                branches = Branch.objects.filter(
                    lco_id__in=lco_ids
                ).select_related('lco').only('id', 'name', 'lco__name').order_by('name')

            elif user.user_type == "subdistributer" and hasattr(user, 'subdistributer'):
                type_id = user.subdistributer.code
                # LCOs under this sub-distributor (optimized)
                lcos = LCO.objects.filter(
                    sub_distributer=user.subdistributer,
                    is_active=True
                ).select_related('sub_distributer').only('id')
                lco_ids = list(lcos.values_list('id', flat=True))
                branches = Branch.objects.filter(
                    lco_id__in=lco_ids
                ).select_related('lco').only('id', 'name', 'lco__name').order_by('name')

            elif user.user_type == "lco" and hasattr(user, 'lco'):
                type_id = user.lco.code
                # Only branches under this LCO (optimized)
                branches = Branch.objects.filter(
                    lco=user.lco
                ).select_related('lco').only('id', 'name', 'lco__name').order_by('name')

            else:
                # Optional: Superadmin or others see nothing or everything
                # branches = Branch.objects.all().order_by('name')
                pass

        except Exception as e:
            # print("Error fetching branches:", e)
            branches = Branch.objects.none()
    
    # Override with type_id filter if not already set (optimized)
    if not branches.exists() and hasattr(request.user, 'user_id'):
        branches = Branch.objects.filter(
            type_id=request.user.user_id
        ).select_related('lco').only('id', 'name', 'lco__name').order_by('name')
    
    if request.user.is_superuser:
        branches = Branch.objects.all().select_related('lco').only('id', 'name', 'lco__name').order_by('name')
    # ----------------- helpers for assignments / fk setting -----------------
    def _model_field_allows_null_for_post(instance, field_name):
        lookup_name = field_name[:-3] if field_name.endswith('_id') else field_name
        try:
            f = instance._meta.get_field(lookup_name)
        except Exception:
            return True
        return getattr(f, 'null', True)

    def _model_field_allows_assignment(instance, field_name, incoming_value):
        try:
            f = instance._meta.get_field(field_name)
        except Exception:
            return True
        if incoming_value in (None, ''):
            if getattr(f, 'blank', True) or getattr(f, 'null', False):
                return True
            return False
        return True

    def _set_fk_if_provided(instance, fk_attr, model_class, incoming_value):
        if incoming_value in (None, ''):
            if _model_field_allows_null_for_post(instance, fk_attr):
                setattr(instance, fk_attr, None)
                # print(f"DEBUG: Setting {fk_attr} = None (allowed)")
                return True
            else:
                # print(f"DEBUG: Skipping {fk_attr} because incoming is empty and field is NOT NULL (preserve existing)")
                return False
        try:
            fk_id = int(incoming_value)
        except (ValueError, TypeError):
            # print(f"DEBUG: Invalid FK id for {fk_attr}: {incoming_value!r} (skipping)")
            return False
        try:
            obj = model_class.objects.get(pk=fk_id)
        except Exception as e:
            # print(f"DEBUG: Related object not found for {fk_attr} id={fk_id}: {e} (skipping)")
            return False
        setattr(instance, fk_attr, obj)
        # print(f"DEBUG: Set {fk_attr} -> {model_class.__name__}(pk={fk_id})")
        return True

    # ----------------- changelog grouping helper -----------------
    def build_change_groups(emp):
        """
        Return (create_groups, update_groups) suitable for the template modal.
    
        - Normalizes values for comparison and skips fields where old == new after normalization.
        - Resolves FK-like fields to readable names via _resolve_fk_name.
        - Extracts filenames for 'photo' changes.
        - Skips adding update groups that end up with no visible changes.
        """
        create_groups = []
        update_groups = []
        try:
            import os
            import json
            from decimal import Decimal
            from django.utils import timezone
    
            # Limit to last 50 entries for performance
            logs_qs = list(emp.change_logs.select_related('changed_by').order_by('-created_at')[:50])
            # debug
            # print(f"DEBUG: build_change_groups: found {len(logs_qs)} change log entries for employee pk={getattr(emp, 'pk', None)}")
            if not logs_qs:
                return create_groups, update_groups
    
            def _changed_by_display(u):
                if not u:
                    return "System / Unknown"
                try:
                    if getattr(u, "get_full_name", None):
                        full = u.get_full_name()
                        if full:
                            return full
                    if getattr(u, "username", None):
                        return u.username
                    return str(u)
                except Exception:
                    return str(u)
    
            def _ts_key(dt):
                if not dt:
                    return ""
                if isinstance(dt, datetime):
                    try:
                        dt2 = dt.replace(microsecond=0)
                    except Exception:
                        dt2 = dt
                    return dt2.isoformat()
                return str(dt)
    
            def _resolve_fk_name(field_key, v):
                try:
                    if v in (None, ""):
                        return ""
                    if isinstance(v, dict) and v.get("name"):
                        return str(v.get("name"))
                    if isinstance(v, (list, tuple)):
                        resolved = []
                        for item in v:
                            if isinstance(item, dict) and item.get("name"):
                                resolved.append(str(item.get("name")))
                                continue
                            s_item = str(item)
                            if s_item.isdigit():
                                pk = int(s_item)
                                if field_key in ("allowed_branches", "allowed_branch", "branch", "branch_id") and Branch is not None:
                                    obj = Branch.objects.filter(pk=pk).first()
                                    resolved.append(obj.name if obj else s_item)
                                    continue
                                if field_key in ("lco", "lco_id") and LCO is not None:
                                    obj = LCO.objects.filter(pk=pk).first()
                                    resolved.append(obj.name if obj else s_item)
                                    continue
                                if field_key in ("job_position", "position", "position_id") and JobPosition is not None:
                                    obj = JobPosition.objects.filter(pk=pk).first()
                                    resolved.append(obj.name if obj else s_item)
                                    continue
                                if field_key in ("department", "department_id") and Department is not None:
                                    obj = Department.objects.filter(pk=pk).first()
                                    resolved.append(obj.name if obj else s_item)
                                    continue
                                if field_key in ("manager", "manager_id") and Employee is not None:
                                    obj = Employee.objects.filter(pk=pk).first()
                                    resolved.append(getattr(obj, "employee_name", s_item) if obj else s_item)
                                    continue
                            resolved.append(s_item)
                        return ", ".join([r for r in resolved if r is not None and r != ""])
                    s = str(v)
                    if s.isdigit():
                        pk = int(s)
                        if field_key in ("lco", "lco_id") and LCO is not None:
                            obj = LCO.objects.filter(pk=pk).first()
                            return obj.name if obj else s
                        if field_key in ("branch", "branch_id") and Branch is not None:
                            obj = Branch.objects.filter(pk=pk).first()
                            return obj.name if obj else s
                        if field_key in ("job_position", "position", "position_id") and JobPosition is not None:
                            obj = JobPosition.objects.filter(pk=pk).first()
                            return obj.name if obj else s
                        if field_key in ("department", "department_id") and Department is not None:
                            obj = Department.objects.filter(pk=pk).first()
                            return obj.name if obj else s
                        if field_key in ("manager", "manager_id") and Employee is not None:
                            obj = Employee.objects.filter(pk=pk).first()
                            return getattr(obj, "employee_name", s) if obj else s
                    return s
                except Exception:
                    return str(v)
    
            # helper: pretty field name (snake_case -> human readable)
            def _prettify_field_name(field_key):
                if not field_key:
                    return ""
                fk_suffix = False
                if field_key.endswith("_id"):
                    field_key = field_key[:-3]
                    fk_suffix = True
    
                explicit = {
                    "employee_name": "Name",
                    "work_email": "Work Email",
                    "work_mobile": "Work Mobile",
                    "personal_mobile": "Personal Mobile",
                    "work_phone": "Work Phone",
                    "aadhaar_number": "Aadhaar Number",
                    "passport_number": "Passport Number",
                    "date_of_birth": "Date of birth",
                    "number_of_children": "Number of children",
                    "address_line1": "Address",
                    "pincode": "Pincode",
                    "pin_code": "Pincode",
                    "visa_expiry_date": "Visa expiry date",
                    "visa_number": "Visa number",
                    "work_location": "Work location",
                    "emergency_contact_name": "Emergency contact name",
                    "emergency_contact": "Emergency contact",
                    "allowed_branches": "Allowed branches",
                    "branch": "Branch",
                    "lco": "LCO",
                    "job_position": "Position",
                    "position": "Position",
                    "department": "Department",
                    "manager": "Manager",
                    "nationality": "Nationality",
                    "state": "State",
                    "district": "District",
                }
                if field_key in explicit:
                    return explicit[field_key]
    
                pf = field_key.replace("_", " ").strip().title()
                pf = pf.replace(" Of ", " of ").replace(" And ", " and ")
                pf = pf.replace("Lco", "LCO").replace("Job Position", "Position").replace("Allowed Branches", "Allowed branches")
                if fk_suffix and pf.endswith(" Id"):
                    pf = pf[:-3].strip()
                return pf
    
            # Normalization helpers to decide if old/new are meaningfully different
            def _normalize_value_for_compare(v):
                # None-like
                if v is None:
                    return None
    
                # Decimal, int, float -> Decimal for numeric comparsion
                if isinstance(v, Decimal):
                    return None if v == Decimal("0") else v
                if isinstance(v, (int, float)):
                    try:
                        dv = Decimal(str(v))
                        return None if dv == Decimal("0") else dv
                    except Exception:
                        pass
    
                # dict: prefer 'name' if present
                if isinstance(v, dict):
                    if v.get("name"):
                        s = str(v.get("name")).strip()
                    else:
                        s = str(v).strip()
                    return s.casefold() if s else None
    
                # list/tuple: join parts
                if isinstance(v, (list, tuple)):
                    try:
                        parts = []
                        for item in v:
                            if isinstance(item, dict) and item.get("name"):
                                parts.append(str(item.get("name")).strip())
                            else:
                                parts.append(str(item).strip())
                        joined = ", ".join(p for p in parts if p)
                        return joined.casefold() if joined else None
                    except Exception:
                        try:
                            return str(v).strip().casefold()
                        except Exception:
                            return None
    
                # strings: strip, handle 'null'/'none', try numeric
                try:
                    s = str(v).strip()
                except Exception:
                    s = str(v)
                if s == "":
                    return None
                low = s.lower()
                if low in ("null", "none"):
                    return None
                # numeric string -> Decimal
                try:
                    d = Decimal(s)
                    return None if d == Decimal("0") else d
                except Exception:
                    return s.casefold()
    
            def _values_equivalent(old_val, new_val):
                try:
                    return _normalize_value_for_compare(old_val) == _normalize_value_for_compare(new_val)
                except Exception:
                    return False
    
            # Group logs by (who, timestamp) preserving order
            groups_map = {}
            ordered_keys = []
    
            for log in logs_qs:
                who_pk = getattr(getattr(log, "changed_by", None), "pk", None)
                ts = getattr(log, "created_at", None) or getattr(log, "timestamp", None)
                key = (who_pk, _ts_key(ts))
                if key not in groups_map:
                    groups_map[key] = {"raw": [], "changed_by_obj": getattr(log, "changed_by", None), "ts": ts}
                    ordered_keys.append(key)
                groups_map[key]["raw"].append(log)
    
            for key in ordered_keys:
                entry = groups_map[key]
                raw_list = entry["raw"]
                rep = raw_list[0]
                action = (getattr(rep, "action", "") or "").lower()
                cb_obj = entry["changed_by_obj"]
                cb_display = _changed_by_display(cb_obj)
                ts_display = ""
                if entry["ts"]:
                    try:
                        ts_display = timezone.localtime(entry["ts"]).strftime("%Y-%m-%d %H:%M:%S")
                    except Exception:
                        ts_display = str(entry["ts"])
    
                changes_flat = []
                for row in raw_list:
                    raw_changes = getattr(row, "changes", None)
                    if not raw_changes:
                        continue
                    if isinstance(raw_changes, dict):
                        payload = raw_changes
                    else:
                        try:
                            payload = json.loads(raw_changes)
                        except Exception:
                            payload = {"raw": str(raw_changes)}
    
                    for field_name, val in payload.items():
                        old_val = ""
                        new_val = ""
                        if isinstance(val, dict):
                            old_val = val.get("old", "")
                            new_val = val.get("new", "")
                        else:
                            new_val = val
    
                        # If values are equivalent after normalization, skip field
                        try:
                            if _values_equivalent(old_val, new_val):
                                continue
                        except Exception:
                            # fall back to showing the field if compare fails
                            pass
    
                        # photo: show filename only
                        if field_name == "photo":
                            old_disp = os.path.basename(old_val) if old_val else ""
                            new_disp = os.path.basename(new_val) if new_val else ""
                            changes_flat.append({
                                "field_changed": "Photo",
                                "old_value": old_disp or "",
                                "new_value": new_disp or ""
                            })
                            continue
    
                        # is_active boolean-display
                        if field_name == "is_active":
                            old_display = "Active" if old_val else ("Inactive" if old_val in (0, False, "false", "False") else str(old_val) or "")
                            new_display = "Active" if new_val else ("Inactive" if new_val in (0, False, "false", "False") else str(new_val) or "")
                            changes_flat.append({"field_changed": "Active", "old_value": old_display, "new_value": new_display})
                            continue
    
                        # FK-like resolution
                        if field_name.endswith("_id") or field_name in ("branch", "lco", "department", "position", "job_position", "manager", "allowed_branches"):
                            old_disp = _resolve_fk_name(field_name, old_val)
                            new_disp = _resolve_fk_name(field_name, new_val)
                            pretty_field = _prettify_field_name(field_name)
                            changes_flat.append({"field_changed": pretty_field, "old_value": old_disp, "new_value": new_disp})
                            continue
    
                        # generic fallback
                        old_str = "" if old_val is None else str(old_val)
                        new_str = "" if new_val is None else str(new_val)
                        pretty_field = _prettify_field_name(field_name)
                        changes_flat.append({"field_changed": pretty_field, "old_value": old_str, "new_value": new_str})
    
                # Append groups (skip empty update groups)
                if ("create" in action) or (getattr(rep, "action", "") == getattr(EmployeeChangeLog, "ACTION_CREATE", "create")):
                    create_groups.append({
                        "changed_by": cb_display,
                        "changed_by_obj": cb_obj,
                        "change_timestamp": ts_display,
                        "raw": raw_list,
                    })
                else:
                    if changes_flat:
                        update_groups.append({
                            "changed_by": cb_display,
                            "changed_by_obj": cb_obj,
                            "change_timestamp": ts_display,
                            "changes": changes_flat,
                            "raw": raw_list,
                        })
                    else:
                        # nothing meaningful to show for this group -> skip
                        # optional: log debug info
                        # print(f"DEBUG: skipping empty change group for employee pk={getattr(emp,'pk',None)} rep_pk={getattr(rep,'pk',None)}")
                        pass
    
        except Exception as exc:
            # print("ERROR: build_change_groups failed:", exc)
            create_groups = []
            update_groups = []
    
        return create_groups, update_groups


    # ----------------- prepare template defaults -----------------
    try:
        allowed_branches_vals = [str(b.pk) for b in (employee.allowed_branches.all() if hasattr(employee, 'allowed_branches') else [])]
    except Exception:
        allowed_branches_vals = []

    employee_data_defaults = {
        "name": employee.employee_name or '',
        "email": employee.email or '',
        "country": employee.nationality or '',
        "state": employee.state or '',
        "district": employee.district or '',
        "dateOfBirth": employee.date_of_birth.strftime('%Y-%m-%d') if getattr(employee, 'date_of_birth', None) else '',
        "maritalStatus": employee.marital_status.id if employee.marital_status else None,
        "gender": employee.gender or '',
        # "lco_id": str(employee.lco.pk) if getattr(employee, 'lco', None) else '',
        "branch_id": str(employee.branch.pk) if getattr(employee, 'branch', None) else '',
        "position_id": str(employee.job_position.pk) if getattr(employee, 'job_position', None) else '',
        "department_id": str(employee.department.pk) if getattr(employee, 'department', None) else '',
        "manager_id": str(employee.manager.pk) if getattr(employee, 'manager', None) else '',
        "workEmail": employee.work_email or '',
        "workMobile": employee.work_mobile or '',
        "mobile": employee.personal_mobile or '',
        "workPhone": employee.work_phone or '',
        "employeeId": employee.employee_id or '',
        "workLocation": employee.work_location or '',
        "visaNumber": employee.visa_number or '',
        "visaExpDate": employee.visa_expiry_date.strftime('%Y-%m-%d') if getattr(employee, 'visa_expiry_date', None) else '',
        "pinCode": employee.pincode or '',
        "city": employee.city or '',
        "address": employee.address_line1 or '',
        "emgContactName": employee.emergency_contact_name or '',
        "emgPhone": employee.emergency_contact or '',
        "aadhaarNumber": employee.aadhaar_number or '',
        "passportNumber": employee.passport_number or '',
        "numberOfChildren": str(employee.number_of_children) if getattr(employee, 'number_of_children', None) is not None else '',
        "workPermitNumber": employee.work_permit or '',
        "photo_url": employee.photo.url if getattr(employee, 'photo', None) else None,
        "allowed_branches": allowed_branches_vals,
         # New fields
        "basicSalary": employee.basic_salary or '',
        "da": employee.da or '',
        "hra": employee.hra or '',
        "type": getattr(employee, 'type', '') or '',
        "username" : User.objects.get(employee_id=employee.id).username,
        'marital_statuses': MaritalStatus.objects.all(),
            "emp_type": request.user.user_type,
    "type_id": type_id,
    "is_active": employee.is_active or False,
    "department": employee.department.id if employee.department else None,

    }
    # print(employee_data_defaults['district'],'@@@@@@@@@@@@')

    # ----------------- GET render -----------------
    if request.method == "GET":
        show_success_modal = request.GET.get('updated') == '1' or request.GET.get('emp_updated') == '1'
        updated_employee_name = request.GET.get('employee_name', '') if show_success_modal else ''
        updated_employee_pk = employee.pk if show_success_modal else None
        create_groups, update_groups = build_change_groups(employee)

        context = {
            "branches": branches,
            "departments": departments,
            "job_positions": job_positions,
            "managers": managers,
            # 'lco_choices': lco_choices,
            'branches': branches,
            # 'disable_lco_select': disable_lco_select,
            # 'selected_lco_id': selected_lco_id,            
            "errors": defaultdict(str),
            "employee_data": employee_data_defaults,
            "posted": employee_data_defaults,
            "show_success_modal": show_success_modal,
            "updated_employee_name": updated_employee_name,
            "updated_employee_pk": updated_employee_pk,
            "created_employee_name": "",
            "non_field_errors": '',
            "create_groups": create_groups,
            "update_groups": update_groups,
            'marital_statuses': MaritalStatus.objects.all()
            
        }
        # print("Context (GET) prepared.")
        return render(request, 'employe/employee_edit.html', context)

    # ----------------- POST processing -----------------
    if request.method == "POST":
        errors = {}

        # posted keys — include allowed_branches retrieval separately (getlist)
        posted = {k: (request.POST.get(k, '') or '').strip() for k in employee_data_defaults.keys()}
        posted_allowed_branches = request.POST.getlist('allowed_branches')
        
        posted['allowed_branches'] = posted_allowed_branches  # keep for template
        posted['type'] = (request.POST.get('type') or posted.get('type', '') or '').strip()

        


        # ---- HANDLE position coming from template as `position` (not only position_id) ----
# Accept either name="position" or name="position_id". Also ignore sentinel used for "create".
        _pos_val = (request.POST.get('position') or request.POST.get('position_id') or '').strip()
        if _pos_val and _pos_val != '__create_position__':
            posted['position'] = _pos_val
            posted['position_id'] = _pos_val
        else:
            # ensure keys exist so later code sees empty string rather than KeyError/None
            posted['position'] = posted.get('position', '')
            posted['position_id'] = posted.get('position_id', '')
        # print("DEBUG: posted (safe):", posted)

        remove_image = request.POST.get('remove_image', '0') == '1'
        if remove_image:
            if employee.photo:
                # print(f"DEBUG: Removing photo for employee {employee.pk}")
                try:
                    employee.photo.delete(save=False)
                except Exception as e:
                    pass
                    # print("Warning deleting existing photo:", e)
                employee.photo = None

        # Parse dates
        date_of_birth_raw = posted.get("dateOfBirth", "")
        date_of_birth = None
        if date_of_birth_raw:
            try:
                date_of_birth = datetime.strptime(date_of_birth_raw, '%Y-%m-%d').date()
            except ValueError as e:
                # print(f"ERROR: invalid dateOfBirth: {e}")
                errors["dateOfBirth"] = "Invalid date format. Use YYYY-MM-DD."

        visa_expiry_raw = posted.get("visaExpDate", "")
        visa_expiry_date = None
        if visa_expiry_raw:
            try:
                visa_expiry_date = datetime.strptime(visa_expiry_raw, '%Y-%m-%d').date()
            except ValueError as e:
                # print(f"ERROR: invalid visaExpDate: {e}")
                errors["visaExpDate"] = "Invalid date format. Use YYYY-MM-DD."

        # Build employee_data dict (typed where convenient)
        # lco_id = request.POST.get('lco')  # ✅ Safe access
        marital_status_id = posted.get("maritalStatus")

        if marital_status_id and marital_status_id.isdigit():
            data = MaritalStatus.objects.get(id=int(marital_status_id))
        else:
            data = None  # or handle the case where no valid ID is provided

        employee_data = {
            "employee_name": posted.get("name", ""),
            "email": posted.get("email", ""),
            "country": posted.get("country", ""),
            "state": posted.get("state", ""),
            "district": posted.get("district", ""),
            "date_of_birth": date_of_birth,
            "marital_status": data,
            "gender": posted.get("gender", ""),
            "branch_id": posted.get("branch_id", "") or posted.get("branch", ""),
            "position_id": posted.get("position_id", "") or posted.get("position", ""),
            "department_id": posted.get("department_id", "") or posted.get("department", ""),
            "manager_id": posted.get("manager_id", "") or posted.get("manager", ""),
            "work_email": posted.get("workEmail", ""),
            "work_mobile": posted.get("workMobile", ""),
            "personal_mobile": posted.get("mobile", ""),
            "work_phone": posted.get("workPhone", ""),
            "employee_id": posted.get("employeeId", ""),
            "work_location": posted.get("workLocation", ""),
            "visa_number": posted.get("visaNumber", ""),
            "visa_expiry_date": visa_expiry_date,
            "pincode": posted.get("pinCode", ""),
            "city": posted.get("city", ""),
            "address_line1": posted.get("address", ""),
            "emergency_contact_name": posted.get("emgContactName", ""),
            "emergency_contact": posted.get("emgPhone", ""),
            "aadhaar_number": posted.get("aadhaarNumber", ""),
            "passport_number": posted.get("passportNumber", ""),
            "number_of_children": posted.get("numberOfChildren", ""),
            "work_permit": posted.get("workPermitNumber", ""),
            "allowed_branches": posted_allowed_branches,
            # New fields
            "basic_salary": posted.get("basicSalary", ""),
            "da": posted.get("da", ""),
            "hra": posted.get("hra", ""),
            "type": posted.get("type", ""),
            "username": posted.get("username", ""),
            "password": posted.get("password", ""),
                "emp_type": request.user.user_type,
    "type_id": type_id,
    
        }


        is_active = request.POST.get('is_active') == '1'  # Check if checkbox is checked
        employee_data['is_active'] = is_active  # Store in employee_data


        # print(employee_data)
        def parse_decimal_posted(key, label):
            s = (posted.get(key, '') or '').strip()
            if s == '':
                # treat blank as zero — change to `return None` if you prefer to preserve old value instead
                return Decimal('0.00')
            # allow thousands separators like "30,000.00"
            s_clean = s.replace(',', '')
            try:
                return Decimal(s_clean)
            except (InvalidOperation, ValueError):
                errors[key] = f"Invalid number for {label}."
                return None
            
        # parse posted keys (note: form uses names basicSalary, da, hra)
        basic_dec = parse_decimal_posted('basicSalary', 'Basic Salary')
        da_dec    = parse_decimal_posted('da', 'DA')
        hra_dec   = parse_decimal_posted('hra', 'HRA')



        # Password handling
        new_password = (request.POST.get('password') or '').strip()
        confirm_password = (request.POST.get('confirmPassword') or '').strip()
        if new_password:
            if len(new_password) < 6:
                errors['password'] = "Password must be at least 6 characters."
            elif new_password != confirm_password:
                errors['confirmPassword'] = "Passwords do not match."

        # number_of_children conversion
        noc_raw = employee_data.get('number_of_children', '')
        number_of_children_val = None
        if noc_raw != '':
            try:
                number_of_children_val = int(noc_raw)
                if number_of_children_val < 0:
                    errors['numberOfChildren'] = "Number of children cannot be negative."
            except Exception:
                errors['numberOfChildren'] = "Number of children must be an integer."
        employee_data['number_of_children'] = number_of_children_val

        # Image file
        image = request.FILES.get('photo') or request.FILES.get('image') or request.FILES.get('employee-image-upload')
        if image:
            # print("DEBUG: uploaded file:", getattr(image, 'name', ''), getattr(image, 'size', 'n/a'))
            pass

        # Validate allowed_branches list: ensure each id exists and collect ints
        allowed_branch_ids = []
        invalid_allowed = []
        posted_allowed = employee_data.get('allowed_branches') or []
        if posted_allowed:
            for v in posted_allowed:
                try:
                    bid = int(v)
                except (ValueError, TypeError):
                    invalid_allowed.append(v)
                    continue
                try:
                    if Branch is not None and Branch.objects.filter(pk=bid).exists():
                        allowed_branch_ids.append(bid)
                    else:
                        invalid_allowed.append(v)
                except Exception:
                    invalid_allowed.append(v)
        if invalid_allowed:
            errors['allowed_branches'] = "One or more selected branches are invalid."

        # If there are no basic errors so far, attempt save + changelog
        if not errors:
            try:
                with transaction.atomic():
                    image_removed = posted.get('remove_image', '0') == '1'
                    # print("DEBUG: typeid", type_id)
                    # snapshot old values
                    old_values = {
                        "employee_name": employee.employee_name,
                        "email": employee.email,
                        "nationality": employee.nationality,
                        "state": employee.state,
                        "district": employee.district,
                        "date_of_birth": employee.date_of_birth,
                        "marital_status": data,
                        "gender": employee.gender,
                        # "lco_id": getattr(employee.lco, 'pk', None),
                        "branch_id": getattr(employee.branch, 'pk', None),
                        "position_id": getattr(employee.job_position, 'pk', None),
                        "department_id": getattr(employee.department, 'pk', None),
                        "manager_id": getattr(employee.manager, 'pk', None),
                        "work_email": employee.work_email,
                        "work_mobile": employee.work_mobile,
                        "personal_mobile": employee.personal_mobile,
                        "work_phone": employee.work_phone,
                        "employee_id": employee.employee_id,
                        "work_location": employee.work_location,
                        "visa_number": employee.visa_number,
                        "visa_expiry_date": getattr(employee, 'visa_expiry_date', None),
                        "pincode": employee.pincode,
                        "city": employee.city,
                        "address_line1": employee.address_line1,
                        "emergency_contact_name": employee.emergency_contact_name,
                        "emergency_contact": employee.emergency_contact,
                        "aadhaar_number": employee.aadhaar_number,
                        "passport_number": employee.passport_number,
                        "number_of_children": employee.number_of_children,
                        "work_permit": getattr(employee, 'work_permit', None),
                        "photo": employee.photo.url if getattr(employee, 'photo', None) else None,
                        "allowed_branches": [b.pk for b in (employee.allowed_branches.all() if hasattr(employee, 'allowed_branches') else [])],

                        "basic_salary": employee.basic_salary,  # Add old value for basic_salary
                        "da": employee.da,  # Add old value for DA
                        "hra": employee.hra,  # Add old value for HRA
                        "type": getattr(employee, 'type', None),
                        "emp_type": request.user.user_type,
                        "type_id":type_id,
                        "is_active": employee.is_active  # Add is_active to old_values
                        
                    }

                    # Apply simple scalar assignments
                    simple_field_map = {
                        "employee_name": "employee_name",
                        "email": "email",
                        "country": "nationality",
                        "state": "state",
                        "district": "district",
                        "date_of_birth": "date_of_birth",
                        "marital_status": "marital_status",
                        "gender": "gender",
                        "work_email": "work_email",
                        "work_mobile": "work_mobile",
                        "personal_mobile": "personal_mobile",
                        "work_phone": "work_phone",
                        "employee_id": "employee_id",
                        "work_location": "work_location",
                        "visa_number": "visa_number",
                        "visa_expiry_date": "visa_expiry_date",
                        "pincode": "pincode",
                        "city": "city",
                        "address_line1": "address_line1",
                        "emergency_contact_name": "emergency_contact_name",
                        "emergency_contact": "emergency_contact",
                        "aadhaar_number": "aadhaar_number",
                        "passport_number": "passport_number",
                        "number_of_children": "number_of_children",
                        "work_permit": "work_permit",
                        "type": "type",
                        "emp_type": "emp_type",
                        "type_id": "type_id"
                    }

                    for src_key, model_attr in simple_field_map.items():
                        if not hasattr(employee, model_attr):
                            continue
                        val = employee_data.get(src_key)
                        if not _model_field_allows_assignment(employee, model_attr, val):
                            # print(f"DEBUG: preserve existing required field {model_attr}")
                            continue
                        # print(f"DEBUG: setting {model_attr} -> {val!r}")
                        setattr(employee, model_attr, val)


                    if isinstance(basic_dec, Decimal):
                        employee.basic_salary = basic_dec.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
                    else:
                        # policy: set to 0.00 if parse failed/blank — change to `pass` to preserve old DB value
                        employee.basic_salary = Decimal('0.00')
                    
                    if isinstance(da_dec, Decimal):
                        employee.da = da_dec.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
                    else:
                        employee.da = Decimal('0.00')
                    
                    if isinstance(hra_dec, Decimal):
                        employee.hra = hra_dec.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
                    else:
                        employee.hra = Decimal('0.00')
                    # data = MaritalStatus.objects.get(id=employee_data.get('maritalStatus'))
                    # print('=============>',data)
                    # employee.marital_status = data
                    # FK fields (set objects)
                    _set_fk_if_provided(employee, 'branch', Branch, employee_data.get('branch_id', ''))
                    if JobPosition:
                        _set_fk_if_provided(employee, 'job_position', JobPosition, employee_data.get('position_id', ''))
                    if Department:
                        _set_fk_if_provided(employee, 'department', Department, employee_data.get('department_id', ''))
                    _set_fk_if_provided(employee, 'manager', Employee, employee_data.get('manager_id', ''))
                    if LCO:
                        _set_fk_if_provided(employee, 'lco', LCO, employee_data.get('lco_id', ''))

                    # assign image if provided or remove
                    if image:
                        # print(f"DEBUG: uploaded file: {image.name}, size: {image.size}")
                        employee.photo = image
                    elif image_removed:
                        try:
                            if getattr(employee, 'photo', None):
                                employee.photo.delete(save=False)
                        except Exception as e:
                            pass
                            # print("Warning deleting existing photo:", e)
                        employee.photo = None
                        # print("DEBUG: Image removed, setting photo to None.")

                    # Validate model-level constraints
                    try:
                        employee.full_clean()
                    except ValidationError as ve:
                        # print("ValidationError from full_clean():", getattr(ve, 'message_dict', ve))
                        if hasattr(ve, 'message_dict'):
                            for k, msgs in ve.message_dict.items():
                                errors[k] = msgs[0] if isinstance(msgs, (list, tuple)) else str(msgs)
                        else:
                            errors["__all__"] = str(ve)
                        raise

                    # Handle password: update existing auth user or create+link
                    # if new_password:
                    #     UserModel = get_user_model()
                    #     username_field = getattr(UserModel, 'USERNAME_FIELD', 'username')

                    #     # Construct a username — using email or employee ID
                    #     base_username = (employee_data['username'] or f"emp{int(time.time())}").strip()
                    #     create_kwargs = {username_field: base_username}

                    #     # Optional: set email if UserModel has it
                    #     try:
                    #         UserModel._meta.get_field('username')
                    #         create_kwargs['username'] = employee_data['username'] or ''
                    #     except Exception:
                    #         pass

                    #     try:
                    #         created_user = None
                    #         try:
                    #             created_user = UserModel.objects.create_user(password=new_password, **create_kwargs)
                    #         except IntegrityError:
                    #             # fallback if username is not unique
                    #             fallback_username = f"{base_username}-{int(time.time())}"
                    #             create_kwargs[username_field] = fallback_username
                    #             created_user = UserModel.objects.create_user(password=new_password, **create_kwargs)

                    #         # Optionally set first/last name if available
                    #         if hasattr(created_user, 'first_name') and hasattr(created_user, 'last_name'):
                    #             parts = (employee.employee_name or '').split(None, 1)
                    #             created_user.first_name = parts[0] if parts else ''
                    #             created_user.last_name = parts[1] if len(parts) > 1 else ''
                    #             created_user.save()

                    #         print(f"DEBUG: Created new auth user (pk={created_user.pk}) for employee")

                    #         # 🔁 NO employee.user = created_user since field is removed

                    #         # OPTIONAL: log somewhere the user ↔ employee connection
                    #         # e.g., store employee_id in User.custom_field or use a linking model

                    #     except Exception as e:
                    #         print(f"ERROR creating user for employee: {e}")
                    #         errors['password'] = "Failed to create user for the employee."
                    #         raise

                    # Save employee core
                    employee.is_active = employee_data.get('is_active', False)  # Default to False if not provided
                    employee.save()
                    # print(f"employee_edit: saved employee pk={employee.pk}")

                    # ----------------- M2M: allowed_branches -----------------
                    try:
                        if hasattr(employee, 'allowed_branches'):
                            employee.allowed_branches.set(allowed_branch_ids)
                            # print("DEBUG: allowed_branches set ->", allowed_branch_ids)

                    except Exception as e:
                        # print("ERROR setting allowed_branches:", e)
                        errors['allowed_branches'] = "Failed to update allowed branches"

                    # ----------------- SYNC AUTH USER EMAIL / USERNAME if needed -----------------
                    try:
                        UserModel = get_user_model()
                        employee_identifier = employee.id  # unique employee ID

                        try:
                            linked_user = UserModel.objects.get(employee_id=employee_identifier)
                            # print(f"DEBUG: Found linked user {linked_user} for employee_id={employee_identifier}")
                        except UserModel.DoesNotExist:
                            linked_user = None
                            # print(f"DEBUG: No linked user found for employee_id={employee_identifier}")

                        if linked_user:
                            new_username_val = employee_data.get('username', '').strip()
                            new_password = (request.POST.get('password') or '').strip()

                            username_field = getattr(UserModel, 'USERNAME_FIELD', 'username')
                            # print('username_field', username_field)
                            # print('username', new_username_val)
                            # print('password', new_password)

                            # Update username if changed
                            if new_username_val and new_username_val.lower() != (getattr(linked_user, username_field, '') or '').lower():
                                if UserModel.objects.filter(**{f"{username_field}__iexact": new_username_val}).exclude(pk=linked_user.pk).exists():
                                    errors['username'] = "This username is already used by another account."
                                    raise ValidationError("Username conflict")

                                # print(f"DEBUG before username save: {username_field} = {getattr(linked_user, username_field)}")
                                setattr(linked_user, username_field, new_username_val)
                                linked_user.save(update_fields=[username_field])
                                # print(f"DEBUG after username save: {username_field} = {getattr(linked_user, username_field)}")

                            # ✅ Update password if provided
                            if new_password:
                                linked_user.set_password(new_password)
                                linked_user.save(update_fields=["password"])
                                # print(f"DEBUG: Password updated for linked user (employee_id={employee_identifier})")




                    except ValidationError:
                        raise
                    except Exception as e:
                        # print("ERROR syncing auth user email:", e)
                        errors['email'] = "Failed to sync email with auth user."
                        raise

                    # Build snapshot of new values
                    new_values = {
                        "employee_name": employee.employee_name,
                        "email": employee.email,
                        "nationality": employee.nationality,
                        "state": employee.state,
                        "district": employee.district,
                        "date_of_birth": employee.date_of_birth,
                        "marital_status": employee.marital_status if employee.marital_status else None,
                        "gender": employee.gender,
                        # "lco_id": getattr(employee.lco, 'pk', None),
                        "branch_id": getattr(employee.branch, 'pk', None),
                        "position_id": getattr(employee.job_position, 'pk', None),
                        "department_id": getattr(employee.department, 'pk', None),
                        "manager_id": getattr(employee.manager, 'pk', None),
                        "work_email": employee.work_email,
                        "work_mobile": employee.work_mobile,
                        "personal_mobile": employee.personal_mobile,
                        "work_phone": employee.work_phone,
                        "employee_id": employee.employee_id,
                        "work_location": employee.work_location,
                        "visa_number": employee.visa_number,
                        "visa_expiry_date": getattr(employee, 'visa_expiry_date', None),
                        "pincode": employee.pincode,
                        "city": employee.city,
                        "address_line1": employee.address_line1,
                        "emergency_contact_name": employee.emergency_contact_name,
                        "emergency_contact": employee.emergency_contact,
                        "aadhaar_number": employee.aadhaar_number,
                        "passport_number": employee.passport_number,
                        "number_of_children": employee.number_of_children,
                        "work_permit": getattr(employee, 'work_permit', None),
                        "photo": employee.photo.url if getattr(employee, 'photo', None) else None,
                        "allowed_branches": [b.pk for b in (employee.allowed_branches.all() if hasattr(employee, 'allowed_branches') else [])],
                        "basic_salary": employee.basic_salary,  # Include the basic salary field
                         "da": employee.da,  # Include the DA (Dearness Allowance) field
                         "hra": employee.hra,  # Include the HRA (House Rent Allowance) field
                         "type": getattr(employee, 'type', None),
                         "emp_type":request.user.user_type,
                         "type_id":type_id,
                          "is_active": employee.is_active  # Add is_active to new_values
                    }

                    # produce diffs only for fields that genuinely changed
                    diffs = {}

                    def norm_val(x):
                        if x in (None, ''):
                            return None
                        if isinstance(x, (list, tuple)):
                            norm_list = []
                            for it in x:
                                if it in (None, ''):
                                    continue
                                if isinstance(it, (int, float)):
                                    norm_list.append(int(it))
                                else:
                                    s = str(it).strip()
                                    if s.isdigit():
                                        try:
                                            norm_list.append(int(s))
                                        except Exception:
                                            norm_list.append(s)
                                    else:
                                        norm_list.append(s)
                            try:
                                norm_list_sorted = sorted(norm_list)
                            except Exception:
                                norm_list_sorted = norm_list
                            return norm_list_sorted
                        if isinstance(x, (datetime, date)):
                            try:
                                return x.isoformat()
                            except Exception:
                                return str(x)
                        if isinstance(x, Decimal):
                            return str(x)
                        return str(x).strip() if x is not None else None

                    for k, old_v in old_values.items():
                        new_v = new_values.get(k)
                        if norm_val(old_v) != norm_val(new_v):
                            diffs[k] = {"old": old_v, "new": new_v}

                    # If diffs found, create EmployeeChangeLog
                    if diffs and EmployeeChangeLog is not None:
                        try:
                            def _serializable(x):
                                if isinstance(x, (datetime, date)):
                                    return x.isoformat()
                                if isinstance(x, Decimal):
                                    return str(x)
                                if isinstance(x, (list, tuple)):
                                    return list(x)
                                return x
                            
                            
                            safe_diffs = json.loads(json.dumps(diffs, default=_serializable))
                            changed_by = request.user if getattr(request, "user", None) and request.user.is_authenticated else None
                            EmployeeChangeLog.objects.create(
                                employee=employee,
                                changed_by=changed_by,
                                action=EmployeeChangeLog.ACTION_UPDATE,
                                changes=safe_diffs,
                                summary="Updated: " + ", ".join(sorted(diffs.keys())),
                                meta={
                                    "ip": request.META.get("REMOTE_ADDR"),
                                    "user_agent": request.META.get("HTTP_USER_AGENT", "")[:255]
                                }
                            )
                            # print(f"DEBUG: EmployeeChangeLog created for employee pk={employee.pk}, fields: {list(diffs.keys())}")
                        except Exception as e:
                            pass
                            # print(f"ERROR creating EmployeeChangeLog: {e}")

                    # redirect to same edit page with success token
                    params = {'updated': '1', 'employee_name': employee.employee_name or '', 'emp_updated': '1'}
                    from urllib.parse import urlencode
                    redirect_url = reverse('employee:employee_edit', kwargs={'employee_id': employee.pk}) + '?' + urlencode(params)
                    return redirect(redirect_url)
                    # if diffs:
                    #     messages.success(request, f"Employee  upadated successfully")
                    # return redirect(reverse('employee:employee_edit', kwargs={'employee_id': employee.pk}))

            except ValidationError as ve:
                # print("employee_edit: ValidationError raised -", getattr(ve, 'message_dict', ve))
                # let outer re-render handle it
                pass
            except Exception as exc:
                # print(f"employee_edit: error during save - {exc}")
                traceback.print_exc()
                errors["__all__"] = "An error occurred while updating the employee."

        # Prepare re-render if we hit errors
        create_groups, update_groups = build_change_groups(employee)
        context = {
            "errors": defaultdict(str, errors),
            "posted": {k: (posted.get(k, '') or '') for k in employee_data_defaults.keys()},
            "employee_data": employee_data_defaults,
            "branches": branches,
            "departments": departments,
            "job_positions": job_positions,
            "managers": managers,
            # "lcos": lco_choices,
            "non_field_errors": errors.get("__all__", ''),
            "show_success_modal": False,
            "created_employee_name": "",
            "create_groups": create_groups,
            "update_groups": update_groups,
            'marital_statuses': MaritalStatus.objects.all()
        }
        context['posted']['allowed_branches'] = posted.get('allowed_branches', [])
        # print("Re-rendering form with errors:", dict(context["errors"]))
        return render(request, 'employe/employee_edit.html', context)

    # fallback
    return redirect(reverse('employee:employee_create'))









@login_required
def employee_delete(request, emp_id):
    """
    Deletes an Employee and redirects back to the list with a flash message.
    """
    emp = get_object_or_404(Employee, id=emp_id)
    name = emp.employee_name
    emp.delete()
    messages.success(request, f"Employee “{name}” has been deleted.")
    return redirect('employee:employee_list')













PHONE_VALIDATOR = RegexValidator(
    regex=r'^\+?\d{7,15}$',
    message='Enter a valid phone number. Up to 15 digits allowed, optional leading +.'
)
@require_http_methods(["GET", "POST"])
@login_required
def branch_create(request):
    template = "employe/branch_create.html"

    # preserve list/search state (GET or POST)
    q = request.GET.get("q", "") if request.method == "GET" else (request.POST.get("q", "") or request.GET.get("q", ""))
    items_per_page = request.GET.get("items_per_page", "") if request.method == "GET" else (request.POST.get("items_per_page", "") or request.GET.get("items_per_page", ""))
    page = request.GET.get("page", "") if request.method == "GET" else (request.POST.get("page", "") or request.GET.get("page", ""))

    # defaults for template (used when re-rendering)
    defaults = {
        "name": "",
        "branch_code": "",
        "lco_id": "",
        "branch_email": "",
        "branch_mobile": "",
        "branch_phone": "",
        "branch_street": "",
        "branch_street2": "",
        "branch_city": "",
        "branch_state": "",
        "branch_country": "",
        "branch_pincode": "",
        "photo_url": "",
        "warehouse":""
    }

    if request.method == "GET":
        user = request.user
        lco_choices = LCO.objects.none()  # Default empty queryset
        disable_lco_select = False
        selected_lco_id = None

        if user.is_authenticated:
            if user.user_type == "distributer" and user.distributer:
                # Show LCOs under the distributer's subdistributers
                # Assuming SubDistributer has FK to Distributer and LCO has FK to SubDistributer
                lco_choices = LCO.objects.filter(sub_distributer__distributer=user.distributer, is_active=True).order_by("name")
            elif user.user_type == "subdistributer" and user.subdistributer:
                # Show LCOs under the logged-in subdistributer
                lco_choices = LCO.objects.filter(sub_distributer=user.subdistributer, is_active=True).order_by("name")
            elif user.user_type == "lco" and user.lco:
                # Only show this LCO, and disable select
                lco_choices = LCO.objects.filter(pk=user.lco.pk)
                selected_lco_id = user.lco.pk
                disable_lco_select = True
            else:
                # Show all LCOs
                lco_choices = LCO.objects.order_by("name").all()

        context = {
            **defaults,
            "lcos": lco_choices,
            "disable_lco_select": disable_lco_select,
            "selected_lco_id": selected_lco_id,
            "errors": {},
            "q": q,
            "items_per_page": items_per_page,
            "page": page,
            "created_branch_name": request.GET.get("created", ""),
        }
        return render(request, template, context)


    # POST
    errors = {}
    posted = {k: (request.POST.get(k, "") or "").strip() for k in defaults.keys()}

    # Map district select (if you used branch_district_id) into branch_city
    # allow both names used in different templates
    if request.POST.get("branch_district_id"):
        posted["branch_city"] = request.POST.get("branch_district_id").strip()

    # Validate required fields
    required_fields = {
        "name": "Branch Name is required.",
        "branch_code": "Branch Code is required.",
        "branch_email": "Email is required.",
        "branch_mobile": "Mobile is required.",
        "branch_country": "Country is required.",
        "branch_state": "State is required.",
        "branch_city": "District / City is required.",
        "branch_street": "Address is required.",
    }

    for fld, msg in required_fields.items():
        if not posted.get(fld):
            errors[fld] = msg

    # Email validation
    if posted.get("branch_email"):
        try:
            EmailValidator()(posted["branch_email"])
        except ValidationError:
            errors["branch_email"] = "Enter a valid email address."

    # Phone validation - try project validator then fallback simple check
    if posted.get("branch_mobile"):
        if PHONE_VALIDATOR:
            try:
                PHONE_VALIDATOR(posted["branch_mobile"])
            except ValidationError:
                errors["branch_mobile"] = "Enter a valid mobile number."
        else:
            # basic check: digits and + and spaces allowed
            import re
            if not re.match(r'^[\d\+\-\s\(\)]{6,20}$', posted["branch_mobile"]):
                errors["branch_mobile"] = "Enter a valid mobile number."

    # branch_code / name uniqueness check (quick)
    if posted.get("name"):
        if Branch.objects.filter(name__iexact=posted["name"]).exists():
            errors["name"] = "A branch with this name already exists."
    if posted.get("branch_code"):
        if Branch.objects.filter(branch_code__iexact=posted["branch_code"]).exists():
            errors["branch_code"] = "A branch with this code already exists."
    if not(posted.get("warehouse")):
        errors["warehouse"] = "Please select a warehouse."
    else :
    #     # if Branch.objects.filter(warehouse__iexact=posted["warehouse"]).exists():
    #     #     errors["warehouse"] = "A branch with this warehouse already exists."
        warehouse = Warehouse.objects.get(id=posted["warehouse"])
    # image upload
    image = request.FILES.get("photo") or None
    remove_image_flag = (request.POST.get("remove_image") == "1")

    # If errors -> re-render
    if errors:
        context = {
            **posted,
            "lcos": LCO.objects.order_by("name").all() if hasattr(LCO, "objects") else [],
            "errors": errors,
            "q": q,
            "items_per_page": items_per_page,
            "page": page,
            "photo_url": "",
        }
        return render(request, template, context)

    # Save branch inside transaction

    try:
        with transaction.atomic():
            b = Branch(
                name=posted.get("name") or None,
                branch_code=posted.get("branch_code") or None,
                branch_email=posted.get("branch_email") or None,
                branch_mobile=posted.get("branch_mobile") or None,
                branch_phone=posted.get("branch_phone") or None,
                branch_street=posted.get("branch_street") or None,
                branch_street2=posted.get("branch_street2") or None,
                branch_city=posted.get("branch_city") or None,
                branch_state=posted.get("branch_state") or None,
                branch_country=posted.get("branch_country") or None,
                branch_pincode=posted.get("branch_pincode") or None,
                type=request.user.user_type,
                type_id=request.user.user_id,
                warehouse=warehouse
            )

            # attach LCO if provided and exists
            lco_id = request.POST.get("lco_id") or ""
            if lco_id:
                try:
                    b.lco = LCO.objects.get(pk=int(lco_id))
                except Exception:
                    b.lco = None

            # attach photo if uploaded
            if image:
                b.photo = image
            # if remove_image_flag on create it's irrelevant, but handle defensively:
            if remove_image_flag:
                b.photo = None

            b.full_clean()  # raise ValidationError on max_length etc.
            b.save()

            # create changelog: snapshot for create
            try:
                # Prepare new_values snapshot
                new_values = {
                    "name": b.name,
                    "branch_code": b.branch_code,
                    "lco_id": getattr(b.lco, "pk", None),
                    "lco_name": getattr(b.lco, "name", "") if getattr(b, "lco", None) else "",
                    "branch_email": b.branch_email,
                    "branch_mobile": b.branch_mobile,
                    "branch_phone": b.branch_phone,
                    "branch_street": b.branch_street,
                    "branch_street2": b.branch_street2,
                    "branch_city": b.branch_city,
                    "branch_state": b.branch_state,
                    "branch_country": b.branch_country,
                    "branch_pincode": b.branch_pincode,
                    "photo": (b.photo.name if getattr(b, "photo", None) else ""),
                }
                # JSON-safe
                def _serializable(x):
                    if isinstance(x, (datetime, date)):
                        return x.isoformat()
                    if isinstance(x, Decimal):
                        return str(x)
                    return x

                safe_snapshot = json.loads(json.dumps(new_values, default=_serializable))
                changed_by = request.user if getattr(request, "user", None) and request.user.is_authenticated else None
                BranchChangeLog.objects.create(
                    branch=b,
                    changed_by=changed_by,
                    action=BranchChangeLog.ACTION_CREATE,
                    changes=safe_snapshot,
                    summary=f"Created branch {b.name}",
                    meta={"ip": request.META.get("REMOTE_ADDR"), "user_agent": request.META.get("HTTP_USER_AGENT", "")[:255]},
                )
            except Exception as e:
                # don't block create if changelog fails
                print("Failed to create BranchChangeLog:", e)
                traceback.print_exc()

            # Success: redirect back to create with created message (or adapt to edit/list)
            messages.success(request, f"Branch '{b.name}' created successfully.")
            params = {"created": b.name}
            if q:
                params["q"] = q
            if items_per_page:
                params["items_per_page"] = items_per_page
            if page:
                params["page"] = page

            return redirect(reverse("employee:branch_create") + "?" + "&".join([f"{k}={v}" for k, v in params.items()]))
    except IntegrityError as ie:
        # likely unique constraint; present friendly error
        errtxt = str(ie)
        if "unique" in errtxt.lower():
            # try to pull which field
            if "name" in errtxt.lower():
                errors["name"] = "A branch with this name already exists."
            elif "branch_code" in errtxt.lower():
                errors["branch_code"] = "A branch with this code already exists."
            else:
                errors["__all__"] = "Duplicate value error."
        else:
            errors["__all__"] = "Database error while saving the branch."
    except ValidationError as ve:
        if hasattr(ve, "message_dict"):
            for k, v in ve.message_dict.items():
                errors[k] = v[0] if isinstance(v, (list, tuple)) else str(v)
        else:
            errors["__all__"] = str(ve)
    except Exception as exc:
        # print("branch_create: unexpected error:", exc)
        traceback.print_exc()
        errors["__all__"] = "An unexpected error occurred while creating the branch."

    # on error -> re-render preserving entered values
    context = {
        **posted,
        "lcos": LCO.objects.order_by("name").all() if hasattr(LCO, "objects") else [],
        "errors": errors,
        "q": q,
        "items_per_page": items_per_page,
        "page": page,
        "photo_url": "",  # if upload failed, we don't have a saved photo
    }
    return render(request, template, context)










@require_http_methods(["GET", "POST"])
@login_required
def branch_edit(request, pk):    
    def _format_timestamp(log_obj):
        # try common timestamp fields and format them for display
        dt = getattr(log_obj, "created_at", None) or getattr(log_obj, "created", None) or getattr(log_obj, "timestamp", None)
        if not dt:
            return ""
        try:
            return localtime(dt).strftime("%Y-%m-%d %H:%M:%S")
        except Exception:
            try:
                return str(dt)
            except Exception:
                return ""
    
    def _shorten_filename(val):
        """
        If `val` looks like a path or URL, return its basename.
        Otherwise return `val` unchanged.
        """
        if val is None:
            return val
        # Only operate on strings
        try:
            if not isinstance(val, str):
                return val
        except Exception:
            return val
    
        s = val.strip()
        if s == "":
            return s
    
        # If it's a URL, parse and take path basename
        try:
            if s.startswith("http://") or s.startswith("https://"):
                p = urlparse(s)
                if p.path:
                    name = os.path.basename(p.path)
                    return name or s
        except Exception:
            pass
    
        # common media prefixes: if it contains slashes, take last segment
        if "/" in s or "\\" in s:
            # remove query string or fragment if present
            s_no_q = s.split("?", 1)[0].split("#", 1)[0]
            # now take basename (handles both / and \)
            try:
                name = os.path.basename(s_no_q)
                return name or s_no_q
            except Exception:
                # fallback: split manually
                parts = s_no_q.replace("\\", "/").split("/")
                return parts[-1] if parts else s_no_q
    
        # else return as-is
        return s
    
    def _format_change_value(val):
        """
        Apply formatting rules to a change value before display in the log.
        Currently shortens file paths/URLs to the filename.
        Could add more formatting later (e.g. pretty dates, boolean -> Yes/No).
        """
        # keep None as-is
        if val is None:
            return None
        # if it's a dict/list, stringify compactly
        if isinstance(val, (dict, list, tuple)):
            try:
                return json.dumps(val, default=str)
            except Exception:
                return str(val)
        # try shortening filenames/urls for strings
        if isinstance(val, str):
            short = _shorten_filename(val)
            return short
        # fallback for other types
        try:
            return str(val)
        except Exception:
            return val
    
    def get_branch_change_groups(branch):
        """
        Returns (update_groups, create_groups)
        Each group: {
          "changed_by_display": "...",
          "change_timestamp": "YYYY-mm-dd HH:MM:SS",
          "changes": [ { "field_changed": "<field>", "old_value": "...", "new_value": "..." }, ... ]
        }
        """
        update_groups = []
        create_groups = []
        try:
            qs = BranchChangeLog.objects.filter(branch=branch).order_by('-id')
        except Exception:
            return [], []
    
        for log in qs:
            # actor display
            actor = getattr(log, "changed_by", None)
            if actor:
                try:
                    name = getattr(actor, "get_full_name", lambda: "")()
                    if not name:
                        name = getattr(actor, "username", None) or getattr(actor, "email", None) or str(actor)
                except Exception:
                    name = str(actor)
                changed_by_display = name
            else:
                changed_by_display = (getattr(log, "meta", {}) or {}).get("user_agent", "")[:50] or "System"
    
            ts = _format_timestamp(log)
    
            # parse stored changes (best-effort)
            changes_parsed = []
            raw = getattr(log, "changes", None)
            data = None
            if isinstance(raw, dict):
                data = raw
            else:
                try:
                    data = json.loads(raw) if raw else {}
                except Exception:
                    data = {}
    
            # expect diff
            diff = {}
            if isinstance(data, dict):
                diff = data.get("diff") or data.get("changes") or data.get("difference") or {}
    
            if isinstance(diff, dict) and diff:
                for field, change in diff.items():
                    old = change.get("old") if isinstance(change, dict) else None
                    new = change.get("new") if isinstance(change, dict) else None
                    changes_parsed.append({
                        "field_changed": field,
                        "old_value": _format_change_value(old),
                        "new_value": _format_change_value(new),
                    })
            else:
                old_snap = data.get("old") if isinstance(data, dict) else None
                new_snap = data.get("new") if isinstance(data, dict) else None
                if isinstance(old_snap, dict) and isinstance(new_snap, dict):
                    for k in sorted(set(list(old_snap.keys()) + list(new_snap.keys()))):
                        o = old_snap.get(k)
                        n = new_snap.get(k)
                        if o != n:
                            changes_parsed.append({
                                "field_changed": k,
                                "old_value": _format_change_value(o),
                                "new_value": _format_change_value(n),
                            })
    
            # fallback: if still empty show raw json compact
            if not changes_parsed:
                raw_txt = ''
                try:
                    raw_txt = json.dumps(data, indent=None, default=str) if data else (raw or "")
                except Exception:
                    raw_txt = (raw or "")
                if raw_txt:
                    changes_parsed.append({
                        "field_changed": "(raw)",
                        "old_value": "",
                        "new_value": _format_change_value(raw_txt),
                    })
    
            # classify action
            action = getattr(log, "action", "") or ""
            act_lower = str(action).lower() if action else ""
            entry = {
                "changed_by_display": changed_by_display,
                "change_timestamp": ts,
                "changes": changes_parsed
            }
            if "create" in act_lower or act_lower in ("created","add","insert"):
                create_groups.append(entry)
            else:
                update_groups.append(entry)
    
        return update_groups, create_groups
    
    template = "employe/branch_edit.html"

    # preserve list/search state
    q = request.GET.get("q", "") if request.method == "GET" else (request.POST.get("q", "") or request.GET.get("q", ""))
    items_per_page = request.GET.get("items_per_page", "") if request.method == "GET" else (request.POST.get("items_per_page", "") or request.GET.get("items_per_page", ""))
    page = request.GET.get("page", "") if request.method == "GET" else (request.POST.get("page", "") or request.GET.get("page", ""))

    # resolve branch
    try:
        branch = get_object_or_404(Branch, pk=pk)
    except Exception:
        messages.error(request, "Branch not found.")
        return redirect(reverse("employee:branch_create"))

    # defaults for posted values and preview (include id/name fallbacks for country/state/district)
    defaults = {
        "name": branch.name or "",
        "branch_code": branch.branch_code or "",
        "lco_id": getattr(branch.lco, "pk", "") or "",
        "branch_email": branch.branch_email or "",
        "branch_mobile": branch.branch_mobile or "",
        "branch_phone": branch.branch_phone or "",
        "branch_street": branch.branch_street or "",
        "branch_street2": branch.branch_street2 or "",
        "branch_city": branch.branch_city or "",
        "branch_state": branch.branch_state or "",
        "branch_country": branch.branch_country or "",
        "branch_pincode": branch.branch_pincode or "",
        "photo_url": (branch.photo.url if getattr(branch, "photo", None) else ""),

        # server-rendered option values for JS/template (works for name or id storage)
        "branch_country_id": (getattr(branch, "branch_country_id", None) or getattr(branch, "branch_country", "")) or "",
        "branch_country_name": (getattr(branch, "branch_country_name", None) or getattr(branch, "branch_country", "")) or "",
        "branch_state_id": (getattr(branch, "branch_state_id", None) or getattr(branch, "branch_state", "")) or "",
        "branch_state_name": (getattr(branch, "branch_state_name", None) or getattr(branch, "branch_state", "")) or "",
        "branch_district_id": (getattr(branch, "branch_district_id", None) or getattr(branch, "branch_city", "")) or "",
        "branch_district_name": (getattr(branch, "branch_district_name", None) or getattr(branch, "branch_city", "")) or "",
        "warehouse": (getattr(branch, "warehouse", None) or "") or "",
        "selected_warehouse_id": (getattr(branch, "warehouse_id", None) or "") or "",
    }
    # print("default" , defaults['branch_district_id'])
    # GET: render form
    if request.method == "GET":
        created_branch_name = request.GET.get("created_branch_name", "")  # used to trigger modal
        update_groups, create_groups = get_branch_change_groups(branch)
        user = request.user
        lco_choices = LCO.objects.none()  # Default to empty
        disable_lco_select = False
        selected_lco_id = getattr(branch.lco, "pk", "")  # Pre-fill from branch instance
        # print('jsdbfd')
        # print(selected_lco_id)
        # print('jsdbfd')

        if user.is_authenticated:
            if user.user_type == "distributer" and user.distributer:
                # LCOs under all SubDistributers belonging to this Distributer
                lco_choices = LCO.objects.filter(
                    sub_distributer__distributer=user.distributer,
                    is_active=True
                ).order_by("name")

            elif user.user_type == "subdistributer" and user.subdistributer:
                # LCOs under this subdistributer
                lco_choices = LCO.objects.filter(
                    sub_distributer=user.subdistributer,
                    is_active=True
                ).order_by("name")

            elif user.user_type == "lco" and user.lco:
                # Only show this LCO and disable select
                lco_choices = LCO.objects.filter(
                    pk=user.lco.pk,
                    is_active=True
                )
                selected_lco_id = user.lco.pk
                disable_lco_select = True

            else:
                # Show all LCOs
                lco_choices = LCO.objects.filter(is_active=True).order_by("name")
        context = {
            **defaults,
            "lcos": lco_choices,
            "lco_id": selected_lco_id,
            "disable_lco_select": disable_lco_select,
            "errors": {},
            "q": q,
            "items_per_page": items_per_page,
            "page": page,
            "branch": branch,
            "created_branch_name": request.GET.get("created_branch_name", ""),
            "update_groups": update_groups,
            "create_groups": create_groups,
        }
        return render(request, template, context)

    # ------- POST -------
    errors = {}
    # posted keys come from defaults.keys() so include our branch_*_id keys too
    posted = {k: (request.POST.get(k, "") or "").strip() for k in defaults.keys()}
    def _clean_location_value(val):
        if not isinstance(val, str):
            return val
        val = val.strip()
        # Check for the "Name - id/code" format and extract only the Name part
        if " - " in val:
            parts = val.split(" - ", 1)
            # Assuming the Name is the first part
            return parts[0].strip()
        return val

    # **START OF CORRECTION FOR CASE-SENSITIVITY ISSUE**

    # Clean up the posted location data before using it for comparison/assignment
    for fld in ["branch_country", "branch_state", "branch_city"]:
        if posted.get(fld):
            # 1. Apply cleaning (e.g., strip ID if present)
            cleaned_val = _clean_location_value(posted[fld])
            # 2. Convert to lowercase for consistent saving/comparison (the FIX)
            posted[fld] = cleaned_val.lower() if isinstance(cleaned_val, str) else cleaned_val
        
    # Map optional alternate names (district -> branch_city)
    if request.POST.get("branch_district_id"):
        district_val = request.POST.get("branch_district_id").strip()
        cleaned_district_val = _clean_location_value(district_val)
        # Convert to lowercase for consistency
        posted["branch_city"] = cleaned_district_val.lower() if isinstance(cleaned_district_val, str) else cleaned_district_val

    # **END OF CORRECTION**

    # image handling
    image = request.FILES.get("photo") or None
    remove_image_flag = (request.POST.get("remove_image") == "1")

    # Validate required fields (same as before)
    required_fields = {
        "name": "Branch Name is required.",
        "branch_code": "Branch Code is required.",
        "branch_email": "Email is required.",
        "branch_mobile": "Mobile is required.",
        "branch_country": "Country is required.",
        "branch_state": "State is required.",
        "branch_city": "District / City is required.",
        "branch_street": "Address is required.",
    }
    for fld, msg in required_fields.items():
        if not posted.get(fld):
            errors[fld] = msg

    # Email validation
    if posted.get("branch_email"):
        try:
            EmailValidator()(posted["branch_email"])
        except ValidationError:
            errors["branch_email"] = "Enter a valid email address."

    # Mobile / phone basic validation
    if posted.get("branch_mobile"):
        if not re.match(r'^[\d\+\-\s\(\)]{6,20}$', posted["branch_mobile"]):
            errors["branch_mobile"] = "Enter a valid mobile number."
    if posted.get("branch_phone"):
        if not re.match(r'^[\d\+\-\s\(\)]{6,20}$', posted["branch_phone"]):
            errors["branch_phone"] = "Enter a valid phone number."

    # Unique constraints: exclude current branch
    if posted.get("name"):
        qs = Branch.objects.filter(name__iexact=posted["name"]).exclude(pk=branch.pk)
        if qs.exists():
            errors["name"] = "A branch with this name already exists."
    if posted.get("branch_code"):
        qs = Branch.objects.filter(branch_code__iexact=posted["branch_code"]).exclude(pk=branch.pk)
        if qs.exists():
            errors["branch_code"] = "A branch with this code already exists."

    # If any server-side errors -> re-render with posted values
    if errors:
        context = {
            **posted,
            "lcos": LCO.objects.order_by("name").all() if hasattr(LCO, "objects") else [],
            "errors": errors,
            "q": q,
            "items_per_page": items_per_page,
            "page": page,
            "photo_url": (branch.photo.url if getattr(branch, "photo", None) else ""),
            "branch": branch,
        }
        return render(request, template, context)

    # Helper: robust serializer for snapshot/diff
    def _serializable_value(x):
        try:
            import datetime as _dt
            if isinstance(x, (_dt.date, _dt.datetime)):
                return x.isoformat()
        except Exception:
            try:
                if hasattr(x, "isoformat"):
                    return x.isoformat()
            except Exception:
                pass
        try:
            if isinstance(x, Decimal):
                return str(x)
        except Exception:
            pass
        return x

    # prepare old snapshot (for changelog)
    old_snapshot = {
        "name": branch.name,
        "branch_code": branch.branch_code,
        "lco_id": getattr(branch.lco, "pk", None),
        "lco_name": getattr(branch.lco, "name", "") if getattr(branch, "lco", None) else "",
        "branch_email": branch.branch_email,
        "branch_mobile": branch.branch_mobile,
        "branch_phone": branch.branch_phone,
        "branch_street": branch.branch_street,
        "branch_street2": branch.branch_street2,
        "branch_city": branch.branch_city,
        "branch_state": branch.branch_state,
        "branch_country": branch.branch_country,
        "branch_pincode": branch.branch_pincode,
        "photo": (branch.photo.name if getattr(branch, "photo", None) else ""),
        "is_active": getattr(branch, "is_active", None),
    }

    # Determine changed fields and apply them to the branch instance (but don't save yet)
    changed_fields = []

    # scalar fields to consider (posted keys same as model attributes)
    scalar_fields = [
        "name", "branch_code", "branch_email", "branch_mobile", "branch_phone",
        "branch_street", "branch_street2", "branch_city", "branch_state",
        "branch_country", "branch_pincode"
    ]
    
    # **START OF CORRECTION FOR CASE-SENSITIVITY ISSUE**

    location_fields = ["branch_city", "branch_state", "branch_country"]

    for fld in scalar_fields:
        oldv = getattr(branch, fld, None)
        new_raw = posted.get(fld, "")
        newv = new_raw if new_raw != "" else None

        is_changed = False
        
        # Check for change with case-insensitivity for location fields (the FIX)
        if fld in location_fields:
            old_normalized = str(oldv).lower().strip() if isinstance(oldv, str) and oldv else None
            new_normalized = str(newv).lower().strip() if isinstance(newv, str) and newv else None
            
            # Use normalized values for comparison
            if old_normalized != new_normalized:
                is_changed = True
        else:
            # Use original serializable values for all other fields (case-sensitive)
            if _serializable_value(oldv) != _serializable_value(newv):
                is_changed = True

        if is_changed:
            # Assign the new value (which is already lowercase for location fields)
            setattr(branch, fld, newv)
            changed_fields.append(fld)
            
    # **END OF CORRECTION**

    # handle is_active checkbox explicitly (checkbox sends "true" or "on" when checked)
    posted_is_active = request.POST.get("is_active", None)
    if posted_is_active is not None:
        new_active = posted_is_active.lower() in ("true", "1", "on", "yes")
        old_active = bool(getattr(branch, "is_active", False))
        if new_active != old_active:
            branch.is_active = new_active
            changed_fields.append("is_active")

    # handle LCO FK specially (compare PKs)
    lco_id_raw = posted.get("lco_id", "") or ""
    if lco_id_raw:
        try:
            lco_pk = int(lco_id_raw)
        except Exception:
            lco_pk = None
        if lco_pk:
            old_lco_pk = getattr(branch.lco, "pk", None)
            if old_lco_pk != lco_pk:
                try:
                    branch.lco = LCO.objects.get(pk=lco_pk)
                    changed_fields.append("lco")
                except Exception:
                    # invalid lco chosen -> clear and record error
                    branch.lco = None
                    changed_fields.append("lco")
        else:
            # provided non-numeric -> try match against name fallback
            try:
                lco_obj = LCO.objects.filter(name__iexact=lco_id_raw).first()
                new_lco_pk = getattr(lco_obj, "pk", None)
                if getattr(branch.lco, "pk", None) != new_lco_pk:
                    branch.lco = lco_obj
                    changed_fields.append("lco")
            except Exception:
                pass
    else:
        # user cleared LCO
        if getattr(branch, "lco", None) is not None:
            branch.lco = None
            changed_fields.append("lco")
    if not(posted.get("warehouse")):
        errors['warehouse'] = "Warehouse is required."
    else :
        branch.warehouse = Warehouse.objects.get(pk=posted.get("warehouse"))
        changed_fields.append("warehouse")
    # handle photo removal
    if remove_image_flag:
        if getattr(branch, "photo", None):
            try:
                branch.photo.delete(save=False)
            except Exception:
                pass
        branch.photo = None
        if "photo" not in changed_fields:
            changed_fields.append("photo")

    # handle uploaded image
    if image:
        branch.photo = image
        if "photo" not in changed_fields:
            changed_fields.append("photo")

    # If nothing changed -> redirect back with info message (no DB write)
    if not changed_fields:
        messages.info(request, "No changes detected; nothing to save.")
        params = {}
        if q: params["q"] = q
        if items_per_page: params["items_per_page"] = items_per_page
        if page: params["page"] = page
        params["updated"] = "0"
        query_string = ("?" + urlencode(params)) if params else ""
        return redirect(reverse("employee:branch_edit", args=[branch.pk]) + query_string)

    # model validation for the updated model
    try:
        branch.full_clean()
    except ValidationError as ve:
        vdict = {}
        if hasattr(ve, "message_dict"):
            for fld, msgs in ve.message_dict.items():
                vdict[fld] = msgs[0] if isinstance(msgs, (list, tuple)) else str(msgs)
        else:
            vdict["__all__"] = str(ve)
        context = {
            **posted,
            "lcos": LCO.objects.order_by("name").all() if hasattr(LCO, "objects") else [],
            "errors": vdict,
            "q": q,
            "items_per_page": items_per_page,
            "page": page,
            "photo_url": (branch.photo.url if getattr(branch, "photo", None) else ""),
            "branch": branch,
        }
        return render(request, template, context)

    # Save changed fields inside transaction
    try:
        with transaction.atomic():
            # Save only changed fields
            branch.save(update_fields=changed_fields)

            # prepare new snapshot (after save)
            new_snapshot = {
                "name": branch.name,
                "branch_code": branch.branch_code,
                "lco_id": getattr(branch.lco, "pk", None),
                "lco_name": getattr(branch.lco, "name", "") if getattr(branch, "lco", None) else "",
                "branch_email": branch.branch_email,
                "branch_mobile": branch.branch_mobile,
                "branch_phone": branch.branch_phone,
                "branch_street": branch.branch_street,
                "branch_street2": branch.branch_street2,
                "branch_city": branch.branch_city,
                "branch_state": branch.branch_state,
                "branch_country": branch.branch_country,
                "branch_pincode": branch.branch_pincode,
                "photo": (branch.photo.name if getattr(branch, "photo", None) else ""),
                "is_active": getattr(branch, "is_active", None),
            }

            # compute diff
            diff = {}
            for k, oldv in old_snapshot.items():
                newv = new_snapshot.get(k)
                if _serializable_value(oldv) != _serializable_value(newv):
                    diff[k] = {"old": _serializable_value(oldv), "new": _serializable_value(newv)}

            # write change log (best-effort) only if diff non-empty
            if diff:
                try:
                    action_val = getattr(BranchChangeLog, "ACTION_UPDATE", "update")
                    BranchChangeLog.objects.create(
                        branch=branch,
                        changed_by=(request.user if getattr(request, "user", None) and request.user.is_authenticated else None),
                        action=action_val,
                        changes=json.dumps({"old": old_snapshot, "new": new_snapshot, "diff": diff}, default=str),
                        summary=f"Updated Branch: {branch.name}",
                        meta={"ip": request.META.get("REMOTE_ADDR"), "user_agent": request.META.get("HTTP_USER_AGENT", "")[:255]},
                    )
                except Exception:
                    traceback.print_exc()

    except IntegrityError as ie:
        # handle unique constraint error gracefully
        errtxt = str(ie)
        if "unique" in errtxt.lower():
            if "name" in errtxt.lower():
                errors["name"] = "A branch with this name already exists."
            elif "branch_code" in errtxt.lower():
                errors["branch_code"] = "A branch with this code already exists."
            else:
                errors["__all__"] = "Duplicate value error."
        else:
            errors["__all__"] = "Database error while saving the branch."

    except Exception as exc:
        traceback.print_exc()
        errors["__all__"] = "An unexpected error occurred while updating the branch."

    # on errors -> re-render preserving entered values
    if errors:
        context = {
            **posted,
            "lcos": LCO.objects.order_by("name").all() if hasattr(LCO, "objects") else [],
            "errors": errors,
            "q": q,
            "items_per_page": items_per_page,
            "page": page,
            "photo_url": (branch.photo.url if getattr(branch, "photo", None) else ""),
            "branch": branch,
        }
        return render(request, template, context)

    # success -> redirect back to edit page (or list) and show a success message + trigger modal
    messages.success(request, f"Branch '{branch.name}' saved successfully.")

    params = {}
    if q: params["q"] = q
    if items_per_page: params["items_per_page"] = items_per_page
    if page: params["page"] = page
    params["updated"] = "1"
    # include branch name so template can open the success modal
    params["created_branch_name"] = branch.name or ""

    query_string = ("?" + urlencode(params)) if params else ""
    return redirect(reverse("employee:branch_edit", args=[branch.pk]) + query_string)












def _serialize_item(obj):
    return {
        "id": obj.id,
        "name": str(obj.name),
        "code": str(obj.code) if getattr(obj, "code", None) is not None else ""
    }


# ------------------ POSITIONS ------------------

@require_GET
@login_required
def list_positions_ajax(request):
    q = (request.GET.get('q') or '').strip()
    qs = JobPosition.objects.all().order_by('name')
    if q:
        qs = qs.filter(name__icontains=q) | qs.filter(code__icontains=q)
    items = [ _serialize_item(p) for p in qs[:100] ]  # limit results
    return JsonResponse({"items": items})

def _friendly_integrity_errors(exc, model_label='position'):
    """
    Try to map IntegrityError to a short, friendly error dict.
    Returns a dict suitable for {"errors": {...}}
    """
    try:
        # 1) Try to read constraint name from DB driver (psycopg2 diag)
        cause = getattr(exc, '__cause__', None) or getattr(exc, 'original_exception', None)
        diag = getattr(cause, 'diag', None)
        if diag is not None:
            cname = getattr(diag, 'constraint_name', None)
            if cname:
                # common naming patterns: employe_jobposition_code_key, ..._name_key
                if 'code' in cname.lower():
                    return {'code': f"A {model_label} with that code already exists."}
                if 'name' in cname.lower():
                    return {'name': f"A {model_label} with that name already exists."}
                # fallback to generic
                return {'__all__': f"A {model_label} with that value already exists."}
    except Exception:
        # Don't fail if diag parsing throws
        logger.debug("Could not parse diag from IntegrityError: %s", exc, exc_info=True)

    # 2) Try regex on exception message (postgres text like: Key (code)=(onee) already exists.)
    msg = str(exc).lower()
    m = re.search(r'key\s*\(\s*([a-z0-9_]+)\s*\)\s*=', msg)
    if m:
        col = m.group(1)
        if 'code' in col:
            return {'code': f"A {model_label} with that code already exists."}
        if 'name' in col:
            return {'name': f"A {model_label} with that name already exists."}

    # 3) generic fallback
    if 'unique' in msg or 'already exists' in msg:
        return {'__all__': f"A {model_label} with that name or code already exists."}

    return {'__all__': "Database error."}


# ------------------ POSITIONS ------------------

@require_POST
@login_required
def create_position_ajax(request):
    name = (request.POST.get('name') or '').strip()
    code = (request.POST.get('code') or '').strip()
    if code == '':
        code = None

    errors = {}
    if not name:
        errors['name'] = "Name is required."
    elif len(name) > 100:
        errors['name'] = "Name must be 100 characters or fewer."
    if code and len(code) > 20:
        errors['code'] = "Code must be 20 characters or fewer."

    if errors:
        return JsonResponse({"errors": errors}, status=400)

    try:
        with transaction.atomic():
            # defensive duplicate checks (case-insensitive)
            if JobPosition.objects.filter(name__iexact=name).exists():
                return JsonResponse({"errors": {"name": "A position with that name already exists."}}, status=400)

            if code and JobPosition.objects.filter(code__iexact=code).exists():
                return JsonResponse({"errors": {"code": "A position with that code already exists."}}, status=400)

            pos = JobPosition.objects.create(name=name, code=code)
            return JsonResponse({"success": True, "id": pos.id, "name": pos.name,"code":pos.code, "created": True})

    except IntegrityError as e:
        # log full exception for debugging, return friendly message
        logger.exception("IntegrityError while creating JobPosition: %s", e)
        return JsonResponse({"errors": _friendly_integrity_errors(e, model_label='position')}, status=400)


@require_POST
@login_required
def update_position_ajax(request):
    sid = request.POST.get('id') or request.POST.get('pk') or None
    name = (request.POST.get('name') or '').strip()
    code = (request.POST.get('code') or '').strip() or None

    if not sid:
        return JsonResponse({"errors": {"id": "Missing id"}}, status=400)

    errors = {}
    if not name:
        errors['name'] = "Name is required."
    elif len(name) > 100:
        errors['name'] = "Name must be 100 characters or fewer."
    if code and len(code) > 20:
        errors['code'] = "Code must be 20 characters or fewer."

    if errors:
        return JsonResponse({"errors": errors}, status=400)

    try:
        obj = JobPosition.objects.get(pk=sid)
    except JobPosition.DoesNotExist:
        return JsonResponse({"errors": {"id": "Position not found"}}, status=404)

    try:
        with transaction.atomic():
            # Defensive duplicate checks excluding the current object
            if JobPosition.objects.filter(name__iexact=name).exclude(pk=obj.pk).exists():
                return JsonResponse({"errors": {"name": "A position with that name already exists."}}, status=400)
            if code and JobPosition.objects.filter(code__iexact=code).exclude(pk=obj.pk).exists():
                return JsonResponse({"errors": {"code": "A position with that code already exists."}}, status=400)

            obj.name = name
            obj.code = code
            obj.save()
            return JsonResponse({"success": True, "id": obj.id, "name": obj.name,"code":obj.code})
    except IntegrityError as e:
        logger.exception("IntegrityError while updating JobPosition id=%s: %s", sid, e)
        return JsonResponse({"errors": _friendly_integrity_errors(e, model_label='position')}, status=400)


# ------------------ DEPARTMENTS ------------------

@require_GET
@login_required
def list_departments_ajax(request):
    q = (request.GET.get('q') or '').strip()
    qs = Department.objects.all().order_by('name')
    if q:
        qs = qs.filter(name__icontains=q) | qs.filter(code__icontains=q)
    items = [{ "id": d.id, "name": d.name, "code": d.code or "" } for d in qs[:100]]
    return JsonResponse({"items": items})


@require_POST
@login_required
def create_department_ajax(request):
    name = (request.POST.get('name') or '').strip()
    code = (request.POST.get('code') or '').strip() or None

    errors = {}
    if not name:
        errors['name'] = "Name is required."
    elif len(name) > 100:
        errors['name'] = "Name must be 100 characters or fewer."
    if code and len(code) > 10:
        errors['code'] = "Code must be 10 characters or fewer."

    if errors:
        return JsonResponse({"errors": errors}, status=400)

    try:
        with transaction.atomic():
            obj, created = Department.objects.get_or_create(name=name, defaults={'code': code})
            if not created:
                if code and obj.code != code:
                    obj.code = code
                    obj.save()
                return JsonResponse({"success": True, "id": obj.id, "name": obj.name,"code":obj.code, "created": False})
            return JsonResponse({"success": True, "id": obj.id, "name": obj.name,"code":obj.code, "created": True})
    except IntegrityError as e:
        logger.exception("IntegrityError while creating Department: %s", e)
        return JsonResponse({"errors": _friendly_integrity_errors(e, model_label='department')}, status=400)


@require_POST
@login_required
def update_department_ajax(request):
    sid = request.POST.get('id') or request.POST.get('pk') or None
    name = (request.POST.get('name') or '').strip()
    code = (request.POST.get('code') or '').strip() or None

    if not sid:
        return JsonResponse({"errors": {"id": "Missing id"}}, status=400)

    errors = {}
    if not name:
        errors['name'] = "Name is required."
    elif len(name) > 100:
        errors['name'] = "Name must be 100 characters or fewer."
    if code and len(code) > 10:
        errors['code'] = "Code must be 10 characters or fewer."

    if errors:
        return JsonResponse({"errors": errors}, status=400)

    try:
        obj = Department.objects.get(pk=sid)
    except Department.DoesNotExist:
        return JsonResponse({"errors": {"id": "Department not found"}}, status=404)

    try:
        with transaction.atomic():
            if Department.objects.filter(name__iexact=name).exclude(pk=obj.pk).exists():
                return JsonResponse({"errors": {"name": "A department with that name already exists."}}, status=400)
            if code and Department.objects.filter(code__iexact=code).exclude(pk=obj.pk).exists():
                return JsonResponse({"errors": {"code": "A department with that code already exists."}}, status=400)

            obj.name = name
            obj.code = code
            obj.save()
            return JsonResponse({"success": True, "id": obj.id, "name": obj.name,"code":obj.code})
    except IntegrityError as e:
        logger.exception("IntegrityError while updating Department id=%s: %s", sid, e)
        return JsonResponse({"errors": _friendly_integrity_errors(e, model_label='department')}, status=400)
    



@require_GET
def list_marital_status_ajax(request):
    q = (request.GET.get('q') or '').strip()
    qs = MaritalStatus.objects.all()

    if q:
        qs = qs.filter(
            Q(name__icontains=q) | Q(discription__icontains=q)
        )

    qs = qs.order_by('name')
    
    items = [
        {
            "id": d.id,
            "name": d.name,
            "code": d.discription or ""
        }
        for d in qs[:100]
    ]
    return JsonResponse({"items": items})
@require_POST
def create_marital_status_ajax(request):
    try:    
        name = (request.POST.get('name') or '').strip()
        description = (request.POST.get('code') or '').strip() or None
        # print(description)

        # Basic validation
        if not name:
            return JsonResponse({'errors': {'name': 'Name is required.'}}, status=400)

        # Check for duplicates
        existing = MaritalStatus.objects.filter(name__iexact=name).first()
        if existing:
            return JsonResponse({
                'success': True,
                'created': False,
                'id': existing.id,
                'name': existing.name,
                'code': existing.discription
            }, status=200)

        # Create new marital status
        ms = MaritalStatus.objects.create(name=name, discription=description)
        return JsonResponse({
            'success': True,
            'created': True,
            'id': ms.id,
            'name': ms.name,
            'discription': ms.discription
        }, status=201)

    except Exception as e:
        return JsonResponse({'errors': {'__all__': str(e)}}, status=500)
    

@require_POST
def update_marital_status_ajax(request):
    try:
        id = request.POST.get('id')
        name = (request.POST.get('name') or '').strip()
        description = (request.POST.get('discription') or '').strip() or None

        if not id or not name:
            return JsonResponse({'errors': {'name': 'ID and Name are required.'}}, status=400)

        try:
            ms = MaritalStatus.objects.get(id=id)
        except MaritalStatus.DoesNotExist:
            return JsonResponse({'errors': {'__all__': 'Marital status not found.'}}, status=404)

        # Check for duplicate name in other records
        if MaritalStatus.objects.exclude(id=id).filter(name__iexact=name).exists():
            return JsonResponse({
                'success': True,
                'created': False,
                'id': ms.id,
                'name': ms.name,
                'discription': ms.discription
            }, status=200)

        # Update record
        ms.name = name
        ms.discription = description
        ms.save()

        return JsonResponse({
            'success': True,
            'created': True,
            'id': ms.id,
            'name': ms.name,
            'discription': ms.discription
        }, status=200)

    except Exception as e:
        return JsonResponse({'errors': {'__all__': str(e)}}, status=500)
