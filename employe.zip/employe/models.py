from django.db import models
from django.core.validators import RegexValidator
from django.core.validators import RegexValidator, FileExtensionValidator
from django.conf import settings
from django.utils.html import format_html
from django.db.models import JSONField
from django.core.validators import MinValueValidator
PHONE_VALIDATOR = RegexValidator(r'^\+?\d{7,15}$', "Enter a valid phone number.")
from decimal import Decimal

class Branch(models.Model):
    name = models.CharField("Branch Name", max_length=255, unique=True)
    branch_code = models.CharField(
        "Branch Code",
        max_length=50,
        unique=True,
        blank=True,
        null=True,
        help_text="Optional short unique identifier for the branch (e.g. BR-001)."
    )

    # relation to LCO: optional (a branch may belong to an LCO)
    lco = models.ForeignKey(
        'LCO.LCO',                # change 'your_app' to the actual app label if LCO is in same or different app
        on_delete=models.SET_NULL,
        related_name='branches',
        blank=True,
        null=True,
        help_text="Optional Local Cable Operator for this branch."
    )

    branch_email = models.EmailField("Email", blank=True, null=True)
    branch_mobile = models.CharField(
        "Mobile",
        max_length=20,
        blank=True,
        null=True,
        validators=[PHONE_VALIDATOR]
    )
    branch_phone = models.CharField(
        "Phone",
        max_length=20,
        blank=True,
        null=True,
        validators=[PHONE_VALIDATOR]
    )

    branch_street  = models.CharField("Street",  max_length=255, blank=True, null=True)
    branch_street2 = models.CharField("Street2", max_length=255, blank=True, null=True)
    branch_city    = models.CharField("City",    max_length=100, blank=True, null=True)
    branch_state   = models.CharField("State",   max_length=100, blank=True, null=True)
    branch_country = models.CharField("Country", max_length=100, blank=True, null=True)
    branch_pincode = models.CharField("Pincode", max_length=12, blank=True, null=True)

    # photo - requires Pillow
    photo = models.ImageField(
        upload_to='branches/photos/%Y/%m/%d/',
        blank=True,
        null=True,
        help_text="Optional photo for the branch (PNG/JPG/WebP)."
    )
    warehouse = models.ForeignKey('warehouse.Warehouse', on_delete=models.SET_NULL, blank=True, null=True)
    USER_TYPES = [
        ('distributer', 'Distributer'),
        ('subdistributer', 'SubDistributer'),
        ('lco', 'LCO'),
    ]
    type = models.CharField(max_length=50, choices=USER_TYPES, default='lco', help_text="Type of user",blank=True, null=True)
    type_id = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True,null=True,blank=True)
    updated_at = models.DateTimeField(auto_now=True,null=True,blank=True)

    class Meta:
        verbose_name = "Branch"
        verbose_name_plural = "Branches"
        ordering = ['name']

    def __str__(self):
        if self.branch_code:
            return f"{self.name} ({self.branch_code})"
        return self.name

    def photo_tag(self):
        """Admin helper: small thumbnail"""
        if self.photo:
            return format_html('<img src="{}" style="max-width:120px; max-height:80px; object-fit:cover;"/>', self.photo.url)
        return "-"
    photo_tag.short_description = "Photo"
    photo_tag.allow_tags = True



class BranchChangeLog(models.Model):
    ACTION_CREATE = "create"
    ACTION_UPDATE = "update"
    ACTION_DELETE = "delete"
    ACTION_CHOICES = (
        (ACTION_CREATE, "Created"),
        (ACTION_UPDATE, "Updated"),
        (ACTION_DELETE, "Deleted"),
    )

    branch = models.ForeignKey(
        "employe.Branch",
        on_delete=models.CASCADE,
        related_name="change_logs",
        help_text="Branch that was changed",
    )
    changed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="branch_change_logs",
        help_text="User who made the change (if available)"
    )
    action = models.CharField(max_length=10, choices=ACTION_CHOICES)
    # field-> {old:..., new:...}
    changes = JSONField(null=True, blank=True)
    # human readable summary (short)
    summary = models.CharField(max_length=255, blank=True, default="")
    # optional meta (ip, user_agent, extra)
    meta = JSONField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["branch"]),
            models.Index(fields=["created_at"]),
        ]

    def __str__(self):
        return f"{self.get_action_display()} {self.branch} at {self.created_at.isoformat()}"
    



class Department(models.Model):
    name        = models.CharField("Department Name", max_length=100, unique=True)
    code        = models.CharField("Code", max_length=10, blank=True, null=True,unique=True,
                                   help_text="Optional short code, e.g. ENG, HR")
    description = models.TextField("Description", blank=True, null=True)

    class Meta:
        verbose_name        = "Department"
        verbose_name_plural = "Departments"
        ordering            = ['name']

    def __str__(self):
        return self.name
    




GENDER_CHOICES = [
    ('male',   'Male'),
    ('female', 'Female'),
    ('other',  'Other'),
]

MARITAL_STATUS_CHOICES = [
    ('single',   'Single'),
    ('married',  'Married'),
    ('divorced', 'Divorced'),
    ('widowed',  'Widowed'),
]

WORK_PERMIT_CHOICES = [
    ('yes', 'Yes'),
    ('no',  'No'),
]

CERTIFICATION_CHOICES = [
    ('bachelor', 'Bachelor’s Degree'),
    ('master',   'Master’s Degree'),
    ('other',    'Other'),
]



class JobPosition(models.Model):
    """
    Master table for all possible employee job positions.
    """
    code = models.CharField(
        max_length=20,
        unique=True,
        help_text="Short unique code, e.g. DEV, MGR",null=True,blank=True
    )
    name = models.CharField(
        max_length=100,
        help_text="Human‑readable name, e.g. Developer, Manager"
    )
    description = models.TextField(
        blank=True,
        null=True,
        help_text="Optional role description or responsibilities"
    )

    class Meta:
        ordering = ['name']
        verbose_name = "Job Position"
        verbose_name_plural = "Job Positions"

    def __str__(self):
        return f"{self.code} – {self.name}" if self.code else self.name

EMPLOYEE_TYPE_LIMITED = 'limited'
EMPLOYEE_TYPE_ADMIN   = 'admin'

EMPLOYEE_TYPE_CHOICES = (
    (EMPLOYEE_TYPE_LIMITED, 'Limited'),
    (EMPLOYEE_TYPE_ADMIN,   'Admin'),
)
class MaritalStatus(models.Model):
    name = models.CharField(max_length=100)
    discription = models.CharField(max_length=50, blank=True, null=True)

    def __str__(self):
        return self.name


class Employee(models.Model):
    employee_id = models.CharField(
        "Employee ID",
        max_length=20,
        unique=True,
        editable=False,
        null= True,
        blank=True
    )
    type = models.CharField(
        "Employee Type",
        max_length=20,
        choices=EMPLOYEE_TYPE_CHOICES,
        default=EMPLOYEE_TYPE_LIMITED,
        help_text="Select employee type (limited choices)."
    )
    # NEW: optional LCO FK
    lco = models.ForeignKey(
        'LCO.LCO',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='employees',
        verbose_name="LCO",
        help_text="Optional Local Cable Operator associated with this employee."
    )
    photo = models.ImageField("Photo",
                                             upload_to="employees/photos/",
                                             blank=True,
                                             null=True,
                                             validators=[FileExtensionValidator(['jpg','jpeg','png','webp'])])
    
    # STEP 1: Personal Details
    employee_name     = models.CharField("Employee Name", max_length=255)
    email             = models.EmailField("Email",null=True, blank=True)
    nationality       = models.CharField("Nationality", max_length=100)

    # NEW FIELD: District
    district = models.CharField("District", max_length=100, blank=True, null=True)

    state                = models.CharField("State/Province", max_length=100, blank=True,
                                           help_text="If nationality is India, pick state here.")
    city                 = models.CharField("City", max_length=100, blank=True, null=True)
    address_line1        = models.CharField("Address Line 1", max_length=255, blank=True, null=True)
    gstin                = models.CharField("GSTIN", max_length=15, blank=True,null=True,
                                            validators=[RegexValidator(r'^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$', 
                                                                       "Enter a valid 15‑character GSTIN.")])
    

    gender            = models.CharField("Gender", max_length=6, choices=GENDER_CHOICES)
    date_of_birth     = models.DateField("Date of Birth",null=True,blank=True)
    marital_status    = models.ForeignKey(
        MaritalStatus,
        on_delete=models.PROTECT,
        related_name='employees',
        blank=True, null=True
    )

    emergency_contact_name  = models.CharField("Emergency Contact Name", max_length=255, blank=True, null=True)
    emergency_contact = models.CharField(
        "Emergency Contact",
        max_length=20,
        null=True,
        blank=True,
        validators=[RegexValidator(r'^\+?\d{7,15}$', "Enter a valid phone number.")],
    )

    # STEP 2: Job Details
    
    visa_number        = models.CharField("Visa Number", max_length=50, blank=True, null=True)
    visa_expiry_date   = models.DateField("Visa Expiry Date",null=True,blank=True)
    pincode         = models.CharField(
        "Pincode (ZIP)",
        max_length=6,
        blank=True,
        null=True,
        validators=[RegexValidator(r'^[1-9][0-9]{5}$', "Enter a valid 6-digit PIN code.")],
        help_text="6-digit postal code, e.g. 560001"
    )
    job_position = models.ForeignKey(
    JobPosition,
    on_delete=models.PROTECT,
    related_name='employees',
    blank=True, null=True
    )
    work_mobile        = models.CharField(
        "Work Mobile",
        max_length=20,
        validators=[RegexValidator(r'^\+?\d{7,15}$', "Enter a valid phone number.")],blank=True, null=True
    )
    work_phone = models.CharField(
    "Work Phone",
    max_length=20,
    validators=[RegexValidator(r'^\+?\d{7,15}$', "Enter a valid phone number.")],
    blank=True, null=True
    )


    work_email         = models.EmailField("Work Email",null=True,blank=True)
    work_location      = models.CharField("Work Location", max_length=255,blank=True, null=True)

    # relations
    department = models.ForeignKey(
        'employe.Department',
        verbose_name="Department",
        on_delete=models.PROTECT,
        related_name='employees'
    )
    branch     = models.ForeignKey(
        'employe.Branch',
        verbose_name="Branch",
        on_delete=models.PROTECT,
        related_name='employees',
        blank=True,
        null=True

    )

    # NEW: allowed branches (many-to-many)
    allowed_branches = models.ManyToManyField(
        'employe.Branch',
        blank=True,
        related_name='allowed_employees',
        help_text='Branches this employee is allowed to access (multiple).'
    )

    
    manager = models.ForeignKey(
        'self',
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name='subordinates',
        verbose_name="Manager",
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    aadhaar_number     = models.CharField("Aadhaar Number", max_length=20, blank=True, null=True)
    certification_level= models.CharField("Certification Level", max_length=10, choices=CERTIFICATION_CHOICES, blank=True, null=True)
    field_of_study     = models.CharField("Field of Study", max_length=255, blank=True, null=True)
    school             = models.CharField("School / University", max_length=255, blank=True, null=True)
    work_permit = models.CharField("Work Permit Status", max_length=255, blank=True, null=True)

    
    # <-- NEW: passport_number field -->
    passport_number = models.CharField(
        "Passport Number",
        max_length=20,
        blank=True,
        null=True,
        validators=[RegexValidator(
            r'^[A-Za-z0-9\-/\s]{3,20}$',
            "Enter a valid passport number (3–20 characters: letters, numbers, space, hyphen or slash)."
        )],
        help_text="Passport number (optional)."
    )
    personal_mobile = models.CharField(max_length=15, blank=True, null=True)
    # in your Employee model (models.py)
    number_of_children = models.PositiveIntegerField("Number of Children", null=True, blank=True)

    basic_salary = models.DecimalField(
        "Basic Salary",
        max_digits=12,
        decimal_places=2,
        default=Decimal("0.00"),
        validators=[MinValueValidator(Decimal("0.00"))],
        help_text="Basic salary amount in company currency.",
                blank=True,
        null=True
    )

    da = models.DecimalField(
        "DA (Dearness Allowance)",
        max_digits=12,
        decimal_places=2,
        default=Decimal("0.00"),
        validators=[MinValueValidator(Decimal("0.00"))],
        help_text="Dearness Allowance amount.",
                blank=True,
        null=True
    )

    hra = models.DecimalField(
        "HRA (House Rent Allowance)",
        max_digits=12,
        decimal_places=2,
        default=Decimal("0.00"),
        validators=[MinValueValidator(Decimal("0.00"))],
        help_text="House Rent Allowance amount.",
        blank=True,
        null=True
    )
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='created_employees',
        verbose_name="Created By"
    )
    USER_TYPES = [
        ('distributer', 'Distributer'),
        ('subdistributer', 'SubDistributer'),
        ('lco', 'LCO'),
    ]
    emp_type = models.CharField(max_length=50, choices=USER_TYPES, default='lco', help_text="Type of user",blank=True, null=True)
    type_id = models.TextField(null=True, blank=True)
    class Meta:
        verbose_name        = "Employee"
        verbose_name_plural = "Employees"
        ordering            = ['employee_name']

    def __str__(self):
        return self.employee_name


     # NEW FIELD: Active status
    is_active = models.BooleanField(
        "Active",
        default=False,
        help_text="Indicates whether the employee is currently active."
    )


    # ----- payroll fields: new -----




from django.conf import settings
try:
    # Django 3.1+
    from django.db.models import JSONField
except Exception:
    from django.contrib.postgres.fields import JSONField


class EmployeeChangeLog(models.Model):
    ACTION_CREATE = "create"
    ACTION_UPDATE = "update"
    ACTION_DELETE = "delete"
    ACTION_CHOICES = (
        (ACTION_CREATE, "Created"),
        (ACTION_UPDATE, "Updated"),
        (ACTION_DELETE, "Deleted"),
    )

    employee = models.ForeignKey(
        "employe.Employee",
        on_delete=models.CASCADE,
        related_name="change_logs",
        help_text="Employee that was changed",
    )
    changed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="employee_change_logs",
        help_text="User who made the change (if available)"
    )
    action = models.CharField(max_length=10, choices=ACTION_CHOICES)
    # field-> {old:..., new:...}
    changes = JSONField(null=True, blank=True)
    # human readable summary (short)
    summary = models.CharField(max_length=255, blank=True, default="")
    # optional meta (ip, user_agent, extra)
    meta = JSONField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["employee"]),
            models.Index(fields=["created_at"]),
        ]

    def __str__(self):
        return f"{self.get_action_display()} {self.employee} at {self.created_at.isoformat()}"
    


